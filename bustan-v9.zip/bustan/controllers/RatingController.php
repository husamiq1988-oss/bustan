<?php
namespace Controllers;

use Core\Controller;
use Core\Helper;
use Models\Rating;

class RatingController extends Controller {
    public function store(): void {
        $productId = (int) ($_POST['product_id'] ?? 0);
        $phone = $_POST['phone'] ?? '';
        $rating = (int) ($_POST['rating'] ?? 0);
        $comment = $_POST['comment'] ?? '';

        if ($productId <= 0 || $rating < 1 || $rating > 5) {
            Helper::json(['status' => 'error', 'message' => 'بيانات غير صالحة']);
        }

        $ratingModel = new Rating();
        $ratingModel->create([
            'product_id' => $productId,
            'user_phone' => $phone,
            'rating' => $rating,
            'comment' => $comment
        ]);

        Helper::json(['status' => 'success', 'message' => 'تم إضافة التقييم']);
    }
}
