<?php
namespace Controllers;

use Core\Controller;
use Core\Auth;
use Core\Helper;
use Models\Employee;
use Models\EmployeeAttendance;
use Models\EmployeeTransaction;

class EmployeeController extends Controller {
    public function index(): void {
        Auth::requireAuth();

        $employeeModel = new Employee();
        $attendanceModel = new EmployeeAttendance();

        $employees = $employeeModel->active();
        $todayAttendance = $attendanceModel->today();

        $this->view('employees.index', [
            'title' => 'الموارد البشرية | البستان',
            'employees' => $employees,
            'todayAttendance' => $todayAttendance
        ]);
    }

    public function store(): void {
        Auth::requireAuth();

        $employeeModel = new Employee();
        $employeeModel->create([
            'name' => $_POST['name'],
            'phone' => $_POST['phone'] ?? '',
            'role' => $_POST['role'] ?? '',
            'salary' => $_POST['salary'] ?? 0,
            'status' => 'active'
        ]);

        Helper::setFlash('success', 'تم إضافة الموظف');
        Helper::redirect('/employees');
    }

    public function attendance(): void {
        Auth::requireAuth();

        $attendanceModel = new EmployeeAttendance();
        $attendanceModel->create([
            'employee_id' => $_POST['employee_id'],
            'date' => date('Y-m-d'),
            'check_in' => $_POST['check_in'] ?? date('H:i:s'),
            'check_out' => $_POST['check_out'] ?? null,
            'status' => $_POST['status'] ?? 'حضور',
            'late_minutes' => $_POST['late_minutes'] ?? 0,
            'deduction' => $_POST['deduction'] ?? 0
        ]);

        Helper::setFlash('success', 'تم تسجيل الحضور');
        Helper::redirect('/employees');
    }

    public function transaction(): void {
        Auth::requireAuth();

        $transactionModel = new EmployeeTransaction();
        $transactionModel->create([
            'employee_id' => $_POST['employee_id'],
            'type' => $_POST['type'] ?? 'salary',
            'amount' => $_POST['amount'] ?? 0,
            'date' => $_POST['date'] ?? date('Y-m-d'),
            'notes' => $_POST['notes'] ?? ''
        ]);

        Helper::setFlash('success', 'تم تسجيل العملية');
        Helper::redirect('/employees');
    }
}
