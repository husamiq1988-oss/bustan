<?php
namespace Controllers;

use Core\Controller;
use Core\Auth;
use Core\Helper;
use Core\Validator;
use Models\Recipe;
use Models\RecipeIngredient;
use Models\RecipeStep;
use Models\LabRecipe;
use Models\Inventory;
use Models\Product;

class RecipeController extends Controller {
    public function index(): void {
        Auth::requireAuth();

        $recipeModel = new Recipe();
        $labRecipeModel = new LabRecipe();

        $recipes = $recipeModel->withIngredients();
        $labRecipes = $labRecipeModel->visible();

        $this->view('recipes.index', [
            'title' => 'إدارة الوصفات | البستان',
            'recipes' => $recipes,
            'labRecipes' => $labRecipes
        ]);
    }

    public function create(): void {
        Auth::requireAuth();

        $inventoryModel = new Inventory();
        $productModel = new Product();

        $items = $inventoryModel->all();
        $products = $productModel->all();

        $this->view('recipes.create', [
            'title' => 'إضافة وصفة جديدة',
            'items' => $items,
            'products' => $products
        ]);
    }

    public function store(): void {
        Auth::requireAuth();

        $validator = new Validator($_POST);
        $validator->required('recipe_name', 'اسم الوصفة');

        if ($validator->fails()) {
            $_SESSION['errors'] = $validator->errors();
            Helper::redirect('/recipes/create');
        }

        try {
            $this->db->beginTransaction();

            // Create lab recipe
            $labRecipeModel = new LabRecipe();
            $recipeId = $labRecipeModel->create([
                'recipe_name' => $_POST['recipe_name'],
                'main_ingredient_name' => $_POST['main_ingredient_name'] ?? '',
                'main_store_item_id' => $_POST['main_store_item_id'] ?? null,
                'main_ingredient_price' => $_POST['main_ingredient_price'] ?? 0,
                'main_ingredient_amount' => $_POST['main_ingredient_amount'] ?? 0,
                'main_ingredient_unit' => $_POST['main_ingredient_unit'] ?? '',
                'temp_top' => $_POST['temp_top'] ?? 0,
                'temp_bottom' => $_POST['temp_bottom'] ?? 0,
                'has_fan' => $_POST['has_fan'] ?? 0,
                'is_visible' => $_POST['is_visible'] ?? 1,
                'batch_capacity' => $_POST['batch_capacity'] ?? 0,
                'mixer_capacity' => $_POST['mixer_capacity'] ?? 0,
                'kneading_time' => $_POST['kneading_time'] ?? 0,
                'fermentation_time' => $_POST['fermentation_time'] ?? 0,
                'baking_time' => $_POST['baking_time'] ?? 0,
                'piece_weight' => $_POST['piece_weight'] ?? 0
            ]);

            // Add ingredients
            if (!empty($_POST['ingredients'])) {
                $ingredientModel = new RecipeIngredient();
                $ingredientModel->createBatch($recipeId, $_POST['ingredients']);
            }

            // Add steps
            if (!empty($_POST['steps'])) {
                $stepModel = new RecipeStep();
                $stepModel->createBatch($recipeId, $_POST['steps']);
            }

            $this->db->commit();

            Helper::setFlash('success', 'تم إضافة الوصفة بنجاح');
            Helper::redirect('/recipes');

        } catch (\Exception $e) {
            if ($this->db->inTransaction()) {
                $this->db->rollBack();
            }
            Helper::setFlash('error', 'خطأ: ' . $e->getMessage());
            Helper::redirect('/recipes/create');
        }
    }

    public function edit(int $id): void {
        Auth::requireAuth();

        $labRecipeModel = new LabRecipe();
        $data = $labRecipeModel->withIngredients($id);

        if (empty($data)) {
            Helper::setFlash('error', 'الوصفة غير موجودة');
            Helper::redirect('/recipes');
        }

        $inventoryModel = new Inventory();
        $items = $inventoryModel->all();

        $this->view('recipes.edit', [
            'title' => 'تعديل وصفة',
            'recipe' => $data['recipe'],
            'ingredients' => $data['ingredients'],
            'steps' => $data['steps'],
            'items' => $items
        ]);
    }

    public function update(int $id): void {
        Auth::requireAuth();

        $labRecipeModel = new LabRecipe();
        $labRecipeModel->update($id, [
            'recipe_name' => $_POST['recipe_name'],
            'main_ingredient_name' => $_POST['main_ingredient_name'] ?? '',
            'main_ingredient_price' => $_POST['main_ingredient_price'] ?? 0,
            'main_ingredient_amount' => $_POST['main_ingredient_amount'] ?? 0,
            'temp_top' => $_POST['temp_top'] ?? 0,
            'temp_bottom' => $_POST['temp_bottom'] ?? 0,
            'has_fan' => $_POST['has_fan'] ?? 0,
            'is_visible' => $_POST['is_visible'] ?? 1,
            'batch_capacity' => $_POST['batch_capacity'] ?? 0,
            'kneading_time' => $_POST['kneading_time'] ?? 0,
            'fermentation_time' => $_POST['fermentation_time'] ?? 0,
            'baking_time' => $_POST['baking_time'] ?? 0,
            'piece_weight' => $_POST['piece_weight'] ?? 0
        ]);

        Helper::setFlash('success', 'تم التحديث بنجاح');
        Helper::redirect('/recipes');
    }
}
