<?php
namespace Controllers;

use Core\Controller;
use Core\Auth;
use Core\Helper;
use Core\Validator;
use Models\User;
use Models\Product;
use Models\Category;
use Models\Order;
use Models\Expense;
use Models\Chat;
use Models\Story;
use Models\WheelPrize;
use Models\WheelWinner;
use Models\Setting;
use Models\Driver;
use Models\Location;
use Models\Banner;
use Models\Offer;
use Models\Employee;
use Models\Inventory;

class AdminController extends Controller {
    // ========== Users ==========
    public function users(): void {
        Auth::requireAuth();
        $userModel = new User();
        $users = $userModel->all();
        $this->view('admin.users', ['title' => 'إدارة الزبائن', 'users' => $users]);
    }

    public function updateUser(): void {
        Auth::requireAuth();
        $id = (int) ($_POST['user_id'] ?? 0);
        $userModel = new User();
        $userModel->update($id, [
            'wallet_balance' => $_POST['new_balance'] ?? 0,
            'points' => $_POST['new_points'] ?? 0
        ]);
        Helper::setFlash('success', 'تم التحديث');
        Helper::redirect('/admin/users');
    }

    // ========== Products ==========
    public function products(): void {
        Auth::requireAuth();
        $productModel = new Product();
        $categoryModel = new Category();
        $this->view('admin.products', [
            'title' => 'إدارة الأصناف',
            'products' => $productModel->withCategory(),
            'categories' => $categoryModel->all()
        ]);
    }

    public function storeProduct(): void {
        Auth::requireAuth();
        $imagePath = null;
        if (!empty($_FILES['p_image']) && $_FILES['p_image']['error'] === UPLOAD_ERR_OK) {
            $imagePath = Helper::uploadImage($_FILES['p_image'], 'product');
        }
        $productModel = new Product();
        $productModel->create([
            'name' => $_POST['p_name'],
            'description' => $_POST['p_desc'] ?? '',
            'price' => $_POST['p_price'] ?? 0,
            'category_id' => $_POST['category_id'] ?? null,
            'image' => $imagePath,
            'is_available' => 1,
            'opt1' => $_POST['opt1'] ?? null,
            'price1' => $_POST['price1'] ?? 0,
            'opt2' => $_POST['opt2'] ?? null,
            'price2' => $_POST['price2'] ?? 0,
            'opt3' => $_POST['opt3'] ?? null,
            'price3' => $_POST['price3'] ?? 0,
            'opt4' => $_POST['opt4'] ?? null,
            'price4' => $_POST['price4'] ?? 0,
            'opt5' => $_POST['opt5'] ?? null,
            'price5' => $_POST['price5'] ?? 0,
            'opt6' => $_POST['opt6'] ?? null,
            'price6' => $_POST['price6'] ?? 0,
        ]);
        Helper::setFlash('success', 'تم إضافة المنتج');
        Helper::redirect('/admin/products');
    }

    public function updateProduct(int $id): void {
        Auth::requireAuth();
        $data = [
            'name' => $_POST['p_name'] ?? '',
            'description' => $_POST['p_desc'] ?? '',
            'price' => $_POST['p_price'] ?? 0,
            'category_id' => $_POST['category_id'] ?? null,
            'opt1' => $_POST['opt1'] ?? null,
            'price1' => $_POST['price1'] ?? 0,
            'opt2' => $_POST['opt2'] ?? null,
            'price2' => $_POST['price2'] ?? 0,
            'opt3' => $_POST['opt3'] ?? null,
            'price3' => $_POST['price3'] ?? 0,
            'opt4' => $_POST['opt4'] ?? null,
            'price4' => $_POST['price4'] ?? 0,
            'opt5' => $_POST['opt5'] ?? null,
            'price5' => $_POST['price5'] ?? 0,
            'opt6' => $_POST['opt6'] ?? null,
            'price6' => $_POST['price6'] ?? 0,
        ];
        if (!empty($_FILES['p_image']) && $_FILES['p_image']['error'] === UPLOAD_ERR_OK) {
            $data['image'] = Helper::uploadImage($_FILES['p_image'], 'product');
        }
        $productModel = new Product();
        $productModel->update($id, $data);
        Helper::setFlash('success', 'تم التحديث');
        Helper::redirect('/admin/products');
    }

    public function deleteProduct(int $id): void {
        Auth::requireAuth();
        $productModel = new Product();
        $productModel->delete($id);
        Helper::setFlash('success', 'تم الحذف');
        Helper::redirect('/admin/products');
    }

    public function toggleProduct(int $id): void {
        Auth::requireAuth();
        $productModel = new Product();
        $productModel->toggle($id);
        Helper::setFlash('success', 'تم التبديل');
        Helper::redirect('/admin/products');
    }

    // ========== Categories ==========
    public function categories(): void {
        Auth::requireAuth();
        $categoryModel = new Category();
        $this->view('admin.categories', [
            'title' => 'إدارة الأقسام',
            'categories' => $categoryModel->allWithCount()
        ]);
    }

    public function storeCategory(): void {
        Auth::requireAuth();
        $categoryModel = new Category();
        $categoryModel->create([
            'name' => $_POST['cat_name'],
            'is_visible' => 1,
            'sort_order' => $_POST['sort_order'] ?? 0
        ]);
        Helper::setFlash('success', 'تم إضافة القسم');
        Helper::redirect('/admin/categories');
    }

    public function deleteCategory(int $id): void {
        Auth::requireAuth();
        $categoryModel = new Category();
        $categoryModel->delete($id);
        Helper::setFlash('success', 'تم الحذف');
        Helper::redirect('/admin/categories');
    }

    // ========== Orders ==========
    public function orders(): void {
        Auth::requireAuth();
        $orderModel = new Order();
        $this->view('admin.orders', [
            'title' => 'إدارة الطلبات',
            'orders' => $orderModel->all()
        ]);
    }

    public function updateOrderStatus(int $id): void {
        Auth::requireAuth();
        $status = $_POST['status'] ?? '';
        $orderModel = new Order();
        $orderModel->updateStatus($id, $status);
        Helper::json(['status' => 'success']);
    }

    // ========== Expenses ==========
    public function expenses(): void {
        Auth::requireAuth();
        $expenseModel = new Expense();
        $this->view('admin.expenses', [
            'title' => 'سجل المصروفات',
            'expenses' => $expenseModel->monthly()
        ]);
    }

    public function storeExpense(): void {
        Auth::requireAuth();
        $expenseModel = new Expense();
        $expenseModel->create([
            'title' => $_POST['title'],
            'amount' => $_POST['amount'] ?? 0,
            'category' => $_POST['category'] ?? '',
            'expense_date' => $_POST['expense_date'] ?? date('Y-m-d'),
            'notes' => $_POST['notes'] ?? ''
        ]);
        Helper::setFlash('success', 'تم إضافة المصروف');
        Helper::redirect('/admin/expenses');
    }

    // ========== Chats ==========
    public function chats(): void {
        Auth::requireAuth();
        $chatModel = new Chat();
        $this->view('admin.chats', [
            'title' => 'شات الدعم الفني',
            'conversations' => $chatModel->conversations()
        ]);
    }

    // ========== Stories ==========
    public function stories(): void {
        Auth::requireAuth();
        $storyModel = new Story();
        $this->view('admin.stories', [
            'title' => 'حكايات الزبائن',
            'pending' => $storyModel->pending(),
            'approved' => $storyModel->approved()
        ]);
    }

    // ========== Wheel ==========
    public function wheel(): void {
        Auth::requireAuth();
        $prizeModel = new WheelPrize();
        $winnerModel = new WheelWinner();
        $this->view('admin.wheel', [
            'title' => 'إعدادات عجلة الحظ',
            'prizes' => $prizeModel->active(),
            'winners' => $winnerModel->recent()
        ]);
    }

    public function storePrize(): void {
        Auth::requireAuth();
        $prizeModel = new WheelPrize();
        $prizeModel->create([
            'prize_type' => $_POST['prize_type'],
            'prize_value' => $_POST['prize_value'],
            'label' => $_POST['label'],
            'weight' => $_POST['weight'] ?? 1,
            'whatsapp' => $_POST['whatsapp'] ?? 0,
            'discount_percent' => $_POST['discount_percent'] ?? 0
        ]);
        Helper::setFlash('success', 'تم إضافة الجائزة');
        Helper::redirect('/admin/wheel');
    }

    // ========== Settings ==========
    public function settings(): void {
        Auth::requireAuth();
        $settingModel = new Setting();
        $this->view('admin.settings', [
            'title' => 'إعدادات النظام',
            'settings' => $settingModel->all()
        ]);
    }

    public function updateSettings(): void {
        Auth::requireAuth();
        $settingModel = new Setting();
        foreach ($_POST as $key => $value) {
            if (strpos($key, 'setting_') === 0) {
                $realKey = substr($key, 8);
                $settingModel->set($realKey, $value);
            }
        }
        Helper::setFlash('success', 'تم حفظ الإعدادات');
        Helper::redirect('/admin/settings');
    }
}
