<?php
namespace Controllers;

use Core\Controller;
use Core\Auth;
use Core\Helper;
use Core\Validator;
use Models\Inventory;
use Models\InventoryUnit;
use Models\UnitConversion;
use Models\Purchase;

class InventoryController extends Controller {
    public function index(): void {
        Auth::requireAuth();

        $inventoryModel = new Inventory();
        $items = $inventoryModel->withUnits();
        $lowStock = $inventoryModel->lowStock();

        $this->view('inventory.index', [
            'title' => 'إدارة المخزون | البستان',
            'items' => $items,
            'lowStock' => $lowStock
        ]);
    }

    public function store(): void {
        Auth::requireAuth();

        $validator = new Validator($_POST);
        $validator->required('item_name', 'اسم المادة')->max('item_name', 255);

        if ($validator->fails()) {
            $_SESSION['errors'] = $validator->errors();
            Helper::redirect('/inventory');
        }

        $inventoryModel = new Inventory();
        $itemId = $inventoryModel->create([
            'parent_id' => $_POST['parent_id'] ?? null,
            'item_name' => $_POST['item_name'],
            'brand' => $_POST['brand'] ?? null,
            'current_qty' => $_POST['current_qty'] ?? 0,
            'alert_level' => $_POST['alert_level'] ?? 0,
            'unit' => $_POST['unit'] ?? '',
            'cost_price' => $_POST['cost_price'] ?? 0,
            'min_qty' => $_POST['min_qty'] ?? 0,
            'min_qty_unit' => $_POST['min_qty_unit'] ?? 'main',
            'storage_type' => $_POST['storage_type'] ?? 'main'
        ]);

        // Add unit conversion
        if (!empty($_POST['from_unit']) && !empty($_POST['equivalent_quantity'])) {
            $unitModel = new InventoryUnit();
            $unitModel->create([
                'item_id' => $itemId,
                'from_unit' => $_POST['from_unit'],
                'equivalent_quantity' => $_POST['equivalent_quantity'],
                'to_unit' => $_POST['to_unit'] ?? '',
                'calculated_unit_cost' => $_POST['calculated_unit_cost'] ?? 0
            ]);
        }

        Helper::setFlash('success', 'تم إضافة المادة بنجاح');
        Helper::redirect('/inventory');
    }

    public function edit(int $id): void {
        Auth::requireAuth();

        $inventoryModel = new Inventory();
        $item = $inventoryModel->find($id);

        if (!$item) {
            Helper::setFlash('error', 'المادة غير موجودة');
            Helper::redirect('/inventory');
        }

        $unitModel = new InventoryUnit();
        $units = $unitModel->byItem($id);

        $this->view('inventory.edit', [
            'title' => 'تعديل مادة مخزنية',
            'item' => $item,
            'units' => $units
        ]);
    }

    public function update(int $id): void {
        Auth::requireAuth();

        $inventoryModel = new Inventory();
        $inventoryModel->update($id, [
            'item_name' => $_POST['item_name'],
            'brand' => $_POST['brand'] ?? null,
            'current_qty' => $_POST['current_qty'] ?? 0,
            'alert_level' => $_POST['alert_level'] ?? 0,
            'unit' => $_POST['unit'] ?? '',
            'cost_price' => $_POST['cost_price'] ?? 0,
            'min_qty' => $_POST['min_qty'] ?? 0
        ]);

        Helper::setFlash('success', 'تم التحديث بنجاح');
        Helper::redirect('/inventory');
    }
}
