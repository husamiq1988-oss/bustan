<?php
namespace Controllers;

use Core\Controller;
use Core\Auth;
use Core\Helper;
use Models\Chat;
use Models\User;

class ChatController extends Controller {
    public function send(): void {
        $phone = $_POST['user_phone'] ?? '';
        $name = $_POST['customer_name'] ?? '';
        $message = $_POST['message_text'] ?? '';
        $senderType = $_POST['sender_type'] ?? 'customer';

        if (empty($phone) || empty($message)) {
            Helper::json(['status' => 'error', 'message' => 'جميع الحقول مطلوبة']);
        }

        $chatModel = new Chat();
        $chatModel->create([
            'user_phone' => $phone,
            'customer_name' => $name,
            'sender_type' => $senderType,
            'message_text' => $message,
            'is_read' => 0
        ]);

        Helper::json(['status' => 'success', 'message' => 'تم الإرسال']);
    }

    public function getMessages(): void {
        $phone = $_GET['phone'] ?? '';
        if (empty($phone)) {
            Helper::json(['status' => 'error', 'message' => 'رقم الهاتف مطلوب']);
        }

        $chatModel = new Chat();
        $messages = $chatModel->byPhone($phone);
        $chatModel->markRead($phone);

        Helper::json(['status' => 'success', 'messages' => $messages]);
    }

    public function adminReply(): void {
        Auth::requireAuth();
        $phone = $_POST['phone'] ?? '';
        $message = $_POST['message'] ?? '';

        if (empty($phone) || empty($message)) {
            Helper::json(['status' => 'error', 'message' => 'جميع الحقول مطلوبة']);
        }

        $chatModel = new Chat();
        $chatModel->create([
            'user_phone' => $phone,
            'customer_name' => 'Admin',
            'sender_type' => 'admin',
            'message_text' => $message,
            'is_read' => 0
        ]);

        Helper::json(['status' => 'success']);
    }
}
