<?php
namespace Controllers;

use Core\Controller;
use Core\Auth;
use Core\Helper;
use Models\LabRecipe;
use Models\RecipeIngredient;
use Models\RecipeStep;
use Models\ProductionLog;
use Models\Inventory;

class LabController extends Controller {
    public function index(): void {
        Auth::requireAuth();

        $labRecipeModel = new LabRecipe();
        $productionLogModel = new ProductionLog();
        $inventoryModel = new Inventory();

        $recipes = $labRecipeModel->visible();
        $logs = $productionLogModel->today();
        $lowStock = $inventoryModel->lowStock();

        // Check recipe completeness
        foreach ($recipes as &$recipe) {
            $ingredientModel = new RecipeIngredient();
            $recipe['ingredient_count'] = count($ingredientModel->byRecipe($recipe['id']));
            $recipe['has_ingredients'] = $recipe['ingredient_count'] > 0;
        }

        $this->view('lab.index', [
            'title' => 'لوحة تحكم المختبر | البستان',
            'recipes' => $recipes,
            'logs' => $logs,
            'lowStock' => $lowStock
        ]);
    }

    public function execute(): void {
        Auth::requireAuth();

        $recipeId = (int) ($_POST['recipe_id'] ?? 0);
        $qty = (float) ($_POST['qty'] ?? 0);

        if ($recipeId <= 0 || $qty <= 0) {
            Helper::setFlash('error', 'بيانات غير صالحة');
            Helper::redirect('/lab');
        }

        try {
            $this->db->beginTransaction();

            $labRecipeModel = new LabRecipe();
            $recipe = $labRecipeModel->find($recipeId);

            if (!$recipe) {
                throw new \Exception('الوصفة غير موجودة');
            }

            $ingredientModel = new RecipeIngredient();
            $ingredients = $ingredientModel->byRecipe($recipeId);

            // Check inventory
            $inventoryModel = new Inventory();
            foreach ($ingredients as $ing) {
                $item = $inventoryModel->find($ing['store_item_id']);
                if (!$item || $item['current_qty'] < ($ing['ratio_per_unit'] * $qty)) {
                    throw new \Exception('نقص في المخزن: ' . $ing['ingredient_name']);
                }
            }

            // Deduct inventory
            foreach ($ingredients as $ing) {
                $deduct = $ing['ratio_per_unit'] * $qty;
                $inventoryModel->decrement($ing['store_item_id'], $deduct);
            }

            // Log production
            $productionLogModel = new ProductionLog();
            $productionLogModel->create([
                'recipe_id' => $recipeId,
                'actual_store_item_id' => $recipe['main_store_item_id'],
                'executed_qty' => $qty
            ]);

            $this->db->commit();

            Helper::setFlash('success', 'تم التنفيذ بنجاح');
            Helper::redirect('/lab');

        } catch (\Exception $e) {
            if ($this->db->inTransaction()) {
                $this->db->rollBack();
            }
            Helper::setFlash('error', $e->getMessage());
            Helper::redirect('/lab');
        }
    }

    public function cancel(int $id): void {
        Auth::requireAuth();

        $productionLogModel = new ProductionLog();
        $log = $productionLogModel->find($id);

        if (!$log) {
            Helper::setFlash('error', 'السجل غير موجود');
            Helper::redirect('/lab');
        }

        try {
            $this->db->beginTransaction();

            // Return ingredients
            $ingredientModel = new RecipeIngredient();
            $ingredients = $ingredientModel->byRecipe($log['recipe_id']);
            $inventoryModel = new Inventory();

            foreach ($ingredients as $ing) {
                $returnQty = $ing['ratio_per_unit'] * $log['executed_qty'];
                $inventoryModel->increment($ing['store_item_id'], $returnQty);
            }

            // Delete log
            $productionLogModel->delete($id);

            $this->db->commit();

            Helper::setFlash('success', 'تم الإلغاء وإرجاع المخزن');
            Helper::redirect('/lab');

        } catch (\Exception $e) {
            if ($this->db->inTransaction()) {
                $this->db->rollBack();
            }
            Helper::setFlash('error', $e->getMessage());
            Helper::redirect('/lab');
        }
    }
}
