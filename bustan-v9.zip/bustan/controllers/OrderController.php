<?php
namespace Controllers;

use Core\Controller;
use Core\Helper;
use Core\Validator;
use Models\Order;
use Models\OrderItem;
use Models\User;
use Models\Location;
use Models\Driver;
use Models\Setting;
use Models\WalletTransaction;

class OrderController extends Controller {
    public function store(): void {
        $rawData = file_get_contents('php://input');
        $data = json_decode($rawData, true);

        if (!$data) {
            Helper::json(['status' => 'error', 'message' => 'بيانات غير صالحة']);
        }

        // Check restaurant status
        $settingModel = new Setting();
        $restStatus = $settingModel->get('restaurant_status', 'open');
        if ($restStatus === 'closed') {
            Helper::json(['status' => 'error', 'message' => 'المطعم مغلق حالياً']);
        }

        $cart = $data['cart'] ?? [];
        $phone = $data['phone'] ?? '';
        $customerName = $data['customer_name'] ?? '';
        $orderType = $data['order_type'] ?? 'delivery';
        $locationId = (int) ($data['location_id'] ?? 0);
        $paymentMethod = $data['payment_method'] ?? 'cash';
        $exactAddress = $data['exact_address'] ?? '';

        if (empty($cart) || empty($phone) || empty($customerName)) {
            Helper::json(['status' => 'error', 'message' => 'يرجى ملء جميع الحقول المطلوبة']);
        }

        try {
            $this->db->beginTransaction();

            $userModel = new User();
            $user = $userModel->findByPhone($phone);

            if (!$user) {
                throw new \Exception('لم يتم العثور على حساب لهذا الرقم');
            }
            $userId = $user['id'];

            // Calculate totals
            $itemsTotal = 0;
            foreach ($cart as $item) {
                $itemsTotal += ($item['price'] ?? 0) * ($item['qty'] ?? 1);
            }

            $deliveryFee = 0;
            $locationText = '';
            $assignedDriverId = null;

            if ($orderType === 'delivery' && $locationId > 0) {
                $locationModel = new Location();
                $location = $locationModel->find($locationId);
                if ($location) {
                    $deliveryFee = (float) $location['delivery_fee'];
                    $locationText = ' - ' . $location['location_name'];

                    // Smart driver assignment
                    $driverModel = new Driver();
                    $drivers = $driverModel->withOrdersCount();
                    foreach ($drivers as $driver) {
                        if ($driver['status'] === 'active') {
                            $assignedDriverId = $driver['id'];
                            break;
                        }
                    }
                }
            }

            $earnedPoints = floor($itemsTotal / 1000);
            $totalAmount = $itemsTotal + $deliveryFee;
            $paymentStatus = 'pending';

            // Wallet payment
            if ($paymentMethod === 'wallet') {
                if ((float) $user['balance'] < $totalAmount) {
                    throw new \Exception('رصيد المحفظة غير كافٍ');
                }

                $userModel->updateBalance($userId, (float) $user['balance'] - $totalAmount);

                $walletTrans = new WalletTransaction();
                $walletTrans->create([
                    'user_id' => $userId,
                    'amount' => $totalAmount,
                    'type' => 'withdrawal',
                    'description' => 'دفع ثمن الطلب'
                ]);

                $paymentStatus = 'paid';
            }

            // Update user name
            $userModel->update($userId, ['full_name' => $customerName]);

            // Create order
            $orderModel = new Order();
            $orderId = $orderModel->create([
                'user_id' => $userId,
                'user_phone' => $phone,
                'customer_name' => $customerName . $locationText,
                'subtotal_amount' => $itemsTotal,
                'delivery_fee' => $deliveryFee,
                'total_amount' => $totalAmount,
                'cart_data' => json_encode($cart),
                'points_added' => $earnedPoints,
                'order_type' => $orderType,
                'payment_method' => $paymentMethod,
                'order_status' => 'pending',
                'status' => 'pending',
                'driver_id' => $assignedDriverId,
                'admin_notes' => $exactAddress,
                'payment_status' => $paymentStatus
            ]);

            // Create order items
            $orderItemModel = new OrderItem();
            $orderItemModel->createBatch($orderId, $cart);

            $this->db->commit();

            Helper::json([
                'status' => 'success',
                'message' => 'تم إنشاء الطلب بنجاح',
                'order_id' => $orderId
            ]);

        } catch (\Exception $e) {
            if ($this->db->inTransaction()) {
                $this->db->rollBack();
            }
            Helper::json(['status' => 'error', 'message' => $e->getMessage()]);
        }
    }
}
