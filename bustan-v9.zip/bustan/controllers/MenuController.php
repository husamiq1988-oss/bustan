<?php
namespace Controllers;

use Core\Controller;
use Core\Helper;
use Models\Category;
use Models\Product;
use Models\Banner;
use Models\Offer;
use Models\Setting;
use Models\Story;

class MenuController extends Controller {
    public function index(): void {
        $categoryModel = new Category();
        $productModel = new Product();
        $bannerModel = new Banner();
        $offerModel = new Offer();
        $settingModel = new Setting();
        $storyModel = new Story();

        $categories = $categoryModel->visible();
        $products = $productModel->available();
        $banners = $bannerModel->active();
        $offers = $offerModel->latest();
        $stories = $storyModel->featured();

        $restaurantStatus = $settingModel->get('restaurant_status', 'open');
        $nextOpenTime = $settingModel->get('next_open_time', '');

        // Group products by category
        $groupedProducts = [];
        foreach ($products as $product) {
            $catId = $product['category_id'] ?? 0;
            $groupedProducts[$catId][] = $product;
        }

        $this->view('menu.index', [
            'categories' => $categories,
            'products' => $groupedProducts,
            'banners' => $banners,
            'offers' => $offers,
            'stories' => $stories,
            'restaurantStatus' => $restaurantStatus,
            'nextOpenTime' => $nextOpenTime,
            'title' => 'منيو مطعم البستان'
        ]);
    }
}
