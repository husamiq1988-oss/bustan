<?php
namespace Controllers;

use Core\Controller;
use Core\Auth;
use Core\Helper;
use Models\Order;
use Models\Driver;
use Models\DriverLedger;

class DeliveryController extends Controller {
    public function index(): void {
        Auth::requireAuth();

        $driverId = Auth::user()['id'] ?? 0;
        $orderModel = new Order();
        $driverModel = new Driver();
        $ledgerModel = new DriverLedger();

        $myOrders = $orderModel->byDriver($driverId);
        $driver = $driverModel->find($driverId);
        $balance = $ledgerModel->balance($driverId);

        $this->view('delivery.index', [
            'title' => 'مهامي - البستان',
            'orders' => $myOrders,
            'driver' => $driver,
            'balance' => $balance
        ]);
    }

    public function update(int $id): void {
        Auth::requireAuth();

        $status = $_POST['status'] ?? '';
        $allowed = ['pending', 'preparing', 'completed', 'cancelled'];

        if (!in_array($status, $allowed)) {
            Helper::json(['status' => 'error', 'message' => 'حالة غير صالحة']);
        }

        $orderModel = new Order();
        $orderModel->updateStatus($id, $status);

        Helper::json(['status' => 'success', 'message' => 'تم التحديث بنجاح']);
    }
}
