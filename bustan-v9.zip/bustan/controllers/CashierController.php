<?php
namespace Controllers;

use Core\Controller;
use Core\Auth;
use Core\Helper;
use Models\Order;
use Models\User;
use Models\Setting;
use Models\WheelCoupon;

class CashierController extends Controller {
    public function index(): void {
        Auth::requireAuth();

        $orderModel = new Order();
        $settingModel = new Setting();
        $couponModel = new WheelCoupon();

        $todayOrders = $orderModel->today();
        $cashierBalance = (float) $settingModel->get('cashier_balance', '0');
        $activeCoupons = $couponModel->where('is_used', 0);

        $this->view('cashier.index', [
            'title' => 'كاشير البستان',
            'orders' => $todayOrders,
            'cashierBalance' => $cashierBalance,
            'coupons' => $activeCoupons
        ]);
    }

    public function process(): void {
        Auth::requireAuth();

        $orderId = (int) ($_POST['order_id'] ?? 0);
        $paymentMethod = $_POST['payment_method'] ?? 'cash';

        $orderModel = new Order();
        $order = $orderModel->find($orderId);

        if (!$order) {
            Helper::setFlash('error', 'الطلب غير موجود');
            Helper::redirect('/cashier');
        }

        try {
            $this->db->beginTransaction();

            $updateData = [
                'payment_status' => 'paid',
                'order_status' => 'completed',
                'status' => 'completed'
            ];

            if ($paymentMethod === 'cash') {
                $settingModel = new Setting();
                $currentBalance = (float) $settingModel->get('cashier_balance', '0');
                $settingModel->set('cashier_balance', (string) ($currentBalance + $order['total_amount']));
            }

            $orderModel->update($orderId, $updateData);

            $this->db->commit();

            Helper::setFlash('success', 'تم معالجة الدفع بنجاح');
            Helper::redirect('/cashier');

        } catch (\Exception $e) {
            if ($this->db->inTransaction()) {
                $this->db->rollBack();
            }
            Helper::setFlash('error', 'خطأ: ' . $e->getMessage());
            Helper::redirect('/cashier');
        }
    }
}
