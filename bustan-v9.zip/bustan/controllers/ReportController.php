<?php
namespace Controllers;

use Core\Controller;
use Core\Auth;
use Core\Helper;
use Models\Order;
use Models\Expense;
use Models\WalletTransaction;
use Models\Purchase;

class ReportController extends Controller {
    public function index(): void {
        Auth::requireAuth();

        $orderModel = new Order();
        $expenseModel = new Expense();

        $todayStats = $orderModel->todayStats();
        $monthlyStats = $orderModel->monthlyStats();
        $todayExpenses = $expenseModel->totalToday();
        $monthlyExpenses = $expenseModel->totalMonth();

        $this->view('reports.index', [
            'title' => 'التقارير المالية | البستان',
            'todayStats' => $todayStats,
            'monthlyStats' => $monthlyStats,
            'todayExpenses' => $todayExpenses,
            'monthlyExpenses' => $monthlyExpenses,
            'todayProfit' => ($todayStats['total'] ?? 0) - $todayExpenses,
            'monthlyProfit' => ($monthlyStats['total'] ?? 0) - $monthlyExpenses
        ]);
    }

    public function sales(): void {
        Auth::requireAuth();

        $orderModel = new Order();
        $walletModel = new WalletTransaction();

        $todayOrders = $orderModel->today();
        $monthlyOrders = $orderModel->monthlyStats();
        $walletToday = $walletModel->totalToday();

        // Sales by payment method
        $cashSales = $this->db->fetch(
            "SELECT SUM(total_amount) as total FROM orders WHERE DATE(created_at) = CURDATE() AND payment_method = 'cash'"
        );
        $walletSales = $this->db->fetch(
            "SELECT SUM(total_amount) as total FROM orders WHERE DATE(created_at) = CURDATE() AND payment_method = 'wallet'"
        );

        $this->view('reports.sales', [
            'title' => 'تقارير المبيعات',
            'todayOrders' => $todayOrders,
            'monthlyTotal' => $monthlyOrders['total'] ?? 0,
            'cashSales' => $cashSales['total'] ?? 0,
            'walletSales' => $walletSales['total'] ?? 0,
            'walletToday' => $walletToday
        ]);
    }

    public function profits(): void {
        Auth::requireAuth();

        $orderModel = new Order();
        $expenseModel = new Expense();
        $purchaseModel = new Purchase();

        // Monthly breakdown
        $monthlySales = $this->db->fetchAll(
            "SELECT DATE(created_at) as date, COUNT(*) as orders, SUM(total_amount) as total, SUM(production_cost) as cost 
             FROM orders 
             WHERE MONTH(created_at) = MONTH(CURDATE()) AND YEAR(created_at) = YEAR(CURDATE())
             GROUP BY DATE(created_at) ORDER BY date DESC"
        );

        $monthlyExpenses = $expenseModel->monthly();
        $monthlyPurchases = $purchaseModel->monthly();

        $totalSales = array_sum(array_column($monthlySales, 'total'));
        $totalCost = array_sum(array_column($monthlySales, 'cost'));
        $totalExpenses = array_sum(array_column($monthlyExpenses, 'amount'));
        $totalPurchases = array_sum(array_column($monthlyPurchases, 'total_price'));

        $this->view('reports.profits', [
            'title' => 'تقارير الأرباح',
            'dailySales' => $monthlySales,
            'expenses' => $monthlyExpenses,
            'purchases' => $monthlyPurchases,
            'totalSales' => $totalSales,
            'totalCost' => $totalCost,
            'totalExpenses' => $totalExpenses,
            'totalPurchases' => $totalPurchases,
            'grossProfit' => $totalSales - $totalCost,
            'netProfit' => $totalSales - $totalCost - $totalExpenses - $totalPurchases
        ]);
    }
}
