<?php
namespace Controllers;

use Core\Controller;
use Core\Helper;
use Models\WheelPrize;
use Models\WheelSpin;
use Models\WheelWinner;
use Models\WheelCoupon;
use Models\Order;

class WheelController extends Controller {
    public function index(): void {
        $prizeModel = new WheelPrize();
        $prizes = $prizeModel->active();

        $this->view('wheel.index', [
            'title' => 'عجلة الحظ | البستان',
            'prizes' => $prizes
        ]);
    }

    public function spin(): void {
        $phone = $_POST['phone'] ?? '';
        $orderId = (int) ($_POST['order_id'] ?? 0);

        if (empty($phone)) {
            Helper::json(['status' => 'error', 'message' => 'رقم الهاتف مطلوب']);
        }

        // Check if already spun for this order
        $spinModel = new WheelSpin();
        if ($spinModel->byOrder($orderId)) {
            Helper::json(['status' => 'error', 'message' => 'لقد قمت بالدوران مسبقاً']);
        }

        $prizeModel = new WheelPrize();
        $prizes = $prizeModel->active();

        if (empty($prizes)) {
            Helper::json(['status' => 'error', 'message' => 'لا توجد جوائز متاحة']);
        }

        // Weighted random selection
        $totalWeight = array_sum(array_column($prizes, 'weight'));
        $random = mt_rand(1, $totalWeight);
        $currentWeight = 0;
        $selectedPrize = null;

        foreach ($prizes as $prize) {
            $currentWeight += $prize['weight'];
            if ($random <= $currentWeight) {
                $selectedPrize = $prize;
                break;
            }
        }

        if (!$selectedPrize) {
            $selectedPrize = $prizes[0];
        }

        // Generate coupon if discount
        $couponCode = null;
        if ($selectedPrize['prize_type'] === 'discount' && $selectedPrize['discount_percent'] > 0) {
            $couponCode = 'BUSTAN' . strtoupper(bin2hex(random_bytes(3)));
            $couponModel = new WheelCoupon();
            $couponModel->create([
                'coupon_code' => $couponCode,
                'user_phone' => $phone,
                'discount_percent' => $selectedPrize['discount_percent'],
                'is_used' => 0,
                'expires_at' => date('Y-m-d H:i:s', strtotime('+7 days'))
            ]);
        }

        // Record spin
        $spinModel->create([
            'order_id' => $orderId,
            'prize_type' => $selectedPrize['prize_type'],
            'prize_value' => $selectedPrize['prize_value']
        ]);

        // Record winner
        $winnerModel = new WheelWinner();
        $winnerModel->create([
            'order_id' => $orderId,
            'phone' => $phone,
            'prize_label' => $selectedPrize['label'],
            'coupon_code' => $couponCode,
            'is_delivered' => 0
        ]);

        Helper::json([
            'status' => 'success',
            'prize' => $selectedPrize['label'],
            'prize_type' => $selectedPrize['prize_type'],
            'prize_value' => $selectedPrize['prize_value'],
            'coupon_code' => $couponCode,
            'discount_percent' => $selectedPrize['discount_percent'] ?? 0
        ]);
    }

    public function winners(): void {
        Auth::requireAuth();
        $winnerModel = new WheelWinner();
        $this->view('wheel.winners', [
            'title' => 'سجل الفائزين',
            'winners' => $winnerModel->recent()
        ]);
    }
}
