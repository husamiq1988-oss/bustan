<?php
namespace Controllers;

use Core\Controller;
use Core\Auth;
use Core\Helper;
use Core\Validator;
use Models\Asset;
use Models\Inventory;

class AssetController extends Controller {
    public function index(): void {
        Auth::requireAuth();

        $assetModel = new Asset();
        $assets = $assetModel->all();
        $runningAssets = $assetModel->running();
        $wattage = $assetModel->totalWattage();

        // Calculate values
        $currentValue = 0;
        $futureValue = 0;
        $damagedValue = 0;
        $totalMaintenance = 0;

        foreach ($assets as $asset) {
            if ($asset['status'] === 'current') {
                $currentValue += ($asset['cost_price'] ?? 0) * ($asset['quantity'] ?? 1);
            } elseif ($asset['status'] === 'future') {
                $futureValue += ($asset['cost_price'] ?? 0) * ($asset['quantity'] ?? 1);
            } elseif ($asset['status'] === 'damaged') {
                $damagedValue += ($asset['cost_price'] ?? 0) * ($asset['quantity'] ?? 1);
            }
        }

        $this->view('assets.index', [
            'title' => 'إدارة الأصول | البستان',
            'assets' => $assets,
            'runningAssets' => $runningAssets,
            'currentValue' => $currentValue,
            'futureValue' => $futureValue,
            'damagedValue' => $damagedValue,
            'continuousWatts' => $wattage['continuous_watts'] ?? 0,
            'intermittentWatts' => $wattage['intermittent_watts'] ?? 0,
            'totalAmps' => ($wattage['continuous_watts'] ?? 0) / 220
        ]);
    }

    public function store(): void {
        Auth::requireAuth();

        $validator = new Validator($_POST);
        $validator->required('asset_name', 'اسم الأصل')->max('asset_name', 255);

        if ($validator->fails()) {
            $_SESSION['errors'] = $validator->errors();
            Helper::redirect('/assets');
        }

        $imagePath = null;
        if (!empty($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
            $imagePath = Helper::uploadImage($_FILES['image'], 'asset');
        }

        $assetModel = new Asset();
        $assetModel->create([
            'asset_name' => $_POST['asset_name'],
            'category' => $_POST['category'] ?? '',
            'status' => $_POST['status'] ?? 'current',
            'location' => $_POST['location'] ?? '',
            'quantity' => $_POST['quantity'] ?? 1,
            'cost_price' => $_POST['cost_price'] ?? 0,
            'wattage' => $_POST['wattage'] ?? 0,
            'phase_type' => $_POST['phase_type'] ?? '1_phase',
            'load_type' => $_POST['load_type'] ?? 'intermittent',
            'is_running' => $_POST['is_running'] ?? 0,
            'purchase_date' => $_POST['purchase_date'] ?? null,
            'warranty_expiry' => $_POST['warranty_expiry'] ?? null,
            'image_path' => $imagePath,
            'notes' => $_POST['notes'] ?? ''
        ]);

        Helper::setFlash('success', 'تم إضافة الأصل بنجاح');
        Helper::redirect('/assets');
    }

    public function toggle(int $id): void {
        Auth::requireAuth();

        $assetModel = new Asset();
        $assetModel->toggleRunning($id);

        Helper::json(['status' => 'success']);
    }
}
