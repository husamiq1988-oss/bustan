<?php
namespace Controllers;

use Core\Controller;
use Core\Auth;
use Core\Helper;
use Models\Order;
use Models\User;
use Models\Inventory;
use Models\Expense;
use Models\Setting;
use Models\Driver;

class DashboardController extends Controller {
    public function index(): void {
        Auth::requireAuth();

        $orderModel = new Order();
        $userModel = new User();
        $inventoryModel = new Inventory();
        $expenseModel = new Expense();
        $settingModel = new Setting();
        $driverModel = new Driver();

        $todayStats = $orderModel->todayStats();
        $monthlyStats = $orderModel->monthlyStats();
        $pendingOrders = $orderModel->pending();
        $totalUsers = $userModel->count();
        $lowStock = $inventoryModel->lowStock();
        $todayExpenses = $expenseModel->totalToday();
        $restaurantStatus = $settingModel->get('restaurant_status', 'open');
        $cashierBalance = (float) $settingModel->get('cashier_balance', '0');
        $inventoryValue = $this->calculateInventoryValue();

        $this->view('dashboard.index', [
            'title' => 'لوحة التحكم | مطعم البستان',
            'todayStats' => $todayStats,
            'monthlyStats' => $monthlyStats,
            'pendingOrders' => $pendingOrders,
            'totalUsers' => $totalUsers,
            'lowStock' => $lowStock,
            'todayExpenses' => $todayExpenses,
            'restaurantStatus' => $restaurantStatus,
            'cashierBalance' => $cashierBalance,
            'inventoryValue' => $inventoryValue,
            'user' => Auth::user()
        ]);
    }

    public function profits(): void {
        Auth::requireAuth();

        $orderModel = new Order();
        $expenseModel = new Expense();

        $monthlySales = $orderModel->monthlyStats();
        $monthlyExpenses = $expenseModel->totalMonth();
        $profit = ($monthlySales['total'] ?? 0) - $monthlyExpenses;

        $this->view('dashboard.profits', [
            'title' => 'تقارير الأرباح | مطعم البستان',
            'monthlySales' => $monthlySales,
            'monthlyExpenses' => $monthlyExpenses,
            'profit' => $profit
        ]);
    }

    public function sales(): void {
        Auth::requireAuth();

        $orderModel = new Order();
        $todayOrders = $orderModel->today();

        $this->view('dashboard.sales', [
            'title' => 'تقارير المبيعات | مطعم البستان',
            'orders' => $todayOrders
        ]);
    }

    private function calculateInventoryValue(): float {
        $result = $this->db->fetch(
            "SELECT SUM(current_qty * cost_price) as total FROM inventory"
        );
        return (float) ($result['total'] ?? 0);
    }
}
