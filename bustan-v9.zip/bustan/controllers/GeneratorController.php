<?php
namespace Controllers;

use Core\Controller;
use Core\Auth;
use Core\Helper;
use Models\GeneratorLog;
use Models\GeneratorStatus;
use Models\Asset;

class GeneratorController extends Controller {
    public function index(): void {
        Auth::requireAuth();

        $logModel = new GeneratorLog();
        $statusModel = new GeneratorStatus();
        $assetModel = new Asset();

        $logs = $logModel->today();
        $status = $statusModel->get();
        $totalHours = $logModel->totalHours();
        $totalFuel = $logModel->totalFuel();

        $this->view('generator.index', [
            'title' => 'إدارة المولد | البستان',
            'logs' => $logs,
            'status' => $status,
            'totalHours' => $totalHours,
            'totalFuel' => $totalFuel
        ]);
    }

    public function toggle(): void {
        Auth::requireAuth();

        $statusModel = new GeneratorStatus();
        $current = $statusModel->get();

        if ($current['current_state'] === 'stopped') {
            // Start generator
            $statusModel->start();
            Helper::json(['status' => 'success', 'state' => 'running', 'message' => 'تم تشغيل المولد']);
        } else {
            // Stop generator and calculate
            $startTime = strtotime($current['last_start_time']);
            $endTime = time();
            $durationMinutes = round(($endTime - $startTime) / 60);
            $fuelRate = (float) ($current['fuel_rate_per_hour'] ?? 2.5);
            $fuelConsumed = ($durationMinutes / 60) * $fuelRate;

            $logModel = new GeneratorLog();
            $logModel->create([
                'start_time' => date('Y-m-d H:i:s', $startTime),
                'end_time' => date('Y-m-d H:i:s', $endTime),
                'duration_minutes' => $durationMinutes,
                'estimated_fuel_consumed' => $fuelConsumed
            ]);

            $statusModel->stop($durationMinutes / 60, $fuelConsumed);
            Helper::json(['status' => 'success', 'state' => 'stopped', 'message' => 'تم إيقاف المولد']);
        }
    }
}
