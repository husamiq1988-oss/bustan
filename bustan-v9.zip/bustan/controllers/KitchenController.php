<?php
namespace Controllers;

use Core\Controller;
use Core\Auth;
use Core\Helper;
use Models\Order;
use Models\Inventory;
use Models\Recipe;
use Models\ProductionLog;

class KitchenController extends Controller {
    public function index(): void {
        Auth::requireAuth();

        $orderModel = new Order();
        $pendingOrders = $orderModel->pending();

        $this->view('kitchen.index', [
            'title' => 'شاشة المطبخ | البستان',
            'orders' => $pendingOrders
        ]);
    }

    public function complete(int $id): void {
        Auth::requireAuth();

        $orderModel = new Order();
        $order = $orderModel->find($id);

        if (!$order) {
            Helper::setFlash('error', 'الطلب غير موجود');
            Helper::redirect('/kitchen');
        }

        try {
            $this->db->beginTransaction();

            // Update order status
            $orderModel->updateStatus($id, 'completed');

            // Deduct inventory based on recipes
            $cartData = json_decode($order['cart_data'], true) ?: [];
            $inventoryModel = new Inventory();
            $recipeModel = new Recipe();

            foreach ($cartData as $item) {
                $recipes = $recipeModel->byProduct($item['id']);
                foreach ($recipes as $recipe) {
                    $deductAmount = $recipe['quantity_required'] * $item['qty'];
                    $inventoryModel->decrement($recipe['inventory_id'], $deductAmount);
                }
            }

            // Add points to user
            if ($order['points_added'] > 0) {
                $userModel = new \Models\User();
                $userModel->addPoints($order['user_id'], $order['points_added']);
            }

            $this->db->commit();

            Helper::setFlash('success', 'تم إكمال الطلب بنجاح');
            Helper::redirect('/kitchen');

        } catch (\Exception $e) {
            if ($this->db->inTransaction()) {
                $this->db->rollBack();
            }
            Helper::setFlash('error', 'خطأ: ' . $e->getMessage());
            Helper::redirect('/kitchen');
        }
    }
}
