<?php
namespace Controllers;

use Core\Controller;
use Core\Auth;
use Core\Helper;
use Core\Validator;
use Models\User;

class AuthController extends Controller {
    public function loginForm(): void {
        if (Auth::check()) {
            Helper::redirect('/dashboard');
        }
        $this->view('auth.login');
    }

    public function login(): void {
        $validator = new Validator($_POST);
        $validator->required('phone', 'رقم الهاتف')->phone('phone', 'رقم الهاتف');

        if ($validator->fails()) {
            $_SESSION['errors'] = $validator->errors();
            $_SESSION['old'] = $_POST;
            Helper::redirect('/login');
        }

        $userModel = new User();
        $user = $userModel->findByPhone($_POST['phone']);

        if (!$user) {
            $_SESSION['errors'] = ['phone' => 'رقم الهاتف غير مسجل'];
            Helper::redirect('/login');
        }

        // Check password if set
        if (!empty($user['password']) && !empty($_POST['password'])) {
            if (!password_verify($_POST['password'], $user['password'])) {
                $_SESSION['errors'] = ['password' => 'كلمة المرور غير صحيحة'];
                Helper::redirect('/login');
            }
        }

        Auth::login($user);
        Helper::setFlash('success', 'تم تسجيل الدخول بنجاح');
        Helper::redirect('/dashboard');
    }

    public function logout(): void {
        Auth::logout();
        Helper::redirect('/');
    }
}
