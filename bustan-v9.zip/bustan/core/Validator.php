<?php
namespace Core;

class Validator {
    private array $errors = [];
    private array $data = [];

    public function __construct(array $data) {
        $this->data = $data;
    }

    public function required(string $field, string $label = ''): self {
        $label = $label ?: $field;
        if (empty($this->data[$field]) || trim($this->data[$field]) === '') {
            $this->errors[$field] = "حقل {$label} مطلوب";
        }
        return $this;
    }

    public function min(string $field, int $min, string $label = ''): self {
        $label = $label ?: $field;
        if (isset($this->data[$field]) && mb_strlen($this->data[$field]) < $min) {
            $this->errors[$field] = "{$label} يجب أن يكون {$min} أحرف على الأقل";
        }
        return $this;
    }

    public function max(string $field, int $max, string $label = ''): self {
        $label = $label ?: $field;
        if (isset($this->data[$field]) && mb_strlen($this->data[$field]) > $max) {
            $this->errors[$field] = "{$label} يجب أن لا يتجاوز {$max} حرف";
        }
        return $this;
    }

    public function numeric(string $field, string $label = ''): self {
        $label = $label ?: $field;
        if (isset($this->data[$field]) && !is_numeric($this->data[$field])) {
            $this->errors[$field] = "{$label} يجب أن يكون رقماً";
        }
        return $this;
    }

    public function minValue(string $field, float $min, string $label = ''): self {
        $label = $label ?: $field;
        if (isset($this->data[$field]) && (float)$this->data[$field] < $min) {
            $this->errors[$field] = "{$label} يجب أن يكون {$min} على الأقل";
        }
        return $this;
    }

    public function phone(string $field, string $label = ''): self {
        $label = $label ?: $field;
        if (isset($this->data[$field]) && !preg_match('/^07[0-9]{9}$/', $this->data[$field])) {
            $this->errors[$field] = "{$label} يجب أن يكون رقم عراقي صحيح (07XXXXXXXXX)";
        }
        return $this;
    }

    public function email(string $field, string $label = ''): self {
        $label = $label ?: $field;
        if (isset($this->data[$field]) && !filter_var($this->data[$field], FILTER_VALIDATE_EMAIL)) {
            $this->errors[$field] = "{$label} يجب أن يكون بريد إلكتروني صحيح";
        }
        return $this;
    }

    public function in(string $field, array $allowed, string $label = ''): self {
        $label = $label ?: $field;
        if (isset($this->data[$field]) && !in_array($this->data[$field], $allowed)) {
            $this->errors[$field] = "{$label} قيمة غير صالحة";
        }
        return $this;
    }

    public function fails(): bool {
        return !empty($this->errors);
    }

    public function passes(): bool {
        return empty($this->errors);
    }

    public function errors(): array {
        return $this->errors;
    }

    public function first(): ?string {
        return $this->errors[array_key_first($this->errors)] ?? null;
    }
}
