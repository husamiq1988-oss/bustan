<?php
namespace Core;

class Router {
    private array $routes = [];
    private array $params = [];
    private string $currentUri = '';

    public function __construct() {
        $this->currentUri = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
        $base = dirname($_SERVER['SCRIPT_NAME']);
        if ($base !== '/' && strpos($this->currentUri, $base) === 0) {
            $this->currentUri = substr($this->currentUri, strlen($base));
        }
        $this->currentUri = trim($this->currentUri, '/');
    }

    public function get(string $route, $callback, array $middleware = []): self {
        $this->addRoute('GET', $route, $callback, $middleware);
        return $this;
    }

    public function post(string $route, $callback, array $middleware = []): self {
        $this->addRoute('POST', $route, $callback, $middleware);
        return $this;
    }

    public function put(string $route, $callback, array $middleware = []): self {
        $this->addRoute('PUT', $route, $callback, $middleware);
        return $this;
    }

    public function delete(string $route, $callback, array $middleware = []): self {
        $this->addRoute('DELETE', $route, $callback, $middleware);
        return $this;
    }

    private function addRoute(string $method, string $route, $callback, array $middleware): void {
        $route = trim($route, '/');
        $route = preg_replace('/\{([a-zA-Z0-9_]+)\}/', '(?P<$1>[^/]+)', $route);
        $route = '#^' . $route . '$#';
        $this->routes[$method][$route] = ['callback' => $callback, 'middleware' => $middleware];
    }

    public function dispatch(): void {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method === 'POST' && isset($_POST['_method'])) {
            $method = strtoupper($_POST['_method']);
        }

        foreach ($this->routes[$method] ?? [] as $route => $data) {
            if (preg_match($route, $this->currentUri, $matches)) {
                $this->params = array_filter($matches, 'is_string', ARRAY_FILTER_USE_KEY);
                try {
                    $this->runMiddleware($data['middleware']);
                    $this->execute($data['callback']);
                } catch (\Throwable $e) {
                    $this->showError($e);
                }
                return;
            }
        }

        http_response_code(404);
        echo '<h1>404 - الصفحة غير موجودة</h1>';
        echo '<p>URI: ' . htmlspecialchars($this->currentUri) . '</p>';
        echo '<p>Method: ' . $method . '</p>';
    }

    private function runMiddleware(array $middleware): void {
        foreach ($middleware as $m) {
            $class = "Middleware\\" . $m;
            if (class_exists($class)) {
                (new $class)->handle();
            }
        }
    }

    private function execute($callback): void {
        if (is_callable($callback)) {
            call_user_func_array($callback, $this->params);
        } elseif (is_string($callback) && strpos($callback, '@') !== false) {
            [$controller, $method] = explode('@', $callback);
            // تحويل إلى lowercase للبحث
            $class = strtolower("Controllers\\" . $controller);
            if (class_exists($class)) {
                $instance = new $class();
                call_user_func_array([$instance, $method], $this->params);
            } else {
                throw new \Exception('Controller not found: ' . $class . ' (looking for: controllers/' . $controller . '.php)');
            }
        }
    }

    private function showError(\Throwable $e): void {
        http_response_code(500);
        echo '<div style="background:#dc3545;color:white;padding:20px;margin:20px;border-radius:10px;font-family:Arial;">';
        echo '<h2>❌ خطأ في النظام</h2>';
        echo '<p><strong>الرسالة:</strong> ' . htmlspecialchars($e->getMessage()) . '</p>';
        echo '<p><strong>الملف:</strong> ' . $e->getFile() . ' (سطر ' . $e->getLine() . ')</p>';
        echo '<hr><pre style="background:rgba(0,0,0,0.2);padding:10px;border-radius:5px;overflow:auto;">' . $e->getTraceAsString() . '</pre>';
        echo '</div>';
    }

    public function param(string $key): ?string {
        return $this->params[$key] ?? null;
    }
}
