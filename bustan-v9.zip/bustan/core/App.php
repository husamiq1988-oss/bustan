<?php
namespace Core;

class App {
    private Router $router;

    public function __construct() {
        // تفعيل عرض الأخطاء
        error_reporting(E_ALL);
        ini_set('display_errors', 1);
        ini_set('display_startup_errors', 1);

        session_start();
        $config = require __DIR__ . '/../config/app.php';
        date_default_timezone_set($config['timezone']);
        $this->router = new Router();
        $this->registerRoutes();
    }

    private function registerRoutes(): void {
        $routes = require __DIR__ . '/../routes.php';
        $routes($this->router);
    }

    public function run(): void {
        $this->router->dispatch();
    }
}
