<?php
namespace Core;

class Helper {
    public static function e(string $text): string {
        return htmlspecialchars($text, ENT_QUOTES, 'UTF-8');
    }

    public static function redirect(string $url): void {
        header("Location: " . $url);
        exit();
    }

    public static function json(array $data, int $status = 200): void {
        http_response_code($status);
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode($data, JSON_UNESCAPED_UNICODE);
        exit();
    }

    public static function formatMoney(float $amount): string {
        return number_format($amount) . ' د.ع';
    }

    public static function formatDate(string $date): string {
        return date('Y-m-d H:i', strtotime($date));
    }

    public static function now(): string {
        return date('Y-m-d H:i:s');
    }

    public static function asset(string $path): string {
        $config = require __DIR__ . '/../config/app.php';
        return rtrim($config['url'], '/') . '/assets/' . ltrim($path, '/');
    }

    public static function url(string $path = ''): string {
        $config = require __DIR__ . '/../config/app.php';
        return rtrim($config['url'], '/') . '/' . ltrim($path, '/');
    }

    public static function csrfField(): string {
        $token = CSRF::generate();
        return '<input type="hidden" name="_token" value="' . self::e($token) . '">';
    }

    public static function old(string $key, string $default = ''): string {
        return $_SESSION['old'][$key] ?? $default;
    }

    public static function flash(string $key): ?string {
        if (isset($_SESSION['flash'][$key])) {
            $msg = $_SESSION['flash'][$key];
            unset($_SESSION['flash'][$key]);
            return $msg;
        }
        return null;
    }

    public static function setFlash(string $key, string $message): void {
        $_SESSION['flash'][$key] = $message;
    }

    public static function uploadImage(array $file, string $prefix = 'img'): ?string {
        $config = require __DIR__ . '/../config/app.php';
        if (!isset($file['tmp_name']) || $file['error'] !== UPLOAD_ERR_OK) {
            return null;
        }
        if ($file['size'] > $config['max_upload_size']) {
            return null;
        }
        $allowed = ['image/jpeg', 'image/png', 'image/webp', 'image/gif'];
        $finfo = finfo_open(FILEINFO_MIME_TYPE);
        $mime = finfo_file($finfo, $file['tmp_name']);
        finfo_close($finfo);
        if (!in_array($mime, $allowed)) {
            return null;
        }
        $ext = pathinfo($file['name'], PATHINFO_EXTENSION);
        $ext = strtolower($ext);
        if (!in_array($ext, ['jpg', 'jpeg', 'png', 'webp', 'gif'])) {
            return null;
        }
        $filename = $prefix . '_' . time() . '_' . bin2hex(random_bytes(4)) . '.' . $ext;
        $path = $config['upload_path'] . $filename;
        if (!is_dir($config['upload_path'])) {
            mkdir($config['upload_path'], 0755, true);
        }
        if (move_uploaded_file($file['tmp_name'], $path)) {
            return 'uploads/' . $filename;
        }
        return null;
    }
}
