<?php
namespace Core;

class Controller {
    protected Database $db;

    public function __construct() {
        $this->db = new Database();
    }

    protected function view(string $view, array $data = []): void {
        extract($data);
        $viewFile = __DIR__ . '/../views/' . str_replace('.', '/', $view) . '.php';
        if (file_exists($viewFile)) {
            require $viewFile;
        } else {
            throw new \Exception("View not found: {$view}");
        }
    }

    protected function json(array $data, int $status = 200): void {
        Helper::json($data, $status);
    }

    protected function redirect(string $url): void {
        Helper::redirect($url);
    }

    protected function validate(array $rules): array {
        $validator = new Validator($_POST);
        foreach ($rules as $field => $rule) {
            $parts = explode('|', $rule);
            $label = $parts[0] ?? $field;
            foreach ($parts as $part) {
                if ($part === 'required') $validator->required($field, $label);
                if (str_starts_with($part, 'min:')) $validator->min($field, (int)substr($part, 4), $label);
                if (str_starts_with($part, 'max:')) $validator->max($field, (int)substr($part, 4), $label);
                if ($part === 'numeric') $validator->numeric($field, $label);
                if (str_starts_with($part, 'minValue:')) $validator->minValue($field, (float)substr($part, 9), $label);
                if ($part === 'phone') $validator->phone($field, $label);
                if ($part === 'email') $validator->email($field, $label);
            }
        }
        if ($validator->fails()) {
            $_SESSION['errors'] = $validator->errors();
            $_SESSION['old'] = $_POST;
            return ['errors' => $validator->errors()];
        }
        return ['errors' => []];
    }
}
