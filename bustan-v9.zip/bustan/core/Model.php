<?php
namespace Core;

class Model {
    protected Database $db;
    protected string $table = '';
    protected string $primaryKey = 'id';

    public function __construct() {
        $this->db = new Database();
    }

    public function all(): array {
        return $this->db->fetchAll("SELECT * FROM `{$this->table}` ORDER BY {$this->primaryKey} DESC");
    }

    public function find(int $id): ?array {
        return $this->db->fetch("SELECT * FROM `{$this->table}` WHERE {$this->primaryKey} = ?", [$id]);
    }

    public function findBy(string $column, $value): ?array {
        return $this->db->fetch("SELECT * FROM `{$this->table}` WHERE {$column} = ? LIMIT 1", [$value]);
    }

    public function where(string $column, $value): array {
        return $this->db->fetchAll("SELECT * FROM `{$this->table}` WHERE {$column} = ?", [$value]);
    }

    public function create(array $data): int {
        return $this->db->insert($this->table, $data);
    }

    public function update(int $id, array $data): int {
        return $this->db->update($this->table, $data, "{$this->primaryKey} = ?", [$id]);
    }

    public function delete(int $id): int {
        return $this->db->delete($this->table, "{$this->primaryKey} = ?", [$id]);
    }

    public function count(): int {
        $result = $this->db->fetch("SELECT COUNT(*) as count FROM `{$this->table}`");
        return (int) ($result['count'] ?? 0);
    }

    public function query(string $sql, array $params = []): array {
        return $this->db->fetchAll($sql, $params);
    }
}
