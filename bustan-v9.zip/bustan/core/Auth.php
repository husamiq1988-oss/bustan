<?php
namespace Core;

class Auth {
    public static function user(): ?array {
        if (isset($_SESSION['user'])) {
            return $_SESSION['user'];
        }
        return null;
    }

    public static function id(): ?int {
        return $_SESSION['user']['id'] ?? null;
    }

    public static function check(): bool {
        return isset($_SESSION['user']['id']);
    }

    public static function guest(): bool {
        return !self::check();
    }

    public static function role(): string {
        return $_SESSION['user']['role'] ?? 'guest';
    }

    public static function isAdmin(): bool {
        return self::role() === 'admin';
    }

    public static function isChef(): bool {
        return in_array(self::role(), ['admin', 'chef']);
    }

    public static function isDelivery(): bool {
        return in_array(self::role(), ['admin', 'delivery']);
    }

    public static function isCashier(): bool {
        return in_array(self::role(), ['admin', 'cashier']);
    }

    public static function login(array $user): void {
        $_SESSION['user'] = $user;
        $_SESSION['login_time'] = time();
    }

    public static function logout(): void {
        unset($_SESSION['user'], $_SESSION['login_time']);
        session_destroy();
    }

    public static function requireAuth(): void {
        if (self::guest()) {
            Helper::redirect('/login');
        }
    }

    public static function requireRole(string $role): void {
        self::requireAuth();
        if (self::role() !== $role && self::role() !== 'admin') {
            http_response_code(403);
            die('Access Denied');
        }
    }
}
