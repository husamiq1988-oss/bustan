<?php $layout = 'admin'; ?>
<div class="row">
    <div class="col-12">
        <h2><i class="bi bi-plugin"></i> إدارة المولد الكهربائي</h2>
    </div>
</div>

<div class="row mt-4">
    <div class="col-md-4">
        <div class="card text-center mb-3">
            <div class="card-body">
                <h5>حالة المولد</h5>
                <div class="display-1 mb-3">
                    <?php if ($status['current_state'] === 'running'): ?>
                    <i class="bi bi-lightning-charge-fill text-success"></i>
                    <?php else: ?>
                    <i class="bi bi-lightning-charge text-muted"></i>
                    <?php endif; ?>
                </div>
                <h3 class="<?= $status['current_state'] === 'running' ? 'text-success' : 'text-muted' ?>">
                    <?= $status['current_state'] === 'running' ? 'يعمل' : 'متوقف' ?>
                </h3>
                <?php if ($status['current_state'] === 'running'): ?>
                <p class="text-muted">منذ: <?= e($status['last_start_time']) ?></p>
                <?php endif; ?>
                <button class="btn btn-<?= $status['current_state'] === 'running' ? 'danger' : 'success' ?> btn-lg w-100" onclick="toggleGenerator()">
                    <i class="bi bi-power"></i> <?= $status['current_state'] === 'running' ? 'إيقاف' : 'تشغيل' ?>
                </button>
            </div>
        </div>
    </div>
    <div class="col-md-8">
        <div class="row">
            <div class="col-md-6 mb-3">
                <div class="card stat-card">
                    <div class="card-body text-center">
                        <h6>إجمالي الساعات</h6>
                        <h3><?= number_format($totalHours, 2) ?> ساعة</h3>
                    </div>
                </div>
            </div>
            <div class="col-md-6 mb-3">
                <div class="card stat-card" style="background: linear-gradient(135deg, #40916c, #52b788);">
                    <div class="card-body text-center">
                        <h6>الوقود المستهلك</h6>
                        <h3><?= number_format($totalFuel, 2) ?> لتر</h3>
                    </div>
                </div>
            </div>
        </div>
        <div class="card">
            <div class="card-header"><i class="bi bi-clock-history"></i> سجل التشغيل اليوم</div>
            <div class="card-body">
                <?php if (empty($logs)): ?>
                    <p class="text-muted">لا توجد سجلات اليوم</p>
                <?php else: ?>
                <div class="table-responsive">
                    <table class="table">
                        <thead><tr><th>البداية</th><th>النهاية</th><th>المدة</th><th>الوقود</th></tr></thead>
                        <tbody>
                            <?php foreach ($logs as $log): ?>
                            <tr>
                                <td><?= format_date($log['start_time']) ?></td>
                                <td><?= format_date($log['end_time']) ?></td>
                                <td><?= $log['duration_minutes'] ?> دقيقة</td>
                                <td><?= $log['estimated_fuel_consumed'] ?> لتر</td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<script>
function toggleGenerator() {
    fetch('/generator/toggle', {
        method: 'POST',
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        body: '_token=<?= $_SESSION['csrf_token'] ?? '' ?>'
    })
    .then(r => r.json())
    .then(res => {
        alert(res.message);
        location.reload();
    });
}
</script>
