<div class="container">
    <!-- Banners -->
    <?php if (!empty($banners)): ?>
    <div id="bannerCarousel" class="carousel slide mb-4" data-bs-ride="carousel">
        <div class="carousel-inner rounded-4 overflow-hidden">
            <?php foreach ($banners as $i => $banner): ?>
            <div class="carousel-item <?= $i == 0 ? 'active' : '' ?>">
                <?php if (!empty($banner['image_path']) && file_exists(__DIR__ . '/../../../public/' . $banner['image_path'])): ?>
                <img src="/bustan/public/<?= e($banner['image_path']) ?>" class="d-block w-100" style="height:250px;object-fit:cover;" alt="<?= e($banner['title']) ?>">
                <?php else: ?>
                <div class="d-block w-100 bg-success d-flex align-items-center justify-content-center" style="height:250px;">
                    <h3 class="text-white"><?= e($banner['title']) ?></h3>
                </div>
                <?php endif; ?>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
    <?php endif; ?>

    <!-- Restaurant Status -->
    <?php if ($restaurantStatus === 'closed'): ?>
    <div class="alert alert-warning text-center">
        <i class="bi bi-lock-fill"></i> 
        <strong>المطعم مغلق حالياً</strong>
        <?php if ($nextOpenTime): ?>
            <br>وقت الفتح القادم: <?= e($nextOpenTime) ?>
        <?php endif; ?>
    </div>
    <?php endif; ?>

    <!-- Offers -->
    <?php if (!empty($offers)): ?>
    <div class="row mb-4">
        <?php foreach ($offers as $offer): ?>
        <div class="col-md-4 mb-3">
            <div class="card text-white" style="background: linear-gradient(135deg, #40916c, #52b788);">
                <div class="card-body">
                    <h5><?= e($offer['title']) ?></h5>
                    <p><?= e($offer['sub_title'] ?? '') ?></p>
                </div>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
    <?php endif; ?>

    <!-- Categories -->
    <div class="d-flex overflow-auto mb-4 pb-2">
        <?php foreach ($categories as $cat): ?>
        <a href="#cat-<?= $cat['id'] ?>" class="btn btn-outline-success rounded-pill me-2 px-4">
            <?= e($cat['name']) ?>
        </a>
        <?php endforeach; ?>
    </div>

    <!-- Products by Category -->
    <?php foreach ($categories as $cat): ?>
        <?php if (!empty($products[$cat['id']])): ?>
        <h3 id="cat-<?= $cat['id'] ?>" class="mb-3 border-bottom pb-2">
            <i class="bi bi-shop"></i> <?= e($cat['name']) ?>
        </h3>
        <div class="row">
            <?php foreach ($products[$cat['id']] as $product): ?>
            <div class="col-md-4 col-lg-3 mb-4">
                <div class="card product-card h-100" onclick="addToCart(<?= $product['id'] ?>)">
                    <?php if (!empty($product['image']) && file_exists(__DIR__ . '/../../../public/' . $product['image'])): ?>
                    <img src="/bustan/public/<?= e($product['image']) ?>" class="product-img" alt="<?= e($product['name']) ?>">
                    <?php else: ?>
                    <div class="product-img bg-light d-flex align-items-center justify-content-center">
                        <i class="bi bi-image text-success" style="font-size:3rem;"></i>
                    </div>
                    <?php endif; ?>
                    <div class="card-body">
                        <h5 class="card-title"><?= e($product['name']) ?></h5>
                        <p class="card-text text-muted small"><?= e(mb_substr($product['description'] ?? '', 0, 60)) ?>...</p>
                        <div class="d-flex justify-content-between align-items-center">
                            <span class="h5 text-success mb-0"><?= format_money($product['price']) ?></span>
                            <button class="btn btn-success btn-sm rounded-circle">
                                <i class="bi bi-plus-lg"></i>
                            </button>
                        </div>
                        <?php if ($product['opt1']): ?>
                        <small class="text-muted"><?= e($product['opt1']) ?> +<?= format_money($product['price1']) ?></small>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
        <?php endif; ?>
    <?php endforeach; ?>

    <!-- Stories -->
    <?php if (!empty($stories)): ?>
    <h3 class="mt-5 mb-3"><i class="bi bi-book"></i> حكايات الزبائن</h3>
    <div class="row">
        <?php foreach ($stories as $story): ?>
        <div class="col-md-3 mb-3">
            <div class="card">
                <?php if (!empty($story['image_path']) && file_exists(__DIR__ . '/../../../public/' . $story['image_path'])): ?>
                <img src="/bustan/public/<?= e($story['image_path']) ?>" class="card-img-top" style="height:150px;object-fit:cover;" alt="">
                <?php else: ?>
                <div class="card-img-top bg-light d-flex align-items-center justify-content-center" style="height:150px;">
                    <i class="bi bi-person text-success" style="font-size:2rem;"></i>
                </div>
                <?php endif; ?>
                <div class="card-body">
                    <p class="card-text small"><?= e(mb_substr($story['story_text'], 0, 80)) ?>...</p>
                    <small class="text-muted">@<?= e($story['instagram_handle']) ?></small>
                </div>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
    <?php endif; ?>
</div>

<!-- Cart Modal -->
<div class="modal fade" id="cartModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">السلة</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body" id="cartItems"></div>
            <div class="modal-footer">
                <div class="w-100">
                    <div class="mb-2">
                        <input type="text" id="customerName" class="form-control" placeholder="الاسم الكامل">
                    </div>
                    <div class="mb-2">
                        <input type="tel" id="customerPhone" class="form-control" placeholder="رقم الهاتف (07XXXXXXXXX)">
                    </div>
                    <div class="mb-2">
                        <select id="orderType" class="form-select">
                            <option value="delivery">توصيل</option>
                            <option value="hall">صالة</option>
                        </select>
                    </div>
                    <div class="mb-2" id="locationField">
                        <select id="locationId" class="form-select">
                            <option value="">اختر المنطقة</option>
                        </select>
                    </div>
                    <div class="mb-2">
                        <textarea id="exactAddress" class="form-control" placeholder="العنوان الدقيق"></textarea>
                    </div>
                    <div class="d-flex justify-content-between align-items-center">
                        <h5 id="cartTotal">0 د.ع</h5>
                        <button class="btn btn-success" onclick="submitOrder()">
                            <i class="bi bi-send"></i> إرسال الطلب
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Floating Cart Button -->
<button class="btn btn-success btn-lg rounded-circle position-fixed" style="bottom:20px;left:20px;z-index:1000;" onclick="showCart()">
    <i class="bi bi-cart3"></i>
    <span class="badge bg-danger rounded-circle position-absolute" id="cartCount" style="top:-5px;right:-5px;">0</span>
</button>

<script>
let cart = [];

function addToCart(productId) {
    cart.push({id: productId, qty: 1});
    updateCartUI();
}

function updateCartUI() {
    document.getElementById('cartCount').textContent = cart.length;
}

function showCart() {
    new bootstrap.Modal(document.getElementById('cartModal')).show();
}

function submitOrder() {
    const data = {
        cart: cart,
        customer_name: document.getElementById('customerName').value,
        phone: document.getElementById('customerPhone').value,
        order_type: document.getElementById('orderType').value,
        location_id: document.getElementById('locationId').value,
        exact_address: document.getElementById('exactAddress').value,
        payment_method: 'cash'
    };

    fetch('/bustan/public/api/order', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify(data)
    })
    .then(r => r.json())
    .then(res => {
        if (res.status === 'success') {
            alert('تم إرسال الطلب بنجاح! رقم الطلب: ' + res.order_id);
            cart = [];
            updateCartUI();
            bootstrap.Modal.getInstance(document.getElementById('cartModal')).hide();
        } else {
            alert(res.message);
        }
    });
}
</script>
