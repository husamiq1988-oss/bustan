<?php $layout = 'admin'; ?>
<div class="row">
    <div class="col-12">
        <h2><i class="bi bi-cash-stack"></i> كاشير البستان</h2>
    </div>
</div>

<div class="row mt-4">
    <div class="col-md-8">
        <div class="card">
            <div class="card-header"><i class="bi bi-receipt"></i> طلبات اليوم</div>
            <div class="card-body">
                <?php if (empty($orders)): ?>
                    <p class="text-muted text-center py-4">لا توجد طلبات اليوم</p>
                <?php else: ?>
                <div class="table-responsive">
                    <table class="table">
                        <thead><tr><th>#</th><th>الزبون</th><th>المبلغ</th><th>الدفع</th><th>الحالة</th><th>عمليات</th></tr></thead>
                        <tbody>
                            <?php foreach ($orders as $order): ?>
                            <tr>
                                <td><?= $order['id'] ?></td>
                                <td><?= e($order['customer_name']) ?></td>
                                <td><?= format_money($order['total_amount']) ?></td>
                                <td><span class="badge bg-<?= $order['payment_method'] === 'wallet' ? 'info' : 'secondary' ?>"><?= $order['payment_method'] === 'wallet' ? 'محفظة' : 'كاش' ?></span></td>
                                <td><span class="badge badge-<?= $order['payment_status'] ?>"><?= $order['payment_status'] ?></span></td>
                                <td>
                                    <?php if ($order['payment_status'] === 'pending'): ?>
                                    <form method="POST" action="/cashier/process" class="d-inline">
                                        <?= csrf_field() ?>
                                        <input type="hidden" name="order_id" value="<?= $order['id'] ?>">
                                        <button class="btn btn-success btn-sm"><i class="bi bi-check"></i> تأكيد</button>
                                    </form>
                                    <?php else: ?>
                                    <span class="text-success"><i class="bi bi-check-circle"></i></span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card mb-3">
            <div class="card-header"><i class="bi bi-wallet2"></i> رصيد الصندوق</div>
            <div class="card-body text-center">
                <h2 class="text-success"><?= format_money($cashierBalance) ?></h2>
                <button class="btn btn-outline-danger btn-sm w-100 mt-2">تصفير واستلام</button>
            </div>
        </div>
        <div class="card">
            <div class="card-header"><i class="bi bi-ticket-perforated"></i> كوبونات فعالة</div>
            <div class="card-body">
                <?php if (empty($coupons)): ?>
                    <p class="text-muted">لا توجد كوبونات</p>
                <?php else: ?>
                    <?php foreach ($coupons as $coupon): ?>
                    <div class="alert alert-success py-2">
                        <strong><?= e($coupon['coupon_code']) ?></strong>
                        <span class="badge bg-danger"><?= $coupon['discount_percent'] ?>%</span>
                    </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
