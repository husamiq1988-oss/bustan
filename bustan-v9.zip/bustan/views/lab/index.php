<?php $layout = 'admin'; ?>
<div class="row">
    <div class="col-12">
        <h2><i class="bi bi-flask"></i> لوحة تحكم المختبر</h2>
    </div>
</div>

<div class="row mt-4">
    <div class="col-md-8">
        <div class="card">
            <div class="card-header"><i class="bi bi-list"></i> الوصفات المخبرية</div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead><tr><th>الوصفة</th><th>المادة الأساسية</th><th>الحالة</th><th>الكمية</th><th>الحرارة</th><th>عمليات</th></tr></thead>
                        <tbody>
                            <?php foreach ($recipes as $recipe): ?>
                            <tr class="<?= !($recipe['has_ingredients'] ?? false) ? 'table-warning' : '' ?>">
                                <td><strong><?= e($recipe['recipe_name']) ?></strong></td>
                                <td><?= e($recipe['main_ingredient_name'] ?? '') ?></td>
                                <td>
                                    <?php if ($recipe['has_ingredients'] ?? false): ?>
                                    <span class="badge bg-success">مكتملة</span>
                                    <?php else: ?>
                                    <span class="badge bg-warning">ناقصة</span>
                                    <?php endif; ?>
                                </td>
                                <td><?= $recipe['batch_capacity'] ?> كغم</td>
                                <td><?= $recipe['temp_top'] ?>°C / <?= $recipe['temp_bottom'] ?>°C</td>
                                <td>
                                    <button class="btn btn-sm btn-success" data-bs-toggle="modal" data-bs-target="#executeModal<?= $recipe['id'] ?>">
                                        <i class="bi bi-play-fill"></i> تنفيذ
                                    </button>
                                </td>
                            </tr>
                            <!-- Execute Modal -->
                            <div class="modal fade" id="executeModal<?= $recipe['id'] ?>">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header"><h5>تنفيذ وصفة: <?= e($recipe['recipe_name']) ?></h5><button class="btn-close" data-bs-dismiss="modal"></button></div>
                                        <form method="POST" action="/lab/execute">
                                            <?= csrf_field() ?>
                                            <input type="hidden" name="recipe_id" value="<?= $recipe['id'] ?>">
                                            <div class="modal-body">
                                                <div class="mb-3">
                                                    <label>الكمية (كغم)</label>
                                                    <input type="number" step="0.01" name="qty" class="form-control" value="<?= $recipe['batch_capacity'] ?>" required>
                                                </div>
                                                <div class="alert alert-info">
                                                    <strong>المواصفات:</strong><br>
                                                    <small>العجن: <?= $recipe['kneading_time'] ?> دقيقة</small><br>
                                                    <small>التخمير: <?= $recipe['fermentation_time'] ?> دقيقة</small><br>
                                                    <small>الخبز: <?= $recipe['baking_time'] ?> دقيقة</small><br>
                                                    <small>الحرارة العلوية: <?= $recipe['temp_top'] ?>°C</small><br>
                                                    <small>الحرارة السفلية: <?= $recipe['temp_bottom'] ?>°C</small><br>
                                                    <small>المروحة: <?= $recipe['has_fan'] ? 'نعم' : 'لا' ?></small>
                                                </div>
                                            </div>
                                            <div class="modal-footer">
                                                <button class="btn btn-secondary" data-bs-dismiss="modal">إلغاء</button>
                                                <button class="btn btn-success" type="submit"><i class="bi bi-play-fill"></i> تنفيذ</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card mb-3">
            <div class="card-header bg-warning"><i class="bi bi-exclamation-triangle"></i> تنبيهات المخزون</div>
            <div class="card-body">
                <?php if (empty($lowStock)): ?>
                    <p class="text-muted">لا توجد تنبيهات</p>
                <?php else: ?>
                    <?php foreach ($lowStock as $item): ?>
                    <div class="alert alert-danger py-2 mb-2">
                        <strong><?= e($item['item_name']) ?></strong><br>
                        <small>الكمية: <?= $item['current_qty'] ?> / الحد: <?= $item['alert_level'] ?></small>
                    </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>
        <div class="card">
            <div class="card-header"><i class="bi bi-clock-history"></i> سجل التنفيذ اليوم</div>
            <div class="card-body">
                <?php if (empty($logs)): ?>
                    <p class="text-muted">لا توجد سجلات</p>
                <?php else: ?>
                    <?php foreach ($logs as $log): ?>
                    <div class="d-flex justify-content-between mb-2 pb-2 border-bottom">
                        <div>
                            <strong><?= e($log['recipe_name']) ?></strong><br>
                            <small class="text-muted"><?= $log['executed_qty'] ?> كغم</small>
                        </div>
                        <a href="/lab/cancel/<?= $log['id'] ?>" class="btn btn-sm btn-danger" onclick="return confirm('هل أنت متأكد من الإلغاء؟')">
                            <i class="bi bi-x-lg"></i>
                        </a>
                    </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
