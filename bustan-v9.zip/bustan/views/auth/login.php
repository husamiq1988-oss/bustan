<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-5">
            <div class="card shadow-lg mt-5">
                <div class="card-body p-5">
                    <div class="text-center mb-4">
                        <h2 class="text-success">🌿 البستان</h2>
                        <p class="text-muted">تسجيل الدخول للنظام</p>
                    </div>

                    <?php if (!empty($_SESSION['errors'])): ?>
                        <div class="alert alert-danger">
                            <?php foreach ($_SESSION['errors'] as $err): ?>
                                <div><i class="bi bi-exclamation-triangle"></i> <?= e($err) ?></div>
                            <?php endforeach; unset($_SESSION['errors']); ?>
                        </div>
                    <?php endif; ?>

                    <form method="POST" action="/login">
                        <?= csrf_field() ?>
                        <div class="mb-3">
                            <label class="form-label">رقم الهاتف</label>
                            <input type="tel" name="phone" class="form-control form-control-lg" 
                                   placeholder="07XXXXXXXXX" value="<?= old('phone') ?>" required>
                        </div>
                        <div class="mb-4">
                            <label class="form-label">كلمة المرور (إن وجدت)</label>
                            <input type="password" name="password" class="form-control form-control-lg">
                        </div>
                        <button type="submit" class="btn btn-primary btn-lg w-100">
                            <i class="bi bi-box-arrow-in-left"></i> دخول
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
