<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= e($title ?? 'مطعم البستان') ?></title>
    <link href="/bustan/public/assets/css/bootstrap.rtl.min.css" rel="stylesheet">
    <link href="/bustan/public/assets/css/bootstrap-icons.min.css" rel="stylesheet">
    <style>
        :root { --primary: #2d6a4f; --secondary: #40916c; --accent: #52b788; --light: #d8f3dc; --dark: #1b4332; }
        body { font-family: 'Segoe UI', Tahoma, sans-serif; background: #f8f9fa; }
        .navbar { background: linear-gradient(135deg, var(--dark), var(--primary)) !important; }
        .navbar-brand { font-weight: bold; font-size: 1.5rem; }
        .btn-primary { background: var(--primary); border-color: var(--primary); }
        .btn-primary:hover { background: var(--dark); border-color: var(--dark); }
        .card { border: none; border-radius: 15px; box-shadow: 0 2px 15px rgba(0,0,0,0.08); }
        .card-header { background: var(--light); border-bottom: 2px solid var(--accent); font-weight: bold; }
        .stat-card { background: linear-gradient(135deg, var(--primary), var(--secondary)); color: white; }
        .stat-card i { font-size: 2.5rem; opacity: 0.8; }
        .badge-status { padding: 0.5em 1em; border-radius: 20px; }
        .badge-pending { background: #ffc107; color: #000; }
        .badge-preparing { background: #17a2b8; color: #fff; }
        .badge-completed { background: #28a745; color: #fff; }
        .badge-cancelled { background: #dc3545; color: #fff; }
        .sidebar { min-height: 100vh; background: var(--dark); }
        .sidebar .nav-link { color: rgba(255,255,255,0.8); padding: 0.8rem 1rem; border-radius: 8px; margin: 0.2rem 0; }
        .sidebar .nav-link:hover, .sidebar .nav-link.active { background: var(--primary); color: white; }
        .sidebar .nav-link i { margin-left: 0.5rem; }
        .product-card { transition: transform 0.2s; cursor: pointer; }
        .product-card:hover { transform: translateY(-5px); }
        .product-img { height: 180px; object-fit: cover; border-radius: 10px 10px 0 0; }
        .order-item { border-right: 4px solid var(--accent); padding-right: 1rem; margin-bottom: 1rem; }
        .flash-message { position: fixed; top: 20px; left: 20px; z-index: 9999; min-width: 300px; }
        .low-stock { border-right: 4px solid #dc3545 !important; }
        @media (max-width: 768px) { .sidebar { min-height: auto; } .stat-card i { font-size: 1.5rem; } }
    </style>
</head>
<body>
    <!-- Flash Messages -->
    <?php if ($msg = flash('success')): ?>
    <div class="alert alert-success flash-message alert-dismissible fade show">
        <i class="bi bi-check-circle"></i> <?= e($msg) ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
    <?php endif; ?>
    <?php if ($msg = flash('error')): ?>
    <div class="alert alert-danger flash-message alert-dismissible fade show">
        <i class="bi bi-exclamation-circle"></i> <?= e($msg) ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
    <?php endif; ?>

    <?php if (isset($layout) && $layout === 'admin'): ?>
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-2 sidebar p-0">
                    <div class="p-3 text-white text-center">
                        <h4>البستان</h4>
                        <small>نظام الإدارة</small>
                    </div>
                    <nav class="nav flex-column px-2">
                        <a class="nav-link" href="/bustan/public/dashboard"><i class="bi bi-speedometer2"></i> الرئيسية</a>
                        <a class="nav-link" href="/bustan/public/kitchen"><i class="bi bi-fire"></i> المطبخ</a>
                        <a class="nav-link" href="/bustan/public/cashier"><i class="bi bi-cash-stack"></i> الكاشير</a>
                        <a class="nav-link" href="/bustan/public/admin/orders"><i class="bi bi-cart3"></i> الطلبات</a>
                        <a class="nav-link" href="/bustan/public/inventory"><i class="bi bi-box-seam"></i> المخزون</a>
                        <a class="nav-link" href="/bustan/public/recipes"><i class="bi bi-journal-text"></i> الوصفات</a>
                        <a class="nav-link" href="/bustan/public/assets"><i class="bi bi-lightning"></i> الأصول</a>
                        <a class="nav-link" href="/bustan/public/generator"><i class="bi bi-plugin"></i> المولد</a>
                        <a class="nav-link" href="/bustan/public/reports"><i class="bi bi-graph-up"></i> التقارير</a>
                        <a class="nav-link" href="/bustan/public/admin/users"><i class="bi bi-people"></i> الزبائن</a>
                        <a class="nav-link" href="/bustan/public/admin/wheel"><i class="bi bi-circle"></i> عجلة الحظ</a>
                        <a class="nav-link" href="/bustan/public/admin/chats"><i class="bi bi-chat-dots"></i> الدعم</a>
                        <a class="nav-link" href="/bustan/public/admin/settings"><i class="bi bi-gear"></i> الإعدادات</a>
                        <a class="nav-link text-danger" href="/bustan/public/logout"><i class="bi bi-box-arrow-right"></i> خروج</a>
                    </nav>
                </div>
                <div class="col-md-10 p-4">
                    <?= $content ?? '' ?>
                </div>
            </div>
        </div>
    <?php else: ?>
        <nav class="navbar navbar-expand-lg navbar-dark sticky-top">
            <div class="container">
                <a class="navbar-brand" href="/bustan/public/">البستان</a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarNav">
                    <ul class="navbar-nav me-auto">
                        <li class="nav-item"><a class="nav-link" href="/bustan/public/">المنيو</a></li>
                        <li class="nav-item"><a class="nav-link" href="/bustan/public/wheel">عجلة الحظ</a></li>
                    </ul>
                    <ul class="navbar-nav">
                        <?php if (\Core\Auth::check()): ?>
                            <li class="nav-item"><a class="nav-link" href="/bustan/public/dashboard"><i class="bi bi-speedometer2"></i> لوحة التحكم</a></li>
                            <li class="nav-item"><a class="nav-link" href="/bustan/public/logout"><i class="bi bi-box-arrow-right"></i> خروج</a></li>
                        <?php else: ?>
                            <li class="nav-item"><a class="nav-link" href="/bustan/public/login"><i class="bi bi-person"></i> دخول</a></li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </nav>
        <main class="py-4">
            <?= $content ?? '' ?>
        </main>
        <footer class="bg-dark text-white text-center py-3 mt-5">
            <small>مطعم البستان 2026 - جميع الحقوق محفوظة</small>
        </footer>
    <?php endif; ?>

    <script src="/bustan/public/assets/js/bootstrap.bundle.min.js"></script>
    <script>
        setTimeout(() => {
            document.querySelectorAll('.flash-message').forEach(el => {
                el.classList.remove('show');
                setTimeout(() => el.remove(), 300);
            });
        }, 5000);
    </script>
</body>
</html>
