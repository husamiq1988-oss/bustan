<?php $layout = 'admin'; ?>
<div class="row">
    <div class="col-12">
        <h2><i class="bi bi-people"></i> إدارة الزبائن</h2>
    </div>
</div>

<div class="row mt-4">
    <div class="col-12">
        <div class="card">
            <div class="card-header d-flex justify-content-between">
                <span><i class="bi bi-list"></i> قائمة الزبائن</span>
                <span class="badge bg-success"><?= count($users) ?> زبون</span>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead><tr><th>#</th><th>الاسم</th><th>الهاتف</th><th>الرصيد</th><th>النقاط</th><th>تاريخ التسجيل</th><th>عمليات</th></tr></thead>
                        <tbody>
                            <?php foreach ($users as $user): ?>
                            <tr>
                                <td><?= $user['id'] ?></td>
                                <td><?= e($user['name'] ?? $user['full_name'] ?? '') ?></td>
                                <td><?= e($user['phone']) ?></td>
                                <td><?= format_money($user['balance'] ?? $user['wallet_balance'] ?? 0) ?></td>
                                <td><span class="badge bg-warning"><?= $user['points'] ?? 0 ?></span></td>
                                <td><small><?= format_date($user['created_at']) ?></small></td>
                                <td>
                                    <button class="btn btn-sm btn-primary" data-bs-toggle="modal" data-bs-target="#editModal<?= $user['id'] ?>">
                                        <i class="bi bi-pencil"></i>
                                    </button>
                                </td>
                            </tr>
                            <!-- Edit Modal -->
                            <div class="modal fade" id="editModal<?= $user['id'] ?>">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header"><h5>تعديل زبون</h5><button class="btn-close" data-bs-dismiss="modal"></button></div>
                                        <form method="POST" action="/admin/users/update">
                                            <?= csrf_field() ?>
                                            <input type="hidden" name="user_id" value="<?= $user['id'] ?>">
                                            <div class="modal-body">
                                                <div class="mb-3"><label>الرصيد</label><input type="number" step="0.01" name="new_balance" class="form-control" value="<?= $user['balance'] ?? $user['wallet_balance'] ?? 0 ?>"></div>
                                                <div class="mb-3"><label>النقاط</label><input type="number" name="new_points" class="form-control" value="<?= $user['points'] ?? 0 ?>"></div>
                                            </div>
                                            <div class="modal-footer">
                                                <button class="btn btn-secondary" data-bs-dismiss="modal">إلغاء</button>
                                                <button class="btn btn-success" type="submit">حفظ</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
