<?php $layout = 'admin'; ?>
<div class="row">
    <div class="col-12">
        <h2><i class="bi bi-cash-coin"></i> سجل المصروفات</h2>
    </div>
</div>

<div class="row mt-4">
    <div class="col-md-8">
        <div class="card">
            <div class="card-header"><i class="bi bi-list"></i> المصروفات</div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead><tr><th>#</th><th>العنوان</th><th>المبلغ</th><th>الفئة</th><th>التاريخ</th><th>ملاحظات</th></tr></thead>
                        <tbody>
                            <?php foreach ($expenses as $expense): ?>
                            <tr>
                                <td><?= $expense['id'] ?></td>
                                <td><?= e($expense['title']) ?></td>
                                <td><?= format_money($expense['amount']) ?></td>
                                <td><span class="badge bg-secondary"><?= e($expense['category']) ?></span></td>
                                <td><?= e($expense['expense_date']) ?></td>
                                <td><small><?= e($expense['notes'] ?? '') ?></small></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card">
            <div class="card-header"><i class="bi bi-plus-lg"></i> إضافة مصروف</div>
            <div class="card-body">
                <form method="POST" action="/admin/expenses/store">
                    <?= csrf_field() ?>
                    <div class="mb-3"><label>العنوان</label><input type="text" name="title" class="form-control" required></div>
                    <div class="mb-3"><label>المبلغ</label><input type="number" step="0.01" name="amount" class="form-control" required></div>
                    <div class="mb-3"><label>الفئة</label><select name="category" class="form-select">
                        <option value="رواتب">رواتب</option>
                        <option value="مشتريات">مشتريات</option>
                        <option value="صيانة">صيانة</option>
                        <option value="كهرباء">كهرباء</option>
                        <option value="أخرى">أخرى</option>
                    </select></div>
                    <div class="mb-3"><label>التاريخ</label><input type="date" name="expense_date" class="form-control" value="<?= date('Y-m-d') ?>"></div>
                    <div class="mb-3"><label>ملاحظات</label><textarea name="notes" class="form-control" rows="2"></textarea></div>
                    <button class="btn btn-success w-100" type="submit">إضافة</button>
                </form>
            </div>
        </div>
    </div>
</div>
