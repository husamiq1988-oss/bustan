<?php $layout = 'admin'; ?>
<div class="row">
    <div class="col-12">
        <h2><i class="bi bi-chat-dots"></i> شات الدعم الفني</h2>
    </div>
</div>

<div class="row mt-4">
    <div class="col-md-4">
        <div class="card">
            <div class="card-header"><i class="bi bi-list"></i> المحادثات</div>
            <div class="list-group list-group-flush">
                <?php foreach ($conversations as $conv): ?>
                <a href="#" class="list-group-item list-group-item-action d-flex justify-content-between align-items-center" onclick="loadChat('<?= e($conv['user_phone']) ?>')">
                    <div>
                        <strong><?= e($conv['customer_name'] ?? $conv['user_phone']) ?></strong><br>
                        <small class="text-muted"><?= format_date($conv['last_message']) ?></small>
                    </div>
                    <?php if ($conv['unread_count'] > 0): ?>
                    <span class="badge bg-danger rounded-pill"><?= $conv['unread_count'] ?></span>
                    <?php endif; ?>
                </a>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
    <div class="col-md-8">
        <div class="card">
            <div class="card-header"><i class="bi bi-chat"></i> المحادثة</div>
            <div class="card-body" id="chatMessages" style="height:400px;overflow-y:auto;">
                <p class="text-muted text-center">اختر محادثة لعرض الرسائل</p>
            </div>
            <div class="card-footer">
                <div class="input-group">
                    <input type="text" id="replyMessage" class="form-control" placeholder="اكتب ردك...">
                    <button class="btn btn-success" onclick="sendReply()"><i class="bi bi-send"></i></button>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
let currentPhone = '';

function loadChat(phone) {
    currentPhone = phone;
    fetch('/api/chat?phone=' + encodeURIComponent(phone))
    .then(r => r.json())
    .then(res => {
        if (res.status === 'success') {
            const container = document.getElementById('chatMessages');
            container.innerHTML = '';
            res.messages.forEach(msg => {
                const div = document.createElement('div');
                div.className = 'mb-2 ' + (msg.sender_type === 'admin' ? 'text-start' : 'text-end');
                div.innerHTML = `<div class="d-inline-block p-2 rounded ${msg.sender_type === 'admin' ? 'bg-success text-white' : 'bg-light'}">${msg.message_text}<br><small class="opacity-75">${msg.created_at}</small></div>`;
                container.appendChild(div);
            });
            container.scrollTop = container.scrollHeight;
        }
    });
}

function sendReply() {
    const msg = document.getElementById('replyMessage').value;
    if (!msg || !currentPhone) return;

    fetch('/api/chat/reply', {
        method: 'POST',
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        body: 'phone=' + encodeURIComponent(currentPhone) + '&message=' + encodeURIComponent(msg) + '&_token=<?= $_SESSION['csrf_token'] ?? '' ?>'
    })
    .then(r => r.json())
    .then(res => {
        if (res.status === 'success') {
            document.getElementById('replyMessage').value = '';
            loadChat(currentPhone);
        }
    });
}
</script>
