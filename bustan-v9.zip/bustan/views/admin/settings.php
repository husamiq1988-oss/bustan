<?php $layout = 'admin'; ?>
<div class="row">
    <div class="col-12">
        <h2><i class="bi bi-gear"></i> إعدادات النظام</h2>
    </div>
</div>

<div class="row mt-4">
    <div class="col-md-8">
        <div class="card">
            <div class="card-header"><i class="bi bi-sliders"></i> الإعدادات العامة</div>
            <div class="card-body">
                <form method="POST" action="/admin/settings">
                    <?= csrf_field() ?>
                    <div class="mb-3">
                        <label>حالة المطعم</label>
                        <select name="setting_restaurant_status" class="form-select">
                            <option value="open" <?= ($settings['restaurant_status'] ?? '') === 'open' ? 'selected' : '' ?>>مفتوح</option>
                            <option value="closed" <?= ($settings['restaurant_status'] ?? '') === 'closed' ? 'selected' : '' ?>>مغلق</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label>وقت الفتح القادم</label>
                        <input type="text" name="setting_next_open_time" class="form-control" value="<?= e($settings['next_open_time'] ?? '') ?>" placeholder="مثال: 6:00 صباحاً">
                    </div>
                    <div class="mb-3">
                        <label>رصيد الصندوق الافتراضي</label>
                        <input type="number" step="0.01" name="setting_cashier_balance" class="form-control" value="<?= e($settings['cashier_balance'] ?? '0') ?>">
                    </div>
                    <div class="mb-3">
                        <label>رسالة الترحيب</label>
                        <textarea name="setting_welcome_message" class="form-control" rows="3"><?= e($settings['welcome_message'] ?? 'مرحباً بكم في مطعم البستان') ?></textarea>
                    </div>
                    <div class="mb-3">
                        <label>رقم واتساب الدعم</label>
                        <input type="text" name="setting_whatsapp_support" class="form-control" value="<?= e($settings['whatsapp_support'] ?? '') ?>" placeholder="07XXXXXXXXX">
                    </div>
                    <div class="mb-3">
                        <label>رسوم التوصيل الافتراضية</label>
                        <input type="number" step="0.01" name="setting_default_delivery_fee" class="form-control" value="<?= e($settings['default_delivery_fee'] ?? '0') ?>">
                    </div>
                    <button class="btn btn-success" type="submit"><i class="bi bi-save"></i> حفظ الإعدادات</button>
                </form>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card">
            <div class="card-header"><i class="bi bi-info-circle"></i> معلومات النظام</div>
            <div class="card-body">
                <p><strong>الإصدار:</strong> 2.0</p>
                <p><strong>التاريخ:</strong> <?= date('Y-m-d') ?></p>
                <p><strong>PHP:</strong> <?= phpversion() ?></p>
                <hr>
                <h6>الجداول:</h6>
                <span class="badge bg-success">35+ جدول</span>
                <hr>
                <h6>الملفات:</h6>
                <span class="badge bg-primary">90+ ملف</span>
            </div>
        </div>
    </div>
</div>
