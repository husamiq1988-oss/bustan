<?php $layout = 'admin'; ?>
<div class="row">
    <div class="col-12">
        <h2><i class="bi bi-book"></i> حكايات الزبائن</h2>
    </div>
</div>

<div class="row mt-4">
    <div class="col-md-6">
        <div class="card">
            <div class="card-header bg-warning"><i class="bi bi-clock"></i> بانتظار الموافقة</div>
            <div class="card-body">
                <?php if (empty($pending)): ?>
                    <p class="text-muted">لا توجد قصص معلقة</p>
                <?php else: ?>
                    <?php foreach ($pending as $story): ?>
                    <div class="card mb-3">
                        <img src="<?= e($story['image_path'] ?? '') ?>" class="card-img-top" style="height:150px;object-fit:cover;" alt="">
                        <div class="card-body">
                            <h6><?= e($story['user_name']) ?> <small class="text-muted">@<?= e($story['instagram_handle']) ?></small></h6>
                            <p class="card-text"><?= e($story['story_text']) ?></p>
                            <div class="btn-group">
                                <a href="/admin/stories/approve/<?= $story['id'] ?>" class="btn btn-success btn-sm"><i class="bi bi-check"></i> موافقة</a>
                                <a href="/admin/stories/feature/<?= $story['id'] ?>" class="btn btn-primary btn-sm"><i class="bi bi-star"></i> تمييز</a>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <div class="col-md-6">
        <div class="card">
            <div class="card-header bg-success text-white"><i class="bi bi-check-circle"></i> القصص المعتمدة</div>
            <div class="card-body">
                <?php if (empty($approved)): ?>
                    <p class="text-muted">لا توجد قصص معتمدة</p>
                <?php else: ?>
                    <?php foreach ($approved as $story): ?>
                    <div class="card mb-3">
                        <img src="<?= e($story['image_path'] ?? '') ?>" class="card-img-top" style="height:150px;object-fit:cover;" alt="">
                        <div class="card-body">
                            <h6><?= e($story['user_name']) ?> <small class="text-muted">@<?= e($story['instagram_handle']) ?></small></h6>
                            <p class="card-text"><?= e($story['story_text']) ?></p>
                            <?php if ($story['is_featured_cover']): ?>
                            <span class="badge bg-warning"><i class="bi bi-star-fill"></i> غلاف مميز</span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
