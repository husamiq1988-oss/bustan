<?php $layout = 'admin'; ?>
<div class="row">
    <div class="col-12">
        <h2><i class="bi bi-circle"></i> إعدادات عجلة الحظ</h2>
    </div>
</div>

<div class="row mt-4">
    <div class="col-md-8">
        <div class="card">
            <div class="card-header d-flex justify-content-between">
                <span><i class="bi bi-list"></i> الجوائز</span>
                <button class="btn btn-success btn-sm" data-bs-toggle="modal" data-bs-target="#addPrizeModal"><i class="bi bi-plus-lg"></i> جائزة جديدة</button>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead><tr><th>النوع</th><th>القيمة</th><th>الاسم</th><th>الوزن</th><th>خصم %</th><th>واتساب</th></tr></thead>
                        <tbody>
                            <?php foreach ($prizes as $prize): ?>
                            <tr>
                                <td><span class="badge bg-<?= $prize['prize_type'] === 'discount' ? 'danger' : ($prize['prize_type'] === 'points' ? 'warning' : 'success') ?>"><?= e($prize['prize_type']) ?></span></td>
                                <td><?= e($prize['prize_value']) ?></td>
                                <td><?= e($prize['label']) ?></td>
                                <td><?= $prize['weight'] ?></td>
                                <td><?= $prize['discount_percent'] ?>%</td>
                                <td><?= $prize['whatsapp'] ? '<i class="bi bi-check-circle text-success"></i>' : '<i class="bi bi-x-circle text-muted"></i>' ?></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card">
            <div class="card-header"><i class="bi bi-trophy"></i> آخر الفائزين</div>
            <div class="card-body">
                <?php if (empty($winners)): ?>
                    <p class="text-muted">لا يوجد فائزون بعد</p>
                <?php else: ?>
                    <?php foreach ($winners as $winner): ?>
                    <div class="d-flex justify-content-between align-items-center mb-2 pb-2 border-bottom">
                        <div>
                            <strong><?= e($winner['phone']) ?></strong><br>
                            <small class="text-muted"><?= e($winner['prize_label']) ?></small>
                        </div>
                        <span class="badge bg-<?= $winner['is_delivered'] ? 'success' : 'warning' ?>"><?= $winner['is_delivered'] ? 'تم التسليم' : 'معلق' ?></span>
                    </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<!-- Add Prize Modal -->
<div class="modal fade" id="addPrizeModal">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header"><h5>إضافة جائزة</h5><button class="btn-close" data-bs-dismiss="modal"></button></div>
            <form method="POST" action="/admin/wheel/prize">
                <?= csrf_field() ?>
                <div class="modal-body">
                    <div class="mb-3"><label>النوع</label><select name="prize_type" class="form-select">
                        <option value="discount">خصم</option>
                        <option value="points">نقاط</option>
                        <option value="gift">هدية</option>
                    </select></div>
                    <div class="mb-3"><label>القيمة</label><input type="text" name="prize_value" class="form-control" required></div>
                    <div class="mb-3"><label>الاسم المعروض</label><input type="text" name="label" class="form-control" required></div>
                    <div class="mb-3"><label>الوزن (احتمالية)</label><input type="number" name="weight" class="form-control" value="1" required></div>
                    <div class="mb-3"><label>نسبة الخصم</label><input type="number" name="discount_percent" class="form-control" value="0"></div>
                    <div class="mb-3"><label>واتساب</label><select name="whatsapp" class="form-select"><option value="0">لا</option><option value="1">نعم</option></select></div>
                </div>
                <div class="modal-footer">
                    <button class="btn btn-secondary" data-bs-dismiss="modal">إلغاء</button>
                    <button class="btn btn-success" type="submit">حفظ</button>
                </div>
            </form>
        </div>
    </div>
</div>
