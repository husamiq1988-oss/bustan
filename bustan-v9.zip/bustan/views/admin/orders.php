<?php $layout = 'admin'; ?>
<div class="row">
    <div class="col-12">
        <h2><i class="bi bi-cart3"></i> إدارة الطلبات</h2>
    </div>
</div>

<div class="row mt-4">
    <div class="col-12">
        <div class="card">
            <div class="card-header"><i class="bi bi-list"></i> جميع الطلبات</div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead><tr><th>#</th><th>الزبون</th><th>الهاتف</th><th>المجموع</th><th>التوصيل</th><th>الحالة</th><th>الدفع</th><th>الوقت</th><th>عمليات</th></tr></thead>
                        <tbody>
                            <?php foreach ($orders as $order): ?>
                            <tr>
                                <td><?= $order['id'] ?></td>
                                <td><?= e($order['customer_name']) ?></td>
                                <td><?= e($order['user_phone']) ?></td>
                                <td><?= format_money($order['total_amount']) ?></td>
                                <td><?= format_money($order['delivery_fee']) ?></td>
                                <td><span class="badge badge-<?= $order['order_status'] ?>"><?= e($order['order_status']) ?></span></td>
                                <td><span class="badge bg-<?= $order['payment_status'] === 'paid' ? 'success' : 'warning' ?>"><?= $order['payment_status'] ?></span></td>
                                <td><small><?= format_date($order['created_at']) ?></small></td>
                                <td>
                                    <select class="form-select form-select-sm" onchange="updateStatus(<?= $order['id'] ?>, this.value)">
                                        <option value="pending" <?= $order['order_status'] === 'pending' ? 'selected' : '' ?>>معلق</option>
                                        <option value="preparing" <?= $order['order_status'] === 'preparing' ? 'selected' : '' ?>>قيد التحضير</option>
                                        <option value="completed" <?= $order['order_status'] === 'completed' ? 'selected' : '' ?>>مكتمل</option>
                                        <option value="cancelled" <?= $order['order_status'] === 'cancelled' ? 'selected' : '' ?>>ملغى</option>
                                    </select>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
function updateStatus(id, status) {
    fetch('/admin/orders/status/' + id, {
        method: 'POST',
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        body: 'status=' + status + '&_token=<?= $_SESSION['csrf_token'] ?? '' ?>'
    })
    .then(r => r.json())
    .then(res => { if (res.status === 'success') location.reload(); });
}
</script>
