<?php $layout = 'admin'; ?>
<div class="row">
    <div class="col-12">
        <h2><i class="bi bi-grid"></i> إدارة الأصناف</h2>
    </div>
</div>

<div class="row mt-4">
    <div class="col-12">
        <div class="card">
            <div class="card-header d-flex justify-content-between">
                <span><i class="bi bi-list"></i> قائمة المنتجات</span>
                <button class="btn btn-success btn-sm" data-bs-toggle="modal" data-bs-target="#addProductModal">
                    <i class="bi bi-plus-lg"></i> منتج جديد
                </button>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead><tr><th>#</th><th>الصورة</th><th>الاسم</th><th>السعر</th><th>القسم</th><th>الحالة</th><th>عمليات</th></tr></thead>
                        <tbody>
                            <?php foreach ($products as $product): ?>
                            <tr>
                                <td><?= $product['id'] ?></td>
                                <td><img src="<?= e($product['image'] ?? 'assets/images/default-food.png') ?>" style="width:50px;height:50px;object-fit:cover;border-radius:8px;"></td>
                                <td><strong><?= e($product['name']) ?></strong></td>
                                <td><?= format_money($product['price']) ?></td>
                                <td><?= e($product['category_name'] ?? 'غير مصنف') ?></td>
                                <td>
                                    <span class="badge bg-<?= $product['is_available'] ? 'success' : 'secondary' ?>">
                                        <?= $product['is_available'] ? 'متاح' : 'مخفي' ?>
                                    </span>
                                </td>
                                <td>
                                    <button class="btn btn-sm btn-primary" data-bs-toggle="modal" data-bs-target="#editProduct<?= $product['id'] ?>"><i class="bi bi-pencil"></i></button>
                                    <form method="POST" action="/admin/products/toggle/<?= $product['id'] ?>" class="d-inline">
                                        <?= csrf_field() ?>
                                        <button class="btn btn-sm btn-warning"><i class="bi bi-eye<?= $product['is_available'] ? '-slash' : '' ?>"></i></button>
                                    </form>
                                    <form method="POST" action="/admin/products/delete/<?= $product['id'] ?>" class="d-inline" onsubmit="return confirm('هل أنت متأكد؟')">
                                        <?= csrf_field() ?>
                                        <button class="btn btn-sm btn-danger"><i class="bi bi-trash"></i></button>
                                    </form>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Add Product Modal -->
<div class="modal fade" id="addProductModal">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header"><h5>إضافة منتج جديد</h5><button class="btn-close" data-bs-dismiss="modal"></button></div>
            <form method="POST" action="/admin/products/store" enctype="multipart/form-data">
                <?= csrf_field() ?>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-6 mb-3"><label>اسم المنتج</label><input type="text" name="p_name" class="form-control" required></div>
                        <div class="col-md-6 mb-3"><label>السعر</label><input type="number" step="0.01" name="p_price" class="form-control" required></div>
                    </div>
                    <div class="mb-3"><label>الوصف</label><textarea name="p_desc" class="form-control" rows="2"></textarea></div>
                    <div class="mb-3"><label>القسم</label><select name="category_id" class="form-select">
                        <option value="">اختر القسم</option>
                        <?php foreach ($categories as $cat): ?>
                        <option value="<?= $cat['id'] ?>"><?= e($cat['name']) ?></option>
                        <?php endforeach; ?>
                    </select></div>
                    <div class="mb-3"><label>الصورة</label><input type="file" name="p_image" class="form-control" accept="image/*"></div>
                    <hr>
                    <h6>الخيارات الإضافية</h6>
                    <div class="row">
                        <?php for ($i = 1; $i <= 6; $i++): ?>
                        <div class="col-md-6 mb-2">
                            <input type="text" name="opt<?= $i ?>" class="form-control form-control-sm mb-1" placeholder="اسم الخيار <?= $i ?>">
                            <input type="number" step="0.01" name="price<?= $i ?>" class="form-control form-control-sm" placeholder="السعر <?= $i ?>">
                        </div>
                        <?php endfor; ?>
                    </div>
                </div>
                <div class="modal-footer">
                    <button class="btn btn-secondary" data-bs-dismiss="modal">إلغاء</button>
                    <button class="btn btn-success" type="submit">حفظ</button>
                </div>
            </form>
        </div>
    </div>
</div>
