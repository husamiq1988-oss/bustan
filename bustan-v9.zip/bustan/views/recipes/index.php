<?php $layout = 'admin'; ?>
<div class="row">
    <div class="col-12">
        <h2><i class="bi bi-journal-text"></i> إدارة الوصفات</h2>
    </div>
</div>

<div class="row mt-4">
    <div class="col-12">
        <div class="card">
            <div class="card-header d-flex justify-content-between">
                <span><i class="bi bi-list"></i> قائمة الوصفات</span>
                <a href="/recipes/create" class="btn btn-success btn-sm"><i class="bi bi-plus-lg"></i> وصفة جديدة</a>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead><tr><th>الوصفة</th><th>المادة الأساسية</th><th>الحالة</th><th>الكمية</th><th>عمليات</th></tr></thead>
                        <tbody>
                            <?php foreach ($recipes as $recipe): ?>
                            <tr>
                                <td><strong><?= e($recipe['recipe_name']) ?></strong></td>
                                <td><?= e($recipe['main_ingredient_name'] ?? 'غير محدد') ?></td>
                                <td>
                                    <?php if ($recipe['has_ingredients'] ?? false): ?>
                                    <span class="badge bg-success">مكتملة</span>
                                    <?php else: ?>
                                    <span class="badge bg-warning">ناقصة</span>
                                    <?php endif; ?>
                                </td>
                                <td><?= $recipe['batch_capacity'] ?> كغم</td>
                                <td>
                                    <a href="/recipes/edit/<?= $recipe['id'] ?>" class="btn btn-sm btn-primary"><i class="bi bi-pencil"></i></a>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
