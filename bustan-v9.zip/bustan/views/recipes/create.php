<?php $layout = 'admin'; ?>
<div class="row">
    <div class="col-12">
        <h2><i class="bi bi-plus-circle"></i> إضافة وصفة جديدة</h2>
    </div>
</div>

<div class="row mt-4">
    <div class="col-md-8">
        <div class="card">
            <div class="card-body">
                <form method="POST" action="/recipes/store">
                    <?= csrf_field() ?>
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label>اسم الوصفة</label>
                            <input type="text" name="recipe_name" class="form-control" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label>المادة الأساسية</label>
                            <input type="text" name="main_ingredient_name" class="form-control" required>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label>المادة من المخزن</label>
                            <select name="main_store_item_id" class="form-select">
                                <option value="">اختر المادة</option>
                                <?php foreach ($items as $item): ?>
                                <option value="<?= $item['id'] ?>"><?= e($item['item_name']) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-3 mb-3">
                            <label>الكمية</label>
                            <input type="number" step="0.001" name="main_ingredient_amount" class="form-control" required>
                        </div>
                        <div class="col-md-3 mb-3">
                            <label>الوحدة</label>
                            <input type="text" name="main_ingredient_unit" class="form-control" placeholder="كغم، غرام">
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-3 mb-3">
                            <label>الحرارة العلوية</label>
                            <input type="number" name="temp_top" class="form-control" value="200">
                        </div>
                        <div class="col-md-3 mb-3">
                            <label>الحرارة السفلية</label>
                            <input type="number" name="temp_bottom" class="form-control" value="180">
                        </div>
                        <div class="col-md-3 mb-3">
                            <label>المروحة</label>
                            <select name="has_fan" class="form-select">
                                <option value="1">نعم</option>
                                <option value="0">لا</option>
                            </select>
                        </div>
                        <div class="col-md-3 mb-3">
                            <label>الحالة</label>
                            <select name="is_visible" class="form-select">
                                <option value="1">مرئي</option>
                                <option value="0">مخفي</option>
                            </select>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-3 mb-3">
                            <label>سعة الدفعة (كغم)</label>
                            <input type="number" step="0.01" name="batch_capacity" class="form-control" value="10">
                        </div>
                        <div class="col-md-3 mb-3">
                            <label>سعة العجانة</label>
                            <input type="number" step="0.01" name="mixer_capacity" class="form-control" value="25">
                        </div>
                        <div class="col-md-3 mb-3">
                            <label>زمن العجن (دقيقة)</label>
                            <input type="number" name="kneading_time" class="form-control" value="15">
                        </div>
                        <div class="col-md-3 mb-3">
                            <label>زمن التخمير (دقيقة)</label>
                            <input type="number" name="fermentation_time" class="form-control" value="45">
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label>زمن الخبز (دقيقة)</label>
                            <input type="number" name="baking_time" class="form-control" value="25">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label>وزن القطعة (غرام)</label>
                            <input type="number" name="piece_weight" class="form-control" value="100">
                        </div>
                    </div>

                    <hr>
                    <h5><i class="bi bi-list-check"></i> المكونات</h5>
                    <div id="ingredientsContainer">
                        <div class="row ingredient-row mb-2">
                            <div class="col-md-4"><input type="text" name="ingredients[0][name]" class="form-control" placeholder="اسم المكون"></div>
                            <div class="col-md-3">
                                <select name="ingredients[0][store_item_id]" class="form-select">
                                    <option value="">من المخزن</option>
                                    <?php foreach ($items as $item): ?>
                                    <option value="<?= $item['id'] ?>"><?= e($item['item_name']) ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="col-md-2"><input type="number" step="0.001" name="ingredients[0][ratio]" class="form-control" placeholder="النسبة"></div>
                            <div class="col-md-2"><input type="text" name="ingredients[0][unit]" class="form-control" placeholder="الوحدة"></div>
                            <div class="col-md-1"><button type="button" class="btn btn-danger btn-sm" onclick="this.closest('.ingredient-row').remove()"><i class="bi bi-trash"></i></button></div>
                        </div>
                    </div>
                    <button type="button" class="btn btn-outline-primary btn-sm mb-3" onclick="addIngredient()">
                        <i class="bi bi-plus-lg"></i> إضافة مكون
                    </button>

                    <hr>
                    <h5><i class="bi bi-list-ol"></i> خطوات التحضير</h5>
                    <div id="stepsContainer">
                        <div class="row step-row mb-2">
                            <div class="col-md-10"><input type="text" name="steps[]" class="form-control" placeholder="خطوة التحضير"></div>
                            <div class="col-md-2"><button type="button" class="btn btn-danger btn-sm" onclick="this.closest('.step-row').remove()"><i class="bi bi-trash"></i></button></div>
                        </div>
                    </div>
                    <button type="button" class="btn btn-outline-primary btn-sm mb-3" onclick="addStep()">
                        <i class="bi bi-plus-lg"></i> إضافة خطوة
                    </button>

                    <div class="d-grid">
                        <button type="submit" class="btn btn-success btn-lg"><i class="bi bi-save"></i> حفظ الوصفة</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<script>
let ingredientCount = 1;
function addIngredient() {
    const container = document.getElementById('ingredientsContainer');
    const div = document.createElement('div');
    div.className = 'row ingredient-row mb-2';
    div.innerHTML = `
        <div class="col-md-4"><input type="text" name="ingredients[${ingredientCount}][name]" class="form-control" placeholder="اسم المكون"></div>
        <div class="col-md-3">
            <select name="ingredients[${ingredientCount}][store_item_id]" class="form-select">
                <option value="">من المخزن</option>
                <?php foreach ($items as $item): ?>
                <option value="<?= $item['id'] ?>"><?= e($item['item_name']) ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="col-md-2"><input type="number" step="0.001" name="ingredients[${ingredientCount}][ratio]" class="form-control" placeholder="النسبة"></div>
        <div class="col-md-2"><input type="text" name="ingredients[${ingredientCount}][unit]" class="form-control" placeholder="الوحدة"></div>
        <div class="col-md-1"><button type="button" class="btn btn-danger btn-sm" onclick="this.closest('.ingredient-row').remove()"><i class="bi bi-trash"></i></button></div>
    `;
    container.appendChild(div);
    ingredientCount++;
}

function addStep() {
    const container = document.getElementById('stepsContainer');
    const div = document.createElement('div');
    div.className = 'row step-row mb-2';
    div.innerHTML = `
        <div class="col-md-10"><input type="text" name="steps[]" class="form-control" placeholder="خطوة التحضير"></div>
        <div class="col-md-2"><button type="button" class="btn btn-danger btn-sm" onclick="this.closest('.step-row').remove()"><i class="bi bi-trash"></i></button></div>
    `;
    container.appendChild(div);
}
</script>
