<?php $layout = 'admin'; ?>
<div class="row">
    <div class="col-12">
        <h2><i class="bi bi-pencil-square"></i> تعديل وصفة</h2>
    </div>
</div>

<div class="row mt-4">
    <div class="col-md-8">
        <div class="card">
            <div class="card-body">
                <form method="POST" action="/recipes/update/<?= $recipe['id'] ?>">
                    <?= csrf_field() ?>
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label>اسم الوصفة</label>
                            <input type="text" name="recipe_name" class="form-control" value="<?= e($recipe['recipe_name']) ?>" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label>المادة الأساسية</label>
                            <input type="text" name="main_ingredient_name" class="form-control" value="<?= e($recipe['main_ingredient_name']) ?>" required>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-3 mb-3">
                            <label>الحرارة العلوية</label>
                            <input type="number" name="temp_top" class="form-control" value="<?= $recipe['temp_top'] ?>">
                        </div>
                        <div class="col-md-3 mb-3">
                            <label>الحرارة السفلية</label>
                            <input type="number" name="temp_bottom" class="form-control" value="<?= $recipe['temp_bottom'] ?>">
                        </div>
                        <div class="col-md-3 mb-3">
                            <label>المروحة</label>
                            <select name="has_fan" class="form-select">
                                <option value="1" <?= $recipe['has_fan'] ? 'selected' : '' ?>>نعم</option>
                                <option value="0" <?= !$recipe['has_fan'] ? 'selected' : '' ?>>لا</option>
                            </select>
                        </div>
                        <div class="col-md-3 mb-3">
                            <label>الحالة</label>
                            <select name="is_visible" class="form-select">
                                <option value="1" <?= $recipe['is_visible'] ? 'selected' : '' ?>>مرئي</option>
                                <option value="0" <?= !$recipe['is_visible'] ? 'selected' : '' ?>>مخفي</option>
                            </select>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-3 mb-3">
                            <label>سعة الدفعة</label>
                            <input type="number" step="0.01" name="batch_capacity" class="form-control" value="<?= $recipe['batch_capacity'] ?>">
                        </div>
                        <div class="col-md-3 mb-3">
                            <label>زمن العجن</label>
                            <input type="number" name="kneading_time" class="form-control" value="<?= $recipe['kneading_time'] ?>">
                        </div>
                        <div class="col-md-3 mb-3">
                            <label>زمن التخمير</label>
                            <input type="number" name="fermentation_time" class="form-control" value="<?= $recipe['fermentation_time'] ?>">
                        </div>
                        <div class="col-md-3 mb-3">
                            <label>زمن الخبز</label>
                            <input type="number" name="baking_time" class="form-control" value="<?= $recipe['baking_time'] ?>">
                        </div>
                    </div>
                    <div class="mb-3">
                        <label>وزن القطعة (غرام)</label>
                        <input type="number" name="piece_weight" class="form-control" value="<?= $recipe['piece_weight'] ?>">
                    </div>
                    <div class="d-grid">
                        <button type="submit" class="btn btn-success btn-lg"><i class="bi bi-save"></i> حفظ التعديلات</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card">
            <div class="card-header"><i class="bi bi-info-circle"></i> معلومات</div>
            <div class="card-body">
                <p><strong>تاريخ الإنشاء:</strong> <?= format_date($recipe['created_at']) ?></p>
                <p><strong>المكونات:</strong> <?= count($ingredients) ?></p>
                <p><strong>الخطوات:</strong> <?= count($steps) ?></p>
            </div>
        </div>
    </div>
</div>
