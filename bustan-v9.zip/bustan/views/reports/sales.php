<?php $layout = 'admin'; ?>
<div class="row">
    <div class="col-12">
        <h2><i class="bi bi-cart-check"></i> تقرير المبيعات</h2>
    </div>
</div>

<div class="row mt-4">
    <div class="col-md-4 mb-3">
        <div class="card stat-card">
            <div class="card-body text-center">
                <h6>إجمالي المبيعات الشهرية</h6>
                <h3><?= format_money($monthlyTotal) ?></h3>
            </div>
        </div>
    </div>
    <div class="col-md-4 mb-3">
        <div class="card stat-card" style="background: linear-gradient(135deg, #40916c, #52b788);">
            <div class="card-body text-center">
                <h6>كاش</h6>
                <h3><?= format_money($cashSales) ?></h3>
            </div>
        </div>
    </div>
    <div class="col-md-4 mb-3">
        <div class="card stat-card" style="background: linear-gradient(135deg, #1b4332, #2d6a4f);">
            <div class="card-body text-center">
                <h6>محفظة</h6>
                <h3><?= format_money($walletSales) ?></h3>
            </div>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-header"><i class="bi bi-list"></i> طلبات اليوم</div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead><tr><th>#</th><th>الزبون</th><th>المبلغ</th><th>الدفع</th><th>الحالة</th><th>الوقت</th></tr></thead>
                        <tbody>
                            <?php foreach ($todayOrders as $order): ?>
                            <tr>
                                <td><?= $order['id'] ?></td>
                                <td><?= e($order['customer_name']) ?></td>
                                <td><?= format_money($order['total_amount']) ?></td>
                                <td><span class="badge bg-<?= $order['payment_method'] === 'wallet' ? 'info' : 'secondary' ?>"><?= $order['payment_method'] === 'wallet' ? 'محفظة' : 'كاش' ?></span></td>
                                <td><span class="badge badge-<?= $order['order_status'] ?>"><?= e($order['order_status']) ?></span></td>
                                <td><small><?= format_date($order['created_at']) ?></small></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
