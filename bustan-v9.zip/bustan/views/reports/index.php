<?php $layout = 'admin'; ?>
<div class="row">
    <div class="col-12">
        <h2><i class="bi bi-graph-up"></i> التقارير المالية</h2>
    </div>
</div>

<div class="row mt-4">
    <div class="col-md-3 mb-3">
        <div class="card stat-card">
            <div class="card-body text-center">
                <h6>مبيعات اليوم</h6>
                <h3><?= format_money($todayStats['total'] ?? 0) ?></h3>
                <small><?= $todayStats['count'] ?? 0 ?> طلب</small>
            </div>
        </div>
    </div>
    <div class="col-md-3 mb-3">
        <div class="card stat-card" style="background: linear-gradient(135deg, #40916c, #52b788);">
            <div class="card-body text-center">
                <h6>مصروفات اليوم</h6>
                <h3><?= format_money($todayExpenses) ?></h3>
            </div>
        </div>
    </div>
    <div class="col-md-3 mb-3">
        <div class="card stat-card" style="background: linear-gradient(135deg, #1b4332, #2d6a4f);">
            <div class="card-body text-center">
                <h6>صافي الربح اليوم</h6>
                <h3 class="<?= $todayProfit >= 0 ? 'text-success' : 'text-danger' ?>"><?= format_money($todayProfit) ?></h3>
            </div>
        </div>
    </div>
    <div class="col-md-3 mb-3">
        <div class="card stat-card" style="background: linear-gradient(135deg, #b7e4c7, #40916c); color: #1b4332;">
            <div class="card-body text-center">
                <h6>صافي الربح الشهري</h6>
                <h3 class="<?= $monthlyProfit >= 0 ? 'text-success' : 'text-danger' ?>"><?= format_money($monthlyProfit) ?></h3>
            </div>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-header d-flex justify-content-between">
                <span><i class="bi bi-link"></i> روابط التقارير التفصيلية</span>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-4 mb-3">
                        <a href="/reports/sales" class="card text-decoration-none text-dark">
                            <div class="card-body text-center">
                                <i class="bi bi-cart-check" style="font-size:3rem;color:var(--primary);"></i>
                                <h5 class="mt-2">تقرير المبيعات</h5>
                                <p class="text-muted">تفصيلي بالطلبات والدفعات</p>
                            </div>
                        </a>
                    </div>
                    <div class="col-md-4 mb-3">
                        <a href="/reports/profits" class="card text-decoration-none text-dark">
                            <div class="card-body text-center">
                                <i class="bi bi-cash-coin" style="font-size:3rem;color:var(--primary);"></i>
                                <h5 class="mt-2">تقرير الأرباح</h5>
                                <p class="text-muted">الإيرادات والمصروفات والأرباح</p>
                            </div>
                        </a>
                    </div>
                    <div class="col-md-4 mb-3">
                        <a href="/admin/expenses" class="card text-decoration-none text-dark">
                            <div class="card-body text-center">
                                <i class="bi bi-wallet2" style="font-size:3rem;color:var(--primary);"></i>
                                <h5 class="mt-2">سجل المصروفات</h5>
                                <p class="text-muted">جميع المصروفات المسجلة</p>
                            </div>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
