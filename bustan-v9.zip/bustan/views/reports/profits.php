<?php $layout = 'admin'; ?>
<div class="row">
    <div class="col-12">
        <h2><i class="bi bi-cash-coin"></i> تقرير الأرباح</h2>
    </div>
</div>

<div class="row mt-4">
    <div class="col-md-3 mb-3">
        <div class="card stat-card">
            <div class="card-body text-center">
                <h6>إجمالي المبيعات</h6>
                <h3><?= format_money($totalSales) ?></h3>
            </div>
        </div>
    </div>
    <div class="col-md-3 mb-3">
        <div class="card stat-card" style="background: linear-gradient(135deg, #dc3545, #ff6b6b);">
            <div class="card-body text-center">
                <h6>تكلفة الإنتاج</h6>
                <h3><?= format_money($totalCost) ?></h3>
            </div>
        </div>
    </div>
    <div class="col-md-3 mb-3">
        <div class="card stat-card" style="background: linear-gradient(135deg, #ffc107, #ff9800); color: #000;">
            <div class="card-body text-center">
                <h6>المصروفات</h6>
                <h3><?= format_money($totalExpenses) ?></h3>
            </div>
        </div>
    </div>
    <div class="col-md-3 mb-3">
        <div class="card stat-card" style="background: linear-gradient(135deg, #28a745, #52b788);">
            <div class="card-body text-center">
                <h6>صافي الربح</h6>
                <h3><?= format_money($netProfit) ?></h3>
            </div>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-md-8">
        <div class="card">
            <div class="card-header"><i class="bi bi-calendar"></i> المبيعات اليومية</div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead><tr><th>التاريخ</th><th>الطلبات</th><th>المبيعات</th><th>التكلفة</th><th>الربح</th></tr></thead>
                        <tbody>
                            <?php foreach ($dailySales as $day): ?>
                            <tr>
                                <td><?= e($day['date']) ?></td>
                                <td><?= $day['orders'] ?></td>
                                <td><?= format_money($day['total']) ?></td>
                                <td><?= format_money($day['cost']) ?></td>
                                <td class="<?= ($day['total'] - $day['cost']) >= 0 ? 'text-success' : 'text-danger' ?>"><?= format_money($day['total'] - $day['cost']) ?></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card mb-3">
            <div class="card-header"><i class="bi bi-wallet"></i> ملخص</div>
            <div class="card-body">
                <div class="d-flex justify-content-between mb-2"><span>الإجمالي:</span><strong><?= format_money($totalSales) ?></strong></div>
                <div class="d-flex justify-content-between mb-2"><span>التكلفة:</span><strong class="text-danger">-<?= format_money($totalCost) ?></strong></div>
                <div class="d-flex justify-content-between mb-2"><span>المصروفات:</span><strong class="text-danger">-<?= format_money($totalExpenses) ?></strong></div>
                <div class="d-flex justify-content-between mb-2"><span>المشتريات:</span><strong class="text-danger">-<?= format_money($totalPurchases) ?></strong></div>
                <hr>
                <div class="d-flex justify-content-between"><span>صافي الربح:</span><strong class="<?= $netProfit >= 0 ? 'text-success' : 'text-danger' ?> h5"><?= format_money($netProfit) ?></strong></div>
            </div>
        </div>
    </div>
</div>
