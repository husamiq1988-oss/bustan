<?php $layout = 'admin'; ?>
<div class="row">
    <div class="col-12">
        <h2><i class="bi bi-people-fill"></i> الموارد البشرية</h2>
    </div>
</div>

<div class="row mt-4">
    <div class="col-md-8">
        <div class="card">
            <div class="card-header d-flex justify-content-between">
                <span><i class="bi bi-list"></i> قائمة الموظفين</span>
                <button class="btn btn-success btn-sm" data-bs-toggle="modal" data-bs-target="#addEmployeeModal">
                    <i class="bi bi-plus-lg"></i> موظف جديد
                </button>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead><tr><th>#</th><th>الاسم</th><th>الهاتف</th><th>الدور</th><th>الراتب</th><th>الحالة</th><th>عمليات</th></tr></thead>
                        <tbody>
                            <?php foreach ($employees as $emp): ?>
                            <tr>
                                <td><?= $emp['id'] ?></td>
                                <td><strong><?= e($emp['name']) ?></strong></td>
                                <td><?= e($emp['phone']) ?></td>
                                <td><span class="badge bg-secondary"><?= e($emp['role']) ?></span></td>
                                <td><?= format_money($emp['salary']) ?></td>
                                <td><span class="badge bg-<?= $emp['status'] === 'active' ? 'success' : 'secondary' ?>"><?= $emp['status'] === 'active' ? 'نشط' : 'غير نشط' ?></span></td>
                                <td>
                                    <button class="btn btn-sm btn-primary" data-bs-toggle="modal" data-bs-target="#attendanceModal<?= $emp['id'] ?>"><i class="bi bi-clock"></i></button>
                                    <button class="btn btn-sm btn-success" data-bs-toggle="modal" data-bs-target="#transactionModal<?= $emp['id'] ?>"><i class="bi bi-cash"></i></button>
                                </td>
                            </tr>
                            <!-- Attendance Modal -->
                            <div class="modal fade" id="attendanceModal<?= $emp['id'] ?>">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header"><h5>تسجيل حضور: <?= e($emp['name']) ?></h5><button class="btn-close" data-bs-dismiss="modal"></button></div>
                                        <form method="POST" action="/employees/attendance">
                                            <?= csrf_field() ?>
                                            <input type="hidden" name="employee_id" value="<?= $emp['id'] ?>">
                                            <div class="modal-body">
                                                <div class="mb-3"><label>وقت الدخول</label><input type="time" name="check_in" class="form-control" value="<?= date('H:i') ?>"></div>
                                                <div class="mb-3"><label>وقت الخروج</label><input type="time" name="check_out" class="form-control"></div>
                                                <div class="mb-3"><label>الحالة</label><select name="status" class="form-select">
                                                    <option value="حضور">حضور</option>
                                                    <option value="تأخير">تأخير</option>
                                                    <option value="غياب">غياب</option>
                                                </select></div>
                                                <div class="mb-3"><label>الدقائق المتأخرة</label><input type="number" name="late_minutes" class="form-control" value="0"></div>
                                            </div>
                                            <div class="modal-footer">
                                                <button class="btn btn-secondary" data-bs-dismiss="modal">إلغاء</button>
                                                <button class="btn btn-success" type="submit">تسجيل</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                            <!-- Transaction Modal -->
                            <div class="modal fade" id="transactionModal<?= $emp['id'] ?>">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header"><h5>عملية مالية: <?= e($emp['name']) ?></h5><button class="btn-close" data-bs-dismiss="modal"></button></div>
                                        <form method="POST" action="/employees/transaction">
                                            <?= csrf_field() ?>
                                            <input type="hidden" name="employee_id" value="<?= $emp['id'] ?>">
                                            <div class="modal-body">
                                                <div class="mb-3"><label>النوع</label><select name="type" class="form-select">
                                                    <option value="salary">راتب</option>
                                                    <option value="advance">سلفة</option>
                                                </select></div>
                                                <div class="mb-3"><label>المبلغ</label><input type="number" step="0.01" name="amount" class="form-control" required></div>
                                                <div class="mb-3"><label>التاريخ</label><input type="date" name="date" class="form-control" value="<?= date('Y-m-d') ?>"></div>
                                                <div class="mb-3"><label>ملاحظات</label><textarea name="notes" class="form-control" rows="2"></textarea></div>
                                            </div>
                                            <div class="modal-footer">
                                                <button class="btn btn-secondary" data-bs-dismiss="modal">إلغاء</button>
                                                <button class="btn btn-success" type="submit">حفظ</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card">
            <div class="card-header"><i class="bi bi-clock-history"></i> حضور اليوم</div>
            <div class="card-body">
                <?php if (empty($todayAttendance)): ?>
                    <p class="text-muted">لا يوجد سجلات</p>
                <?php else: ?>
                    <?php foreach ($todayAttendance as $att): ?>
                    <div class="d-flex justify-content-between mb-2 pb-2 border-bottom">
                        <div>
                            <strong><?= e($att['employee_name']) ?></strong><br>
                            <small class="text-muted"><?= $att['check_in'] ?> - <?= $att['check_out'] ?? 'لم يسجل' ?></small>
                        </div>
                        <span class="badge bg-<?= $att['status'] === 'حضور' ? 'success' : ($att['status'] === 'تأخير' ? 'warning' : 'danger') ?>"><?= e($att['status']) ?></span>
                    </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<!-- Add Employee Modal -->
<div class="modal fade" id="addEmployeeModal">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header"><h5>إضافة موظف جديد</h5><button class="btn-close" data-bs-dismiss="modal"></button></div>
            <form method="POST" action="/employees/store">
                <?= csrf_field() ?>
                <div class="modal-body">
                    <div class="mb-3"><label>الاسم</label><input type="text" name="name" class="form-control" required></div>
                    <div class="mb-3"><label>الهاتف</label><input type="tel" name="phone" class="form-control" placeholder="07XXXXXXXXX"></div>
                    <div class="mb-3"><label>الدور</label><input type="text" name="role" class="form-control" placeholder="مثال: طباخ، كاشير، سائق"></div>
                    <div class="mb-3"><label>الراتب</label><input type="number" step="0.01" name="salary" class="form-control" value="0"></div>
                </div>
                <div class="modal-footer">
                    <button class="btn btn-secondary" data-bs-dismiss="modal">إلغاء</button>
                    <button class="btn btn-success" type="submit">حفظ</button>
                </div>
            </form>
        </div>
    </div>
</div>
