<?php $layout = 'admin'; ?>
<div class="row">
    <div class="col-12 mb-4">
        <h2><i class="bi bi-speedometer2"></i> لوحة التحكم</h2>
        <p class="text-muted">مرحباً <?= e($user['name'] ?? '') ?></p>
    </div>
</div>

<!-- Stats Cards -->
<div class="row mb-4">
    <div class="col-md-3 mb-3">
        <div class="card stat-card">
            <div class="card-body d-flex justify-content-between align-items-center">
                <div>
                    <h6>مبيعات اليوم</h6>
                    <h3><?= format_money($todayStats['total'] ?? 0) ?></h3>
                    <small><?= $todayStats['count'] ?? 0 ?> طلب</small>
                </div>
                <i class="bi bi-cash-stack"></i>
            </div>
        </div>
    </div>
    <div class="col-md-3 mb-3">
        <div class="card stat-card" style="background: linear-gradient(135deg, #40916c, #52b788);">
            <div class="card-body d-flex justify-content-between align-items-center">
                <div>
                    <h6>مبيعات الشهر</h6>
                    <h3><?= format_money($monthlyStats['total'] ?? 0) ?></h3>
                    <small><?= $monthlyStats['count'] ?? 0 ?> طلب</small>
                </div>
                <i class="bi bi-graph-up"></i>
            </div>
        </div>
    </div>
    <div class="col-md-3 mb-3">
        <div class="card stat-card" style="background: linear-gradient(135deg, #1b4332, #2d6a4f);">
            <div class="card-body d-flex justify-content-between align-items-center">
                <div>
                    <h6>الزبائن</h6>
                    <h3><?= number_format($totalUsers) ?></h3>
                    <small>مسجل</small>
                </div>
                <i class="bi bi-people"></i>
            </div>
        </div>
    </div>
    <div class="col-md-3 mb-3">
        <div class="card stat-card" style="background: linear-gradient(135deg, #b7e4c7, #40916c);">
            <div class="card-body d-flex justify-content-between align-items-center">
                <div>
                    <h6>قيمة المخزون</h6>
                    <h3><?= format_money($inventoryValue) ?></h3>
                    <small>دينار عراقي</small>
                </div>
                <i class="bi bi-box-seam"></i>
            </div>
        </div>
    </div>
</div>

<div class="row">
    <!-- Pending Orders -->
    <div class="col-md-8 mb-4">
        <div class="card">
            <div class="card-header d-flex justify-content-between align-items-center">
                <span><i class="bi bi-clock-history"></i> الطلبات النشطة</span>
                <span class="badge bg-warning"><?= count($pendingOrders) ?> طلب</span>
            </div>
            <div class="card-body">
                <?php if (empty($pendingOrders)): ?>
                    <div class="text-center text-muted py-4">
                        <i class="bi bi-check-circle" style="font-size:3rem;"></i>
                        <p>لا توجد طلبات معلقة</p>
                    </div>
                <?php else: ?>
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead><tr><th>#</th><th>الزبون</th><th>المبلغ</th><th>الحالة</th><th>الوقت</th></tr></thead>
                            <tbody>
                                <?php foreach ($pendingOrders as $order): ?>
                                <tr>
                                    <td><?= $order['id'] ?></td>
                                    <td><?= e($order['customer_name']) ?></td>
                                    <td><?= format_money($order['total_amount']) ?></td>
                                    <td><span class="badge badge-<?= $order['order_status'] ?>"><?= e($order['order_status']) ?></span></td>
                                    <td><small><?= format_date($order['created_at']) ?></small></td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Side Panel -->
    <div class="col-md-4">
        <!-- Restaurant Status -->
        <div class="card mb-3">
            <div class="card-header"><i class="bi bi-shop"></i> حالة المتجر</div>
            <div class="card-body">
                <div class="form-check form-switch">
                    <input class="form-check-input" type="checkbox" id="restStatus" <?= $restaurantStatus === 'open' ? 'checked' : '' ?>>
                    <label class="form-check-label" for="restStatus">
                        <?= $restaurantStatus === 'open' ? 'مفتوح ✅' : 'مغلق 🔒' ?>
                    </label>
                </div>
            </div>
        </div>

        <!-- Cashier Balance -->
        <div class="card mb-3">
            <div class="card-header"><i class="bi bi-cash-stack"></i> صندوق الكاشير</div>
            <div class="card-body">
                <h4 class="text-success"><?= format_money($cashierBalance) ?></h4>
                <button class="btn btn-sm btn-outline-danger w-100">تصفير الصندوق</button>
            </div>
        </div>

        <!-- Low Stock Alerts -->
        <div class="card mb-3">
            <div class="card-header"><i class="bi bi-exclamation-triangle"></i> تنبيهات المخزون</div>
            <div class="card-body">
                <?php if (empty($lowStock)): ?>
                    <p class="text-muted">لا توجد تنبيهات</p>
                <?php else: ?>
                    <?php foreach (array_slice($lowStock, 0, 5) as $item): ?>
                    <div class="alert alert-warning py-1 px-2 mb-1 low-stock">
                        <small><strong><?= e($item['item_name']) ?></strong> - <?= $item['current_qty'] ?> / <?= $item['alert_level'] ?></small>
                    </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>

        <!-- Quick Links -->
        <div class="card">
            <div class="card-header"><i class="bi bi-lightning"></i> روابط سريعة</div>
            <div class="card-body">
                <a href="/kitchen" class="btn btn-outline-primary w-100 mb-2"><i class="bi bi-fire"></i> شاشة المطبخ</a>
                <a href="/cashier" class="btn btn-outline-success w-100 mb-2"><i class="bi bi-cash-stack"></i> الكاشير</a>
                <a href="/delivery" class="btn btn-outline-info w-100"><i class="bi bi-truck"></i> التوصيل</a>
            </div>
        </div>
    </div>
</div>
