<?php $layout = 'admin'; ?>
<div class="row">
    <div class="col-12">
        <h2><i class="bi bi-truck"></i> مهام التوصيل</h2>
        <p class="text-muted">السائق: <?= e($driver['name'] ?? '') ?></p>
    </div>
</div>

<div class="row mt-4">
    <div class="col-md-4">
        <div class="card stat-card mb-3">
            <div class="card-body text-center">
                <h5>الرصيد الحالي</h5>
                <h2><?= format_money($balance) ?></h2>
            </div>
        </div>
    </div>
</div>

<div class="row">
    <?php if (empty($orders)): ?>
    <div class="col-12">
        <div class="card text-center py-5">
            <i class="bi bi-bicycle" style="font-size:4rem;color:var(--accent);"></i>
            <h4 class="mt-3">لا توجد مهام حالياً</h4>
            <p class="text-muted">استرخِ واستمتع بقهوتك</p>
        </div>
    </div>
    <?php else: ?>
        <?php foreach ($orders as $order): ?>
        <div class="col-md-4 mb-4">
            <div class="card">
                <div class="card-header d-flex justify-content-between">
                    <span><strong>#<?= $order['id'] ?></strong></span>
                    <span class="badge badge-<?= $order['order_status'] ?>"><?= e($order['order_status']) ?></span>
                </div>
                <div class="card-body">
                    <h6><i class="bi bi-person"></i> <?= e($order['customer_name']) ?></h6>
                    <p><i class="bi bi-telephone"></i> <?= e($order['user_phone']) ?></p>
                    <p><i class="bi bi-geo-alt"></i> <?= e($order['admin_notes'] ?? 'لا يوجد عنوان') ?></p>
                    <hr>
                    <div class="d-flex justify-content-between">
                        <span>المبلغ:</span>
                        <strong class="text-success"><?= format_money($order['total_amount']) ?></strong>
                    </div>
                </div>
                <div class="card-footer">
                    <div class="btn-group w-100">
                        <button class="btn btn-success" onclick="updateStatus(<?= $order['id'] ?>, 'completed')">
                            <i class="bi bi-check-lg"></i> تم التسليم
                        </button>
                        <button class="btn btn-danger" onclick="updateStatus(<?= $order['id'] ?>, 'cancelled')">
                            <i class="bi bi-x-lg"></i> إلغاء
                        </button>
                    </div>
                </div>
            </div>
        </div>
        <?php endforeach; ?>
    <?php endif; ?>
</div>

<script>
function updateStatus(id, status) {
    fetch('/delivery/update/' + id, {
        method: 'POST',
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        body: 'status=' + status + '&_token=<?= $_SESSION['csrf_token'] ?? '' ?>'
    })
    .then(r => r.json())
    .then(res => {
        if (res.status === 'success') location.reload();
    });
}
</script>
