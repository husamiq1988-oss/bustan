<?php $layout = 'admin'; ?>
<div class="row">
    <div class="col-12">
        <h2><i class="bi bi-fire"></i> شاشة المطبخ</h2>
    </div>
</div>

<div class="row mt-4">
    <?php if (empty($orders)): ?>
    <div class="col-12">
        <div class="card text-center py-5">
            <i class="bi bi-emoji-smile" style="font-size:4rem;color:var(--accent);"></i>
            <h4 class="mt-3">لا توجد طلبات معلقة</h4>
            <p class="text-muted">المطبخ مستقر! استرخِ قليلاً ☕</p>
        </div>
    </div>
    <?php else: ?>
        <?php foreach ($orders as $order): ?>
        <?php $items = json_decode($order['cart_data'] ?? '[]', true) ?: []; ?>
        <div class="col-md-4 mb-4">
            <div class="card order-item">
                <div class="card-header d-flex justify-content-between">
                    <span><strong>#<?= $order['id'] ?></strong></span>
                    <span class="badge badge-<?= $order['order_status'] ?>"><?= e($order['order_status']) ?></span>
                </div>
                <div class="card-body">
                    <h6><i class="bi bi-person"></i> <?= e($order['customer_name']) ?></h6>
                    <p class="text-muted small"><i class="bi bi-telephone"></i> <?= e($order['user_phone']) ?></p>
                    <hr>
                    <?php foreach ($items as $item): ?>
                    <div class="d-flex justify-content-between mb-1">
                        <span><?= e($item['name'] ?? 'منتج') ?> x<?= $item['qty'] ?? 1 ?></span>
                        <span><?= format_money(($item['price'] ?? 0) * ($item['qty'] ?? 1)) ?></span>
                    </div>
                    <?php endforeach; ?>
                    <hr>
                    <div class="d-flex justify-content-between">
                        <strong>المجموع:</strong>
                        <strong class="text-success"><?= format_money($order['total_amount']) ?></strong>
                    </div>
                    <?php if ($order['note'] ?? ''): ?>
                    <div class="alert alert-info mt-2 py-1"><small><i class="bi bi-info-circle"></i> <?= e($order['note']) ?></small></div>
                    <?php endif; ?>
                </div>
                <div class="card-footer">
                    <form method="POST" action="/kitchen/complete/<?= $order['id'] ?>" class="d-grid">
                        <?= csrf_field() ?>
                        <button type="submit" class="btn btn-success">
                            <i class="bi bi-check-lg"></i> تم التجهيز
                        </button>
                    </form>
                </div>
            </div>
        </div>
        <?php endforeach; ?>
    <?php endif; ?>
</div>

<script>
// Auto-refresh every 30 seconds
setInterval(() => location.reload(), 30000);
</script>
