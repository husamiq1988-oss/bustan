<?php $layout = 'admin'; ?>
<div class="row">
    <div class="col-12">
        <h2><i class="bi bi-box-seam"></i> إدارة المخزون</h2>
    </div>
</div>

<div class="row mt-4">
    <div class="col-md-8">
        <div class="card">
            <div class="card-header d-flex justify-content-between">
                <span><i class="bi bi-list"></i> قائمة المواد</span>
                <button class="btn btn-success btn-sm" data-bs-toggle="modal" data-bs-target="#addModal">
                    <i class="bi bi-plus-lg"></i> إضافة مادة
                </button>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead><tr><th>المادة</th><th>الكمية</th><th>الوحدة</th><th>التكلفة</th><th>الحد</th><th>حالة</th><th>عمليات</th></tr></thead>
                        <tbody>
                            <?php foreach ($items as $item): ?>
                            <tr class="<?= ($item['current_qty'] <= $item['alert_level']) ? 'low-stock' : '' ?>">
                                <td><strong><?= e($item['item_name']) ?></strong><br><small class="text-muted"><?= e($item['brand'] ?? '') ?></small></td>
                                <td><?= $item['current_qty'] ?></td>
                                <td><?= e($item['unit']) ?></td>
                                <td><?= format_money($item['cost_price']) ?></td>
                                <td><?= $item['alert_level'] ?></td>
                                <td>
                                    <?php if ($item['current_qty'] <= $item['alert_level']): ?>
                                    <span class="badge bg-danger">نقص</span>
                                    <?php else: ?>
                                    <span class="badge bg-success">جيد</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <a href="/inventory/edit/<?= $item['id'] ?>" class="btn btn-sm btn-primary"><i class="bi bi-pencil"></i></a>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card">
            <div class="card-header"><i class="bi bi-exclamation-triangle"></i> تنبيهات النقص</div>
            <div class="card-body">
                <?php if (empty($lowStock)): ?>
                    <p class="text-muted">لا توجد تنبيهات</p>
                <?php else: ?>
                    <?php foreach ($lowStock as $item): ?>
                    <div class="alert alert-danger py-2 mb-2">
                        <strong><?= e($item['item_name']) ?></strong><br>
                        <small>الكمية: <?= $item['current_qty'] ?> / الحد: <?= $item['alert_level'] ?></small>
                    </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<!-- Add Modal -->
<div class="modal fade" id="addModal">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5>إضافة مادة جديدة</h5>
                <button class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST" action="/inventory/store">
                <?= csrf_field() ?>
                <div class="modal-body">
                    <div class="mb-3"><label>اسم المادة</label><input type="text" name="item_name" class="form-control" required></div>
                    <div class="mb-3"><label>الماركة</label><input type="text" name="brand" class="form-control"></div>
                    <div class="row">
                        <div class="col-6 mb-3"><label>الكمية</label><input type="number" step="0.01" name="current_qty" class="form-control" required></div>
                        <div class="col-6 mb-3"><label>الوحدة</label><input type="text" name="unit" class="form-control" required></div>
                    </div>
                    <div class="row">
                        <div class="col-6 mb-3"><label>التكلفة</label><input type="number" step="0.01" name="cost_price" class="form-control"></div>
                        <div class="col-6 mb-3"><label>حد التنبيه</label><input type="number" step="0.01" name="alert_level" class="form-control"></div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button class="btn btn-secondary" data-bs-dismiss="modal">إلغاء</button>
                    <button class="btn btn-success" type="submit">حفظ</button>
                </div>
            </form>
        </div>
    </div>
</div>
