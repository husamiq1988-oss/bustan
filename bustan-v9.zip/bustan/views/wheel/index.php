<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-6 text-center">
            <h2 class="mb-4">🎡 عجلة الحظ</h2>
            <p class="text-muted">ادخل رقم هاتفك وجرب حظك!</p>

            <div class="card shadow-lg">
                <div class="card-body p-5">
                    <div class="wheel-container mb-4">
                        <canvas id="wheel" width="400" height="400" class="img-fluid"></canvas>
                    </div>

                    <div class="mb-3">
                        <input type="tel" id="wheelPhone" class="form-control form-control-lg text-center" placeholder="07XXXXXXXXX">
                    </div>
                    <div class="mb-3">
                        <input type="number" id="wheelOrder" class="form-control" placeholder="رقم الطلب (اختياري)">
                    </div>

                    <button class="btn btn-success btn-lg w-100" onclick="spin()" id="spinBtn">
                        <i class="bi bi-arrow-repeat"></i> اضغط للدوران
                    </button>

                    <div id="result" class="mt-4 d-none">
                        <div class="alert alert-success">
                            <h4>🎉 مبروك!</h4>
                            <p id="prizeText"></p>
                            <p id="couponCode" class="fw-bold"></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
const prizes = <?= json_encode(array_map(fn($p) => ['label' => $p['label'], 'color' => '#' . substr(md5($p['label']), 0, 6)], $prizes)) ?>;

function drawWheel() {
    const canvas = document.getElementById('wheel');
    const ctx = canvas.getContext('2d');
    const center = canvas.width / 2;
    const radius = center - 10;
    const slice = 2 * Math.PI / prizes.length;

    ctx.clearRect(0, 0, canvas.width, canvas.height);

    prizes.forEach((prize, i) => {
        ctx.beginPath();
        ctx.moveTo(center, center);
        ctx.arc(center, center, radius, i * slice, (i + 1) * slice);
        ctx.fillStyle = i % 2 === 0 ? '#2d6a4f' : '#40916c';
        ctx.fill();
        ctx.stroke();

        ctx.save();
        ctx.translate(center, center);
        ctx.rotate(i * slice + slice / 2);
        ctx.textAlign = 'right';
        ctx.fillStyle = 'white';
        ctx.font = 'bold 14px Arial';
        ctx.fillText(prize.label, radius - 20, 5);
        ctx.restore();
    });

    // Pointer
    ctx.beginPath();
    ctx.moveTo(center - 15, 10);
    ctx.lineTo(center + 15, 10);
    ctx.lineTo(center, 40);
    ctx.fillStyle = '#dc3545';
    ctx.fill();
}

function spin() {
    const phone = document.getElementById('wheelPhone').value;
    const orderId = document.getElementById('wheelOrder').value;

    if (!phone) { alert('أدخل رقم الهاتف'); return; }

    document.getElementById('spinBtn').disabled = true;
    document.getElementById('spinBtn').innerHTML = '<span class="spinner-border"></span> جاري الدوران...';

    fetch('/wheel/spin', {
        method: 'POST',
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        body: 'phone=' + encodeURIComponent(phone) + '&order_id=' + orderId + '&_token=<?= $_SESSION['csrf_token'] ?? '' ?>'
    })
    .then(r => r.json())
    .then(res => {
        if (res.status === 'success') {
            document.getElementById('result').classList.remove('d-none');
            document.getElementById('prizeText').textContent = 'لقد ربحت: ' + res.prize;
            document.getElementById('couponCode').textContent = res.coupon_code ? 'كود الكوبون: ' + res.coupon_code : '';
        } else {
            alert(res.message);
        }
        document.getElementById('spinBtn').disabled = false;
        document.getElementById('spinBtn').innerHTML = '<i class="bi bi-arrow-repeat"></i> اضغط للدوران';
    });
}

drawWheel();
</script>
