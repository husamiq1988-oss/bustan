<?php $layout = 'admin'; ?>
<div class="row">
    <div class="col-12">
        <h2><i class="bi bi-lightning"></i> إدارة الأصول والأحمال الكهربائية</h2>
    </div>
</div>

<div class="row mt-4">
    <div class="col-md-3 mb-3">
        <div class="card stat-card">
            <div class="card-body text-center">
                <h6>رأس المال</h6>
                <h4><?= format_money($currentValue) ?></h4>
            </div>
        </div>
    </div>
    <div class="col-md-3 mb-3">
        <div class="card stat-card" style="background: linear-gradient(135deg, #40916c, #52b788);">
            <div class="card-body text-center">
                <h6>ميزانية مستقبلية</h6>
                <h4><?= format_money($futureValue) ?></h4>
            </div>
        </div>
    </div>
    <div class="col-md-3 mb-3">
        <div class="card stat-card" style="background: linear-gradient(135deg, #b7e4c7, #40916c); color: #1b4332;">
            <div class="card-body text-center">
                <h6>الحمل المستمر</h6>
                <h4><?= number_format($continuousWatts) ?> واط</h4>
            </div>
        </div>
    </div>
    <div class="col-md-3 mb-3">
        <div class="card stat-card" style="background: linear-gradient(135deg, #ffc107, #ff9800); color: #000;">
            <div class="card-body text-center">
                <h6>الحمل عند الحاجة</h6>
                <h4><?= number_format($intermittentWatts) ?> واط</h4>
            </div>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-header d-flex justify-content-between">
                <span><i class="bi bi-list"></i> جرد الأصول</span>
                <button class="btn btn-success btn-sm" data-bs-toggle="modal" data-bs-target="#addAssetModal">
                    <i class="bi bi-plus-lg"></i> إضافة أصل
                </button>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead><tr><th>الأصل</th><th>التصنيف</th><th>الكمية</th><th>الحالة</th><th>الحمل</th><th>التشغيل</th><th>عمليات</th></tr></thead>
                        <tbody>
                            <?php foreach ($assets as $asset): ?>
                            <tr>
                                <td><strong><?= e($asset['asset_name']) ?></strong><br><small class="text-muted"><?= e($asset['location'] ?? '') ?></small></td>
                                <td><?= e($asset['category']) ?></td>
                                <td><?= $asset['quantity'] ?></td>
                                <td><span class="badge bg-<?= $asset['status'] === 'current' ? 'success' : ($asset['status'] === 'future' ? 'warning' : 'danger') ?>"><?= $asset['status'] ?></span></td>
                                <td><?= $asset['wattage'] ?> واط<br><small><?= $asset['phase_type'] ?></small></td>
                                <td>
                                    <div class="form-check form-switch">
                                        <input class="form-check-input" type="checkbox" <?= $asset['is_running'] ? 'checked' : '' ?> onchange="toggleAsset(<?= $asset['id'] ?>)">
                                    </div>
                                </td>
                                <td><a href="#" class="btn btn-sm btn-primary"><i class="bi bi-pencil"></i></a></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
function toggleAsset(id) {
    fetch('/assets/toggle/' + id, { method: 'POST' })
    .then(r => r.json())
    .then(res => { if (res.status === 'success') location.reload(); });
}
</script>
