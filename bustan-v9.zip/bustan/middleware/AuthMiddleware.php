<?php
namespace Middleware;

use Core\Middleware;
use Core\Auth;

class AuthMiddleware extends Middleware {
    public function handle(): void {
        Auth::requireAuth();
    }
}
