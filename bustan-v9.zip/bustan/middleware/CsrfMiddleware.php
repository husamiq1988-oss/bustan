<?php
namespace Middleware;

use Core\Middleware;
use Core\CSRF;

class CsrfMiddleware extends Middleware {
    public function handle(): void {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            CSRF::check();
        }
    }
}
