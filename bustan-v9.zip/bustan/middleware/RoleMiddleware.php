<?php
namespace Middleware;

use Core\Middleware;
use Core\Auth;

class RoleMiddleware extends Middleware {
    private string $role;

    public function __construct(string $role = '') {
        $this->role = $role;
    }

    public function handle(): void {
        Auth::requireAuth();
        if ($this->role && !Auth::isAdmin() && Auth::role() !== $this->role) {
            http_response_code(403);
            die('Access Denied');
        }
    }
}
