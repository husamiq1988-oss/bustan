<?php
namespace Models;

use Core\Model;

class WheelPrize extends Model {
    protected string $table = 'wheel_prizes';

    public function active(): array {
        return $this->db->fetchAll(
            "SELECT * FROM `{$this->table}` WHERE weight > 0 ORDER BY id ASC"
        );
    }

    public function totalWeight(): int {
        $result = $this->db->fetch("SELECT SUM(weight) as total FROM `{$this->table}`");
        return (int) ($result['total'] ?? 0);
    }
}
