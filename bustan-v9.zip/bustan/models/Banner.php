<?php
namespace Models;

use Core\Model;

class Banner extends Model {
    protected string $table = 'banners';

    public function active(): array {
        return $this->db->fetchAll(
            "SELECT * FROM `{$this->table}` WHERE is_active = 1 ORDER BY id DESC"
        );
    }
}
