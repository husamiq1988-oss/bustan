<?php
namespace Models;

use Core\Model;

class UnitConversion extends Model {
    protected string $table = 'unit_conversions';

    public function byInventory(int $inventoryId): ?array {
        return $this->db->fetch(
            "SELECT * FROM `{$this->table}` WHERE inventory_id = ? LIMIT 1",
            [$inventoryId]
        );
    }
}
