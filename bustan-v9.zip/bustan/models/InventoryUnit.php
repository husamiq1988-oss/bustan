<?php
namespace Models;

use Core\Model;

class InventoryUnit extends Model {
    protected string $table = 'inventory_units';

    public function byItem(int $itemId): array {
        return $this->where('item_id', $itemId);
    }

    public function mainUnit(int $itemId): ?array {
        return $this->db->fetch(
            "SELECT * FROM `{$this->table}` WHERE item_id = ? LIMIT 1",
            [$itemId]
        );
    }
}
