<?php
namespace Models;

use Core\Model;

class Asset extends Model {
    protected string $table = 'fixed_assets';

    public function byStatus(string $status): array {
        return $this->db->fetchAll(
            "SELECT * FROM `{$this->table}` WHERE status = ? ORDER BY id DESC",
            [$status]
        );
    }

    public function running(): array {
        return $this->db->fetchAll(
            "SELECT * FROM `{$this->table}` WHERE is_running = 1 ORDER BY id DESC"
        );
    }

    public function totalWattage(): array {
        return $this->db->fetch(
            "SELECT SUM(CASE WHEN load_type = 'continuous' THEN wattage * quantity ELSE 0 END) as continuous_watts, SUM(CASE WHEN load_type != 'continuous' THEN wattage * quantity ELSE 0 END) as intermittent_watts FROM `{$this->table}` WHERE status = 'current'"
        ) ?? ['continuous_watts' => 0, 'intermittent_watts' => 0];
    }

    public function toggleRunning(int $id): int {
        return $this->db->query("UPDATE `{$this->table}` SET is_running = NOT is_running WHERE id = ?", [$id]);
    }

    public function maintenanceLogs(int $assetId): array {
        return $this->db->fetchAll(
            "SELECT * FROM asset_maintenance WHERE asset_id = ? ORDER BY maintenance_date DESC",
            [$assetId]
        );
    }
}
