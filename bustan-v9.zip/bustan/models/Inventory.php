<?php
namespace Models;

use Core\Model;

class Inventory extends Model {
    protected string $table = 'inventory';

    public function lowStock(): array {
        return $this->db->fetchAll(
            "SELECT * FROM `{$this->table}` WHERE current_qty <= alert_level OR current_qty <= min_qty ORDER BY current_qty ASC"
        );
    }

    public function withUnits(): array {
        return $this->db->fetchAll(
            "SELECT i.*, u.from_unit, u.equivalent_quantity, u.to_unit, u.calculated_unit_cost 
             FROM `{$this->table}` i LEFT JOIN inventory_units u ON i.id = u.item_id ORDER BY i.id DESC"
        );
    }

    public function updateQty(int $id, float $qty): int {
        return $this->db->update($this->table, ['current_qty' => $qty], "id = ?", [$id]);
    }

    public function decrement(int $id, float $amount): int {
        return $this->db->query("UPDATE `{$this->table}` SET current_qty = current_qty - ? WHERE id = ?", [$amount, $id]);
    }

    public function increment(int $id, float $amount): int {
        return $this->db->query("UPDATE `{$this->table}` SET current_qty = current_qty + ? WHERE id = ?", [$amount, $id]);
    }
}
