<?php
namespace Models;

use Core\Model;

class Setting extends Model {
    protected string $table = 'restaurant_settings';
    protected string $primaryKey = 'setting_key';

    public function get(string $key, string $default = ''): string {
        $result = $this->db->fetch(
            "SELECT setting_value FROM `{$this->table}` WHERE setting_key = ?",
            [$key]
        );
        return $result['setting_value'] ?? $default;
    }

    public function set(string $key, string $value): int {
        $exists = $this->db->fetch("SELECT 1 FROM `{$this->table}` WHERE setting_key = ?", [$key]);
        if ($exists) {
            return $this->db->update($this->table, ['setting_value' => $value], "setting_key = ?", [$key]);
        }
        return $this->db->insert($this->table, ['setting_key' => $key, 'setting_value' => $value]);
    }

    public function all(): array {
        $results = $this->db->fetchAll("SELECT * FROM `{$this->table}`");
        $settings = [];
        foreach ($results as $row) {
            $settings[$row['setting_key']] = $row['setting_value'];
        }
        return $settings;
    }
}
