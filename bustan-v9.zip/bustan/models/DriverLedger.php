<?php
namespace Models;

use Core\Model;

class DriverLedger extends Model {
    protected string $table = 'driver_ledger';

    public function byDriver(int $driverId): array {
        return $this->db->fetchAll(
            "SELECT * FROM `{$this->table}` WHERE driver_id = ? ORDER BY created_at DESC",
            [$driverId]
        );
    }

    public function balance(int $driverId): float {
        $result = $this->db->fetch(
            "SELECT SUM(amount) as total FROM `{$this->table}` WHERE driver_id = ?",
            [$driverId]
        );
        return (float) ($result['total'] ?? 0);
    }
}
