<?php
namespace Models;

use Core\Model;

class Employee extends Model {
    protected string $table = 'employees';

    public function active(): array {
        return $this->db->fetchAll(
            "SELECT * FROM `{$this->table}` WHERE status = 'active' ORDER BY id DESC"
        );
    }

    public function attendance(int $employeeId, string $date): ?array {
        return $this->db->fetch(
            "SELECT * FROM employee_attendance WHERE employee_id = ? AND date = ?",
            [$employeeId, $date]
        );
    }

    public function transactions(int $employeeId): array {
        return $this->db->fetchAll(
            "SELECT * FROM employee_transactions WHERE employee_id = ? ORDER BY date DESC",
            [$employeeId]
        );
    }
}
