<?php
namespace Models;

use Core\Model;

class Product extends Model {
    protected string $table = 'products';

    public function available(): array {
        return $this->db->fetchAll(
            "SELECT p.*, c.name as category_name FROM `{$this->table}` p LEFT JOIN categories c ON p.category_id = c.id WHERE p.is_available = 1 ORDER BY p.category_id, p.id DESC"
        );
    }

    public function byCategory(int $categoryId): array {
        return $this->db->fetchAll(
            "SELECT * FROM `{$this->table}` WHERE category_id = ? AND is_available = 1 ORDER BY id DESC",
            [$categoryId]
        );
    }

    public function withCategory(): array {
        return $this->db->fetchAll(
            "SELECT p.*, c.name as category_name FROM `{$this->table}` p LEFT JOIN categories c ON p.category_id = c.id ORDER BY p.id DESC"
        );
    }

    public function toggle(int $id): int {
        return $this->db->query("UPDATE `{$this->table}` SET is_available = NOT is_available WHERE id = ?", [$id]);
    }

    public function search(string $query): array {
        return $this->db->fetchAll(
            "SELECT * FROM `{$this->table}` WHERE name LIKE ? OR description LIKE ? ORDER BY id DESC",
            ["%{$query}%", "%{$query}%"]
        );
    }
}
