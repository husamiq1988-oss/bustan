<?php
namespace Models;

use Core\Model;

class LabRecipe extends Model {
    protected string $table = 'lab_recipes';

    public function visible(): array {
        return $this->db->fetchAll(
            "SELECT * FROM `{$this->table}` WHERE is_visible = 1 ORDER BY id DESC"
        );
    }

    public function withIngredients(int $id): array {
        $recipe = $this->find($id);
        if (!$recipe) return [];
        $ingredients = $this->db->fetchAll(
            "SELECT ri.*, i.item_name FROM recipe_ingredients ri LEFT JOIN inventory i ON ri.store_item_id = i.id WHERE ri.recipe_id = ?",
            [$id]
        );
        $steps = $this->db->fetchAll(
            "SELECT * FROM recipe_steps WHERE recipe_id = ? ORDER BY step_order ASC",
            [$id]
        );
        return ['recipe' => $recipe, 'ingredients' => $ingredients, 'steps' => $steps];
    }
}
