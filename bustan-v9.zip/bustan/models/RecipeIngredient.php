<?php
namespace Models;

use Core\Model;

class RecipeIngredient extends Model {
    protected string $table = 'recipe_ingredients';

    public function byRecipe(int $recipeId): array {
        return $this->where('recipe_id', $recipeId);
    }

    public function createBatch(int $recipeId, array $ingredients): void {
        $stmt = $this->db->getPdo()->prepare(
            "INSERT INTO `{$this->table}` (recipe_id, ingredient_name, store_item_id, ratio_per_unit, unit_type, price_per_kg) VALUES (?, ?, ?, ?, ?, ?)"
        );
        foreach ($ingredients as $ing) {
            $stmt->execute([$recipeId, $ing['name'], $ing['store_item_id'] ?? null, $ing['ratio'], $ing['unit'], $ing['price'] ?? 0]);
        }
    }
}
