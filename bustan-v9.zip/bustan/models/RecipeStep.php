<?php
namespace Models;

use Core\Model;

class RecipeStep extends Model {
    protected string $table = 'recipe_steps';

    public function byRecipe(int $recipeId): array {
        return $this->db->fetchAll(
            "SELECT * FROM `{$this->table}` WHERE recipe_id = ? ORDER BY step_order ASC",
            [$recipeId]
        );
    }

    public function createBatch(int $recipeId, array $steps): void {
        $stmt = $this->db->getPdo()->prepare(
            "INSERT INTO `{$this->table}` (recipe_id, step_order, step_description) VALUES (?, ?, ?)"
        );
        foreach ($steps as $i => $step) {
            $stmt->execute([$recipeId, $i + 1, $step]);
        }
    }
}
