<?php
namespace Models;

use Core\Model;

class Rating extends Model {
    protected string $table = 'ratings';

    public function byProduct(int $productId): array {
        return $this->db->fetchAll(
            "SELECT * FROM `{$this->table}` WHERE product_id = ? ORDER BY created_at DESC",
            [$productId]
        );
    }

    public function averageByProduct(int $productId): float {
        $result = $this->db->fetch(
            "SELECT AVG(rating) as avg FROM `{$this->table}` WHERE product_id = ?",
            [$productId]
        );
        return (float) ($result['avg'] ?? 0);
    }

    public function byPhone(string $phone): array {
        return $this->db->fetchAll(
            "SELECT * FROM `{$this->table}` WHERE user_phone = ? ORDER BY created_at DESC",
            [$phone]
        );
    }
}
