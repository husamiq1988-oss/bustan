<?php
namespace Models;

use Core\Model;

class Category extends Model {
    protected string $table = 'categories';

    public function visible(): array {
        return $this->db->fetchAll(
            "SELECT * FROM `{$this->table}` WHERE is_visible = 1 ORDER BY sort_order ASC, id ASC"
        );
    }

    public function allWithCount(): array {
        return $this->db->fetchAll(
            "SELECT c.*, COUNT(p.id) as product_count FROM `{$this->table}` c LEFT JOIN products p ON c.id = p.category_id GROUP BY c.id ORDER BY c.sort_order ASC"
        );
    }
}
