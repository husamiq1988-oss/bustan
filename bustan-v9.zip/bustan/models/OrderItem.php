<?php
namespace Models;

use Core\Model;

class OrderItem extends Model {
    protected string $table = 'order_items';

    public function byOrder(int $orderId): array {
        return $this->where('order_id', $orderId);
    }

    public function createBatch(int $orderId, array $items): void {
        $stmt = $this->db->getPdo()->prepare(
            "INSERT INTO `{$this->table}` (order_id, product_id, quantity, price, note) VALUES (?, ?, ?, ?, ?)"
        );
        foreach ($items as $item) {
            $stmt->execute([$orderId, $item['id'], $item['qty'], $item['price'], $item['note'] ?? '']);
        }
    }
}
