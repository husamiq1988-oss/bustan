<?php
namespace Models;

use Core\Model;

class Chat extends Model {
    protected string $table = 'bustan_support_chats';

    public function byPhone(string $phone): array {
        return $this->db->fetchAll(
            "SELECT * FROM `{$this->table}` WHERE user_phone = ? ORDER BY created_at ASC",
            [$phone]
        );
    }

    public function unread(): array {
        return $this->db->fetchAll(
            "SELECT * FROM `{$this->table}` WHERE sender_type = 'customer' AND is_read = 0 ORDER BY created_at DESC"
        );
    }

    public function markRead(string $phone): void {
        $this->db->query("UPDATE `{$this->table}` SET is_read = 1 WHERE user_phone = ? AND sender_type = 'customer'", [$phone]);
    }

    public function conversations(): array {
        return $this->db->fetchAll(
            "SELECT user_phone, customer_name, MAX(created_at) as last_message, COUNT(CASE WHEN is_read = 0 AND sender_type = 'customer' THEN 1 END) as unread_count FROM `{$this->table}` GROUP BY user_phone ORDER BY last_message DESC"
        );
    }
}
