<?php
namespace Models;

use Core\Model;

class Expense extends Model {
    protected string $table = 'expenses';

    public function today(): array {
        return $this->db->fetchAll(
            "SELECT * FROM `{$this->table}` WHERE expense_date = CURDATE() ORDER BY id DESC"
        );
    }

    public function monthly(): array {
        return $this->db->fetchAll(
            "SELECT * FROM `{$this->table}` WHERE MONTH(expense_date) = MONTH(CURDATE()) AND YEAR(expense_date) = YEAR(CURDATE()) ORDER BY expense_date DESC"
        );
    }

    public function byCategory(string $category): array {
        return $this->db->fetchAll(
            "SELECT * FROM `{$this->table}` WHERE category = ? ORDER BY expense_date DESC",
            [$category]
        );
    }

    public function totalToday(): float {
        $result = $this->db->fetch("SELECT SUM(amount) as total FROM `{$this->table}` WHERE expense_date = CURDATE()");
        return (float) ($result['total'] ?? 0);
    }

    public function totalMonth(): float {
        $result = $this->db->fetch(
            "SELECT SUM(amount) as total FROM `{$this->table}` WHERE MONTH(expense_date) = MONTH(CURDATE()) AND YEAR(expense_date) = YEAR(CURDATE())"
        );
        return (float) ($result['total'] ?? 0);
    }
}
