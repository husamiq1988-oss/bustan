<?php
namespace Models;

use Core\Model;

class Location extends Model {
    protected string $table = 'locations';

    public function withDriverCount(): array {
        return $this->db->fetchAll(
            "SELECT l.*, COUNT(dl.driver_id) as driver_count FROM `{$this->table}` l LEFT JOIN driver_locations dl ON l.id = dl.location_id GROUP BY l.id ORDER BY l.id DESC"
        );
    }
}
