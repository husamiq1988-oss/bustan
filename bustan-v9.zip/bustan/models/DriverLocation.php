<?php
namespace Models;

use Core\Model;

class DriverLocation extends Model {
    protected string $table = 'driver_locations';

    public function byDriver(int $driverId): array {
        return $this->where('driver_id', $driverId);
    }

    public function byLocation(int $locationId): array {
        return $this->where('location_id', $locationId);
    }

    public function assign(int $driverId, int $locationId): int {
        $this->db->query("DELETE FROM `{$this->table}` WHERE driver_id = ?", [$driverId]);
        return $this->db->insert($this->table, ['driver_id' => $driverId, 'location_id' => $locationId]);
    }
}
