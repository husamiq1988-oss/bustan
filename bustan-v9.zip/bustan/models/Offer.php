<?php
namespace Models;

use Core\Model;

class Offer extends Model {
    protected string $table = 'offers';

    public function latest(): array {
        return $this->db->fetchAll(
            "SELECT * FROM `{$this->table}` ORDER BY created_at DESC LIMIT 5"
        );
    }
}
