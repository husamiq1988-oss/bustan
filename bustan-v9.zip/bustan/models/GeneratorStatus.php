<?php
namespace Models;

use Core\Model;

class GeneratorStatus extends Model {
    protected string $table = 'generator_status';
    protected string $primaryKey = 'id';

    public function get(): ?array {
        return $this->db->fetch("SELECT * FROM `{$this->table}` WHERE id = 1");
    }

    public function start(): int {
        return $this->db->update($this->table, [
            'current_state' => 'running',
            'last_start_time' => date('Y-m-d H:i:s')
        ], "id = 1");
    }

    public function stop(float $duration, float $fuel): int {
        return $this->db->update($this->table, [
            'current_state' => 'stopped',
            'accumulated_hours' => "accumulated_hours + {$duration}",
            'total_lifetime_hours' => "total_lifetime_hours + {$duration}",
            'current_fuel_liters' => "current_fuel_liters - {$fuel}"
        ], "id = 1");
    }
}
