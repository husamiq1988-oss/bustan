<?php
namespace Models;

use Core\Model;

class WalletTransaction extends Model {
    protected string $table = 'wallet_transactions';

    public function byUser(int $userId): array {
        return $this->db->fetchAll(
            "SELECT * FROM `{$this->table}` WHERE user_id = ? ORDER BY created_at DESC",
            [$userId]
        );
    }

    public function today(): array {
        return $this->db->fetchAll(
            "SELECT * FROM `{$this->table}` WHERE DATE(created_at) = CURDATE() ORDER BY created_at DESC"
        );
    }

    public function totalToday(): float {
        $result = $this->db->fetch(
            "SELECT SUM(CASE WHEN type = 'deposit' THEN amount ELSE -amount END) as total FROM `{$this->table}` WHERE DATE(created_at) = CURDATE()"
        );
        return (float) ($result['total'] ?? 0);
    }
}
