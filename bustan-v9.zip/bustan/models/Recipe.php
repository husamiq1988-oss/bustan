<?php
namespace Models;

use Core\Model;

class Recipe extends Model {
    protected string $table = 'recipes';

    public function byProduct(int $productId): array {
        return $this->db->fetchAll(
            "SELECT r.*, i.item_name as inventory_name FROM `{$this->table}` r LEFT JOIN inventory i ON r.inventory_id = i.id WHERE r.product_id = ?",
            [$productId]
        );
    }

    public function withIngredients(): array {
        return $this->db->fetchAll(
            "SELECT r.*, p.name as product_name, i.item_name as inventory_name FROM `{$this->table}` r 
             LEFT JOIN products p ON r.product_id = p.id 
             LEFT JOIN inventory i ON r.inventory_id = i.id ORDER BY r.id DESC"
        );
    }
}
