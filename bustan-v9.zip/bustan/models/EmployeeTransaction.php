<?php
namespace Models;

use Core\Model;

class EmployeeTransaction extends Model {
    protected string $table = 'employee_transactions';

    public function byEmployee(int $employeeId): array {
        return $this->db->fetchAll(
            "SELECT * FROM `{$this->table}` WHERE employee_id = ? ORDER BY date DESC",
            [$employeeId]
        );
    }

    public function monthly(): array {
        return $this->db->fetchAll(
            "SELECT et.*, e.name as employee_name FROM `{$this->table}` et LEFT JOIN employees e ON et.employee_id = e.id WHERE MONTH(et.date) = MONTH(CURDATE()) AND YEAR(et.date) = YEAR(CURDATE()) ORDER BY et.date DESC"
        );
    }
}
