<?php
namespace Models;

use Core\Model;

class Driver extends Model {
    protected string $table = 'drivers';

    public function active(): array {
        return $this->db->fetchAll(
            "SELECT d.*, l.location_name FROM `{$this->table}` d LEFT JOIN locations l ON d.location_id = l.id WHERE d.status = 'active' ORDER BY d.id DESC"
        );
    }

    public function findByPhone(string $phone): ?array {
        return $this->findBy('phone', $phone);
    }

    public function withOrdersCount(): array {
        return $this->db->fetchAll(
            "SELECT d.*, COUNT(o.id) as active_orders FROM `{$this->table}` d LEFT JOIN orders o ON d.id = o.driver_id AND o.order_status IN ('pending', 'preparing') GROUP BY d.id ORDER BY active_orders ASC"
        );
    }

    public function ledger(int $driverId): array {
        return $this->db->fetchAll(
            "SELECT * FROM driver_ledger WHERE driver_id = ? ORDER BY created_at DESC",
            [$driverId]
        );
    }
}
