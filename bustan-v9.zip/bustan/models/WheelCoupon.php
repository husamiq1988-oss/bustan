<?php
namespace Models;

use Core\Model;

class WheelCoupon extends Model {
    protected string $table = 'wheel_coupons';

    public function findByCode(string $code): ?array {
        return $this->db->fetch(
            "SELECT * FROM `{$this->table}` WHERE coupon_code = ? AND is_used = 0 AND (expires_at IS NULL OR expires_at > NOW()) LIMIT 1",
            [$code]
        );
    }

    public function use(string $code): int {
        return $this->db->update($this->table, ['is_used' => 1], "coupon_code = ?", [$code]);
    }

    public function byPhone(string $phone): array {
        return $this->db->fetchAll(
            "SELECT * FROM `{$this->table}` WHERE user_phone = ? ORDER BY created_at DESC",
            [$phone]
        );
    }
}
