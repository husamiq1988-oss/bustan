<?php
namespace Models;

use Core\Model;

class GeneratorLog extends Model {
    protected string $table = 'generator_logs';

    public function today(): array {
        return $this->db->fetchAll(
            "SELECT * FROM `{$this->table}` WHERE DATE(start_time) = CURDATE() ORDER BY start_time DESC"
        );
    }

    public function monthly(): array {
        return $this->db->fetchAll(
            "SELECT * FROM `{$this->table}` WHERE MONTH(start_time) = MONTH(CURDATE()) AND YEAR(start_time) = YEAR(CURDATE()) ORDER BY start_time DESC"
        );
    }

    public function totalHours(): float {
        $result = $this->db->fetch("SELECT SUM(duration_minutes) as total FROM `{$this->table}` WHERE MONTH(start_time) = MONTH(CURDATE())");
        return (float) (($result['total'] ?? 0) / 60);
    }

    public function totalFuel(): float {
        $result = $this->db->fetch("SELECT SUM(estimated_fuel_consumed) as total FROM `{$this->table}` WHERE MONTH(start_time) = MONTH(CURDATE())");
        return (float) ($result['total'] ?? 0);
    }
}
