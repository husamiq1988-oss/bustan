<?php
namespace Models;

use Core\Model;

class Order extends Model {
    protected string $table = 'orders';

    public function today(): array {
        return $this->db->fetchAll(
            "SELECT * FROM `{$this->table}` WHERE DATE(created_at) = CURDATE() ORDER BY id DESC"
        );
    }

    public function pending(): array {
        return $this->db->fetchAll(
            "SELECT * FROM `{$this->table}` WHERE order_status IN ('pending', 'preparing') ORDER BY created_at ASC"
        );
    }

    public function byStatus(string $status): array {
        return $this->db->fetchAll(
            "SELECT * FROM `{$this->table}` WHERE order_status = ? ORDER BY created_at DESC",
            [$status]
        );
    }

    public function byUser(int $userId): array {
        return $this->db->fetchAll(
            "SELECT * FROM `{$this->table}` WHERE user_id = ? ORDER BY created_at DESC",
            [$userId]
        );
    }

    public function byDriver(int $driverId): array {
        return $this->db->fetchAll(
            "SELECT * FROM `{$this->table}` WHERE driver_id = ? AND order_status IN ('pending', 'preparing', 'completed') ORDER BY created_at DESC",
            [$driverId]
        );
    }

    public function updateStatus(int $id, string $status): int {
        return $this->db->update($this->table, ['order_status' => $status, 'status' => $status], "id = ?", [$id]);
    }

    public function assignDriver(int $id, int $driverId): int {
        return $this->db->update($this->table, ['driver_id' => $driverId], "id = ?", [$id]);
    }

    public function todayStats(): array {
        return $this->db->fetch(
            "SELECT COUNT(*) as count, SUM(total_amount) as total, SUM(CASE WHEN payment_method = 'wallet' THEN total_amount ELSE 0 END) as wallet_total FROM `{$this->table}` WHERE DATE(created_at) = CURDATE()"
        ) ?? ['count' => 0, 'total' => 0, 'wallet_total' => 0];
    }

    public function monthlyStats(): array {
        return $this->db->fetch(
            "SELECT COUNT(*) as count, SUM(total_amount) as total FROM `{$this->table}` WHERE MONTH(created_at) = MONTH(CURDATE()) AND YEAR(created_at) = YEAR(CURDATE())"
        ) ?? ['count' => 0, 'total' => 0];
    }
}
