<?php
namespace Models;

use Core\Model;

class Story extends Model {
    protected string $table = 'bustan_stories';

    public function approved(): array {
        return $this->db->fetchAll(
            "SELECT * FROM `{$this->table}` WHERE is_approved = 1 ORDER BY created_at DESC"
        );
    }

    public function pending(): array {
        return $this->db->fetchAll(
            "SELECT * FROM `{$this->table}` WHERE is_approved = 0 ORDER BY created_at DESC"
        );
    }

    public function featured(): array {
        return $this->db->fetchAll(
            "SELECT * FROM `{$this->table}` WHERE is_featured_cover = 1 AND is_approved = 1 ORDER BY created_at DESC LIMIT 5"
        );
    }

    public function approve(int $id): int {
        return $this->db->update($this->table, ['is_approved' => 1], "id = ?", [$id]);
    }

    public function feature(int $id): int {
        return $this->db->update($this->table, ['is_featured_cover' => 1], "id = ?", [$id]);
    }
}
