<?php
namespace Models;

use Core\Model;

class WheelSpin extends Model {
    protected string $table = 'wheel_spins';

    public function byOrder(int $orderId): ?array {
        return $this->db->fetch(
            "SELECT * FROM `{$this->table}` WHERE order_id = ? LIMIT 1",
            [$orderId]
        );
    }

    public function today(): array {
        return $this->db->fetchAll(
            "SELECT * FROM `{$this->table}` WHERE DATE(created_at) = CURDATE() ORDER BY id DESC"
        );
    }
}
