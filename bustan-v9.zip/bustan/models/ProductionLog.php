<?php
namespace Models;

use Core\Model;

class ProductionLog extends Model {
    protected string $table = 'production_logs';

    public function today(): array {
        return $this->db->fetchAll(
            "SELECT pl.*, lr.recipe_name FROM `{$this->table}` pl LEFT JOIN lab_recipes lr ON pl.recipe_id = lr.id WHERE DATE(pl.created_at) = CURDATE() ORDER BY pl.created_at DESC"
        );
    }

    public function byRecipe(int $recipeId): array {
        return $this->db->fetchAll(
            "SELECT * FROM `{$this->table}` WHERE recipe_id = ? ORDER BY created_at DESC",
            [$recipeId]
        );
    }
}
