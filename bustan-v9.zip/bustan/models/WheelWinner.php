<?php
namespace Models;

use Core\Model;

class WheelWinner extends Model {
    protected string $table = 'wheel_winners';

    public function recent(): array {
        return $this->db->fetchAll(
            "SELECT * FROM `{$this->table}` ORDER BY won_at DESC LIMIT 50"
        );
    }

    public function undelivered(): array {
        return $this->db->fetchAll(
            "SELECT * FROM `{$this->table}` WHERE is_delivered = 0 ORDER BY won_at DESC"
        );
    }

    public function deliver(int $id): int {
        return $this->db->update($this->table, ['is_delivered' => 1], "id = ?", [$id]);
    }
}
