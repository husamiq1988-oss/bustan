<?php
namespace Models;

use Core\Model;

class Purchase extends Model {
    protected string $table = 'purchases';

    public function byInventory(int $inventoryId): array {
        return $this->db->fetchAll(
            "SELECT * FROM `{$this->table}` WHERE inventory_id = ? ORDER BY purchase_date DESC",
            [$inventoryId]
        );
    }

    public function monthly(): array {
        return $this->db->fetchAll(
            "SELECT * FROM `{$this->table}` WHERE MONTH(purchase_date) = MONTH(CURDATE()) AND YEAR(purchase_date) = YEAR(CURDATE()) ORDER BY purchase_date DESC"
        );
    }
}
