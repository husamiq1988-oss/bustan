<?php
namespace Models;

use Core\Model;

class User extends Model {
    protected string $table = 'users';

    public function findByPhone(string $phone): ?array {
        return $this->findBy('phone', $phone);
    }

    public function updateBalance(int $id, float $amount): int {
        return $this->db->update($this->table, ['balance' => $amount], "id = ?", [$id]);
    }

    public function addPoints(int $id, int $points): int {
        return $this->db->query("UPDATE `{$this->table}` SET points = points + ? WHERE id = ?", [$points, $id]);
    }

    public function search(string $query): array {
        return $this->db->fetchAll(
            "SELECT * FROM `{$this->table}` WHERE name LIKE ? OR phone LIKE ? OR full_name LIKE ? ORDER BY id DESC",
            ["%{$query}%", "%{$query}%", "%{$query}%"]
        );
    }
}
