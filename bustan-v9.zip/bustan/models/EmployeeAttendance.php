<?php
namespace Models;

use Core\Model;

class EmployeeAttendance extends Model {
    protected string $table = 'employee_attendance';

    public function today(): array {
        return $this->db->fetchAll(
            "SELECT ea.*, e.name as employee_name FROM `{$this->table}` ea LEFT JOIN employees e ON ea.employee_id = e.id WHERE ea.date = CURDATE() ORDER BY ea.check_in DESC"
        );
    }

    public function byEmployee(int $employeeId, string $month): array {
        return $this->db->fetchAll(
            "SELECT * FROM `{$this->table}` WHERE employee_id = ? AND DATE_FORMAT(date, '%Y-%m') = ? ORDER BY date DESC",
            [$employeeId, $month]
        );
    }
}
