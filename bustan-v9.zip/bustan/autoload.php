<?php
spl_autoload_register(function ($class) {
    $base_dir = __DIR__ . '/';

    // تحويل \ إلى /
    $classPath = str_replace('\\', '/', $class);

    // المحاولة 1: lowercase كامل
    $file = $base_dir . strtolower($classPath) . '.php';
    if (file_exists($file)) {
        require $file;
        return;
    }

    // المحاولة 2: lowercase للمجلد الأول فقط
    $parts = explode('/', $classPath);
    $parts[0] = strtolower($parts[0]);
    $file = $base_dir . implode('/', $parts) . '.php';
    if (file_exists($file)) {
        require $file;
        return;
    }

    // المحاولة 3: المسار الأصلي
    $file = $base_dir . $classPath . '.php';
    if (file_exists($file)) {
        require $file;
        return;
    }
});
