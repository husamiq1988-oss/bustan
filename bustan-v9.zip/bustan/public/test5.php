<?php
define('DEBUG', true);

if (DEBUG) {
    error_reporting(E_ALL);
    ini_set('display_errors', 1);
    ini_set('display_startup_errors', 1);
}

echo '<h1>اختبار كامل للنظام</h1>';

try {
    echo '<p>1. تسجيل autoloader يدوي...</p>';
    spl_autoload_register(function ($class) {
        $base_dir = __DIR__ . '/../';
        $file = $base_dir . strtolower(str_replace('\\', '/', $class)) . '.php';
        if (file_exists($file)) {
            require $file;
            return true;
        }
        return false;
    });
    echo '<p>✅ Autoloader يدوي مسجل</p>';

    echo '<p>2. تحميل helpers...</p>';
    require __DIR__ . '/../helpers/functions.php';
    echo '<p>✅ Helpers محملة</p>';

    echo '<p>3. اختبار Core\App...</p>';
    if (!class_exists('Core\App')) {
        throw new Exception('Core\App غير موجود!');
    }
    echo '<p>✅ Core\App موجود</p>';

    echo '<p>4. إنشاء App...</p>';
    $app = new Core\App();
    echo '<p>✅ App تم إنشاؤه</p>';

    echo '<p>5. تشغيل App...</p>';
    echo '<hr><h3>نتيجة التشغيل:</h3>';
    $app->run();

} catch (Throwable $e) {
    echo '<div style="background:#dc3545;color:white;padding:20px;margin:20px;border-radius:10px;">';
    echo '<h3>❌ خطأ!</h3>';
    echo '<p><strong>النوع:</strong> ' . get_class($e) . '</p>';
    echo '<p><strong>الرسالة:</strong> ' . $e->getMessage() . '</p>';
    echo '<p><strong>الملف:</strong> ' . $e->getFile() . '</p>';
    echo '<p><strong>السطر:</strong> ' . $e->getLine() . '</p>';
    echo '<hr><pre>' . $e->getTraceAsString() . '</pre>';
    echo '</div>';
}
