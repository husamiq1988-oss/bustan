<?php
// test4.php - اختبار الـ Rewrite
echo '<h1>اختبار Rewrite</h1>';
echo '<p>REQUEST_URI: ' . $_SERVER['REQUEST_URI'] . '</p>';
echo '<p>SCRIPT_NAME: ' . $_SERVER['SCRIPT_NAME'] . '</p>';
echo '<p>PHP_SELF: ' . $_SERVER['PHP_SELF'] . '</p>';
echo '<p>HTTP_HOST: ' . $_SERVER['HTTP_HOST'] . '</p>';

// اختبار إذا كان mod_rewrite يعمل
if (isset($_GET['test'])) {
    echo '<p>✅ GET parameters تعمل!</p>';
}

echo '<hr>';
echo '<p>جرب فتح هذا الرابط:</p>';
echo '<code>' . $_SERVER['HTTP_HOST'] . dirname($_SERVER['SCRIPT_NAME']) . '/test4.php?test=1</code>';
