<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);

require __DIR__ . '/../autoload.php';
require __DIR__ . '/../helpers/functions.php';

try {
    $app = new Core\App();
    $app->run();
} catch (\Throwable $e) {
    echo '<div style="background:#dc3545;color:white;padding:20px;margin:20px;border-radius:10px;font-family:Arial;">';
    echo '<h2>❌ خطأ في النظام</h2>';
    echo '<p><strong>الرسالة:</strong> ' . htmlspecialchars($e->getMessage()) . '</p>';
    echo '<p><strong>الملف:</strong> ' . $e->getFile() . ' (سطر ' . $e->getLine() . ')</p>';
    echo '<hr><pre style="background:rgba(0,0,0,0.2);padding:10px;border-radius:5px;overflow:auto;">' . $e->getTraceAsString() . '</pre>';
    echo '</div>';
}
