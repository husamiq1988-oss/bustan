<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

echo '<h1>اختبار الـ Autoloader</h1>';

// Autoloader يدوي - lowercase
spl_autoload_register(function ($class) {
    $base_dir = __DIR__ . '/../';
    $file = $base_dir . strtolower(str_replace('\\', '/', $class)) . '.php';
    echo '<p>محاولة تحميل: ' . $file . ' - ' . (file_exists($file) ? '✅ موجود' : '❌ غير موجود') . '</p>';
    if (file_exists($file)) {
        require $file;
    }
});

require __DIR__ . '/../helpers/functions.php';

echo '<hr>';
echo '<p>اختبار Core\Database: ' . (class_exists('Core\Database') ? '✅' : '❌') . '</p>';
echo '<p>اختبار Core\App: ' . (class_exists('Core\App') ? '✅' : '❌') . '</p>';
echo '<p>اختبار Core\Router: ' . (class_exists('Core\Router') ? '✅' : '❌') . '</p>';

try {
    $app = new Core\App();
    echo '<p>Core\App: ✅ تم الإنشاء</p>';
} catch (Exception $e) {
    echo '<p>Core\App: ❌ ' . $e->getMessage() . '</p>';
}
