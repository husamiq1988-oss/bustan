<?php
// test3.php - اختبار قاعدة البيانات
error_reporting(E_ALL);
ini_set('display_errors', 1);

echo '<h1>اختبار قاعدة البيانات</h1>';

$config = require __DIR__ . '/../config/database.php';

echo '<pre>';
print_r($config);
echo '</pre>';

try {
    $dsn = "mysql:host={$config['host']};dbname={$config['database']};charset={$config['charset']}";
    $pdo = new PDO($dsn, $config['username'], $config['password'], $config['options']);
    echo '<p>✅ الاتصال ناجح!</p>';

    // اختبار الجداول
    $tables = $pdo->query("SHOW TABLES")->fetchAll(PDO::FETCH_COLUMN);
    echo '<p>الجداول الموجودة (' . count($tables) . '):</p>';
    echo '<ul>';
    foreach ($tables as $table) {
        echo '<li>' . $table . '</li>';
    }
    echo '</ul>';
} catch (PDOException $e) {
    echo '<p>❌ خطأ: ' . $e->getMessage() . '</p>';
}
