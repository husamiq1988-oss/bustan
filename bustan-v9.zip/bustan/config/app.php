<?php
return [
    'name' => 'مطعم البستان 🌿',
    'url' => 'http://localhost/BUSTAN-v2/public',
    'timezone' => 'Asia/Baghdad',
    'locale' => 'ar',
    'debug' => true,
    'session_lifetime' => 7200, // 2 hours
    'csrf_token_name' => '_token',
    'upload_path' => __DIR__ . '/../public/uploads/',
    'max_upload_size' => 5 * 1024 * 1024, // 5MB
];
