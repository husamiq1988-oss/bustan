<?php
function e(string $text): string {
    return htmlspecialchars($text, ENT_QUOTES, 'UTF-8');
}

function asset(string $path): string {
    // استخدام المسار المباشر
    return '/bustan/public/assets/' . ltrim($path, '/');
}

function url(string $path = ''): string {
    return '/bustan/public/' . ltrim($path, '/');
}

function csrf_field(): string {
    return '<input type="hidden" name="_token" value="' . e($_SESSION['csrf_token'] ?? '') . '">';
}

function old(string $key, string $default = ''): string {
    return $_SESSION['old'][$key] ?? $default;
}

function flash(string $key): ?string {
    if (isset($_SESSION['flash'][$key])) {
        $msg = $_SESSION['flash'][$key];
        unset($_SESSION['flash'][$key]);
        return $msg;
    }
    return null;
}

function format_money(float $amount): string {
    return number_format($amount) . ' د.ع';
}

function format_date(string $date): string {
    return date('Y-m-d H:i', strtotime($date));
}
