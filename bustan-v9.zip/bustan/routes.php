<?php
use Core\Router;

return function(Router $router) {
    // Public routes
    $router->get('', 'MenuController@index');
    $router->get('menu', 'MenuController@index');
    $router->get('login', 'AuthController@loginForm');
    $router->post('login', 'AuthController@login');
    $router->get('logout', 'AuthController@logout');

    // API routes (JSON)
    $router->post('api/order', 'OrderController@store');
    $router->post('api/rating', 'RatingController@store');
    $router->post('api/support', 'ChatController@send');

    // Protected routes
    $router->get('dashboard', 'DashboardController@index', ['AuthMiddleware']);
    $router->get('dashboard/profits', 'DashboardController@profits', ['AuthMiddleware']);
    $router->get('dashboard/sales', 'DashboardController@sales', ['AuthMiddleware']);

    // Kitchen
    $router->get('kitchen', 'KitchenController@index', ['AuthMiddleware']);
    $router->post('kitchen/complete/{id}', 'KitchenController@complete', ['AuthMiddleware']);

    // Cashier
    $router->get('cashier', 'CashierController@index', ['AuthMiddleware']);
    $router->post('cashier/process', 'CashierController@process', ['AuthMiddleware']);

    // Delivery
    $router->get('delivery', 'DeliveryController@index', ['AuthMiddleware']);
    $router->post('delivery/update/{id}', 'DeliveryController@update', ['AuthMiddleware']);

    // Inventory
    $router->get('inventory', 'InventoryController@index', ['AuthMiddleware']);
    $router->post('inventory/store', 'InventoryController@store', ['AuthMiddleware']);
    $router->get('inventory/edit/{id}', 'InventoryController@edit', ['AuthMiddleware']);
    $router->post('inventory/update/{id}', 'InventoryController@update', ['AuthMiddleware']);

    // Recipes
    $router->get('recipes', 'RecipeController@index', ['AuthMiddleware']);
    $router->get('recipes/create', 'RecipeController@create', ['AuthMiddleware']);
    $router->post('recipes/store', 'RecipeController@store', ['AuthMiddleware']);
    $router->get('recipes/edit/{id}', 'RecipeController@edit', ['AuthMiddleware']);
    $router->post('recipes/update/{id}', 'RecipeController@update', ['AuthMiddleware']);

    // Assets
    $router->get('assets', 'AssetController@index', ['AuthMiddleware']);
    $router->post('assets/store', 'AssetController@store', ['AuthMiddleware']);

    // Generator
    $router->get('generator', 'GeneratorController@index', ['AuthMiddleware']);
    $router->post('generator/toggle', 'GeneratorController@toggle', ['AuthMiddleware']);

    // Admin actions
    $router->get('admin/users', 'AdminController@users', ['AuthMiddleware']);
    $router->post('admin/users/update', 'AdminController@updateUser', ['AuthMiddleware']);
    $router->get('admin/products', 'AdminController@products', ['AuthMiddleware']);
    $router->post('admin/products/store', 'AdminController@storeProduct', ['AuthMiddleware']);
    $router->post('admin/products/update/{id}', 'AdminController@updateProduct', ['AuthMiddleware']);
    $router->post('admin/products/delete/{id}', 'AdminController@deleteProduct', ['AuthMiddleware']);
    $router->post('admin/products/toggle/{id}', 'AdminController@toggleProduct', ['AuthMiddleware']);
    $router->get('admin/categories', 'AdminController@categories', ['AuthMiddleware']);
    $router->post('admin/categories/store', 'AdminController@storeCategory', ['AuthMiddleware']);
    $router->post('admin/categories/delete/{id}', 'AdminController@deleteCategory', ['AuthMiddleware']);
    $router->get('admin/orders', 'AdminController@orders', ['AuthMiddleware']);
    $router->post('admin/orders/status/{id}', 'AdminController@updateOrderStatus', ['AuthMiddleware']);
    $router->get('admin/expenses', 'AdminController@expenses', ['AuthMiddleware']);
    $router->post('admin/expenses/store', 'AdminController@storeExpense', ['AuthMiddleware']);
    $router->get('admin/chats', 'AdminController@chats', ['AuthMiddleware']);
    $router->get('admin/stories', 'AdminController@stories', ['AuthMiddleware']);
    $router->get('admin/wheel', 'AdminController@wheel', ['AuthMiddleware']);
    $router->post('admin/wheel/prize', 'AdminController@storePrize', ['AuthMiddleware']);
    $router->get('admin/settings', 'AdminController@settings', ['AuthMiddleware']);
    $router->post('admin/settings', 'AdminController@updateSettings', ['AuthMiddleware']);

    // Wheel
    $router->get('wheel', 'WheelController@index');
    $router->post('wheel/spin', 'WheelController@spin');
    $router->get('wheel/winners', 'WheelController@winners', ['AuthMiddleware']);

    // Reports
    $router->get('reports', 'ReportController@index', ['AuthMiddleware']);
    $router->get('reports/sales', 'ReportController@sales', ['AuthMiddleware']);
    $router->get('reports/profits', 'ReportController@profits', ['AuthMiddleware']);
};
